@echo off
cd /d "%~dp0"
echo Compiling Prime Mobile RP...
"pawno\pawncc.exe" "gamemodes\FRP.pwn" -D"gamemodes" -i"pawno\include" -o"gamemodes\FRP.amx"
if errorlevel 1 (
    echo.
    echo Compilation failed.
    pause
    exit /b 1
)
echo.
echo Compilation successful: gamemodes\FRP.amx
pause
