@echo off
cd /d "%~dp0"
echo ========================================
echo   Prime Mobile RP - Build and Start
echo ========================================
echo.
if not exist "pawno\pawncc.exe" (
    echo ERROR: pawno\pawncc.exe was not found.
    pause
    exit /b 1
)
if not exist "gamemodes\FRP.pwn" (
    echo ERROR: gamemodes\FRP.pwn was not found.
    pause
    exit /b 1
)

echo Compiling FRP.pwn...
"pawno\pawncc.exe" "gamemodes\FRP.pwn" -D"gamemodes" -i"pawno\include" -o"gamemodes\FRP.amx"
if errorlevel 1 (
    echo.
    echo COMPILATION FAILED. The old FRP.amx was kept.
    pause
    exit /b 1
)

echo.
echo Compilation successful.
echo Starting Prime Mobile RP...
echo.
if exist "samp03svr.exe" (
    start "Prime Mobile RP" /wait "samp03svr.exe"
) else if exist "samp03svr" (
    start "Prime Mobile RP" /wait "samp03svr"
) else (
    echo ERROR: SA-MP server executable was not found.
    pause
)
