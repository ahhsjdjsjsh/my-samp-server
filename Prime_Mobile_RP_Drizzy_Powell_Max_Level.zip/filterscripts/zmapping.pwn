/*

					__________
					\____    /  ____  _______ _______  __ __ ___  __
					  /     / _/ __ \ \_  __ \\_  __ \|  |  \\  \/ /
					 /     /_ \  ___/  |  | \/ |  | \/|  |  / \   /
					/_______ \ \___  > |__|    |__|   |____/   \_/
					        \/     \/
                                     zMapping
  								(Created by Zerruv)
  								
  								
  								FUCKING POGI MEN

*/

#define FILTERSCRIPT // for consistency
#include <a_samp>
#include <streamer>

public OnPlayerConnect(playerid)
{
	RemoveBuildingForPlayer(playerid, 4046, 1479.5234, -1852.6406, 24.5156, 0.25);
	RemoveBuildingForPlayer(playerid, 4047, 1531.6328, -1852.6406, 24.5156, 0.25);
	RemoveBuildingForPlayer(playerid, 4214, 1589.4531, -1817.5625, 22.2109, 0.25);
	RemoveBuildingForPlayer(playerid, 4217, 1449.2500, -1852.5703, 22.3672, 0.25);
	RemoveBuildingForPlayer(playerid, 4223, 1596.5547, -1817.2969, 21.0313, 0.25);
	RemoveBuildingForPlayer(playerid, 1266, 1482.0859, -1859.9688, 25.0391, 0.25);
	RemoveBuildingForPlayer(playerid, 4170, 1433.9531, -1844.4063, 21.4219, 0.25);
	RemoveBuildingForPlayer(playerid, 1226, 1483.4297, -1867.7188, 16.4219, 0.25);
	RemoveBuildingForPlayer(playerid, 1260, 1482.0859, -1859.9688, 25.0391, 0.25);
	RemoveBuildingForPlayer(playerid, 4004, 1479.5234, -1852.6406, 24.5156, 0.25);
	RemoveBuildingForPlayer(playerid, 1357, 1487.6953, -1848.1094, 12.8125, 0.25);
	RemoveBuildingForPlayer(playerid, 1372, 1486.2109, -1848.1250, 12.6641, 0.25);
	RemoveBuildingForPlayer(playerid, 1230, 1488.9219, -1848.2734, 12.9766, 0.25);
	RemoveBuildingForPlayer(playerid, 4171, 1503.3984, -1848.3359, 21.4609, 0.25);
	RemoveBuildingForPlayer(playerid, 4048, 1531.6328, -1852.6406, 24.5156, 0.25);
	RemoveBuildingForPlayer(playerid, 1226, 1593.9844, -1867.7188, 16.4219, 0.25);
	RemoveBuildingForPlayer(playerid, 4227, 1614.6328, -1862.2109, 14.0156, 0.25);
	RemoveBuildingForPlayer(playerid, 3988, 1596.5547, -1817.2969, 21.0313, 0.25);
	//LSPD
	RemoveBuildingForPlayer(playerid, 4057, 1479.5547, -1693.1406, 19.5781, 0.25);
	RemoveBuildingForPlayer(playerid, 4210, 1479.5625, -1631.4531, 12.0781, 0.25);
	RemoveBuildingForPlayer(playerid, 713, 1457.9375, -1620.6953, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 713, 1496.8672, -1707.8203, 13.4063, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1468.9844, -1713.5078, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1231, 1479.6953, -1716.7031, 15.6250, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1488.7656, -1713.7031, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1289, 1504.7500, -1711.8828, 13.5938, 0.25);
	RemoveBuildingForPlayer(playerid, 1258, 1445.0078, -1704.7656, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 1258, 1445.0078, -1692.2344, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 712, 1445.8125, -1650.0234, 22.2578, 0.25);
	RemoveBuildingForPlayer(playerid, 673, 1457.7266, -1710.0625, 12.3984, 0.25);
	RemoveBuildingForPlayer(playerid, 620, 1461.6563, -1707.6875, 11.8359, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1468.9844, -1704.6406, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 700, 1463.0625, -1701.5703, 13.7266, 0.25);
	RemoveBuildingForPlayer(playerid, 1231, 1479.6953, -1702.5313, 15.6250, 0.25);
	RemoveBuildingForPlayer(playerid, 673, 1457.5547, -1697.2891, 12.3984, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1468.9844, -1694.0469, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1231, 1479.3828, -1692.3906, 15.6328, 0.25);
	RemoveBuildingForPlayer(playerid, 4186, 1479.5547, -1693.1406, 19.5781, 0.25);
	RemoveBuildingForPlayer(playerid, 620, 1461.1250, -1687.5625, 11.8359, 0.25);
	RemoveBuildingForPlayer(playerid, 700, 1463.0625, -1690.6484, 13.7266, 0.25);
	RemoveBuildingForPlayer(playerid, 641, 1458.6172, -1684.1328, 11.1016, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1457.2734, -1666.2969, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1468.9844, -1682.7188, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 712, 1471.4063, -1666.1797, 22.2578, 0.25);
	RemoveBuildingForPlayer(playerid, 1231, 1479.3828, -1682.3125, 15.6328, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1458.2578, -1659.2578, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 712, 1449.8516, -1655.9375, 22.2578, 0.25);
	RemoveBuildingForPlayer(playerid, 1231, 1477.9375, -1652.7266, 15.6328, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1479.6094, -1653.2500, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1457.3516, -1650.5703, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1454.4219, -1642.4922, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1467.8516, -1646.5938, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1472.8984, -1651.5078, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1465.9375, -1639.8203, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1231, 1466.4688, -1637.9609, 15.6328, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1449.5938, -1635.0469, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1467.7109, -1632.8906, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1232, 1465.8906, -1629.9766, 15.5313, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1472.6641, -1627.8828, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1479.4688, -1626.0234, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 3985, 1479.5625, -1631.4531, 12.0781, 0.25);
	RemoveBuildingForPlayer(playerid, 4206, 1479.5547, -1639.6094, 13.6484, 0.25);
	RemoveBuildingForPlayer(playerid, 1232, 1465.8359, -1608.3750, 15.3750, 0.25);
	RemoveBuildingForPlayer(playerid, 1226, 1451.3359, -1596.7031, 16.4219, 0.25);
	RemoveBuildingForPlayer(playerid, 1226, 1471.3516, -1596.7031, 16.4219, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1488.7656, -1704.5938, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 700, 1494.2109, -1694.4375, 13.7266, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1488.7656, -1693.7344, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 620, 1496.9766, -1686.8516, 11.8359, 0.25);
	RemoveBuildingForPlayer(playerid, 641, 1494.1406, -1689.2344, 11.1016, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1488.7656, -1682.6719, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 712, 1480.6094, -1666.1797, 22.2578, 0.25);
	RemoveBuildingForPlayer(playerid, 712, 1488.2266, -1666.1797, 22.2578, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1486.4063, -1651.3906, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1491.3672, -1646.3828, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1493.1328, -1639.4531, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1486.1797, -1627.7656, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1280, 1491.2188, -1632.6797, 13.4531, 0.25);
	RemoveBuildingForPlayer(playerid, 1232, 1494.4141, -1629.9766, 15.5313, 0.25);
	RemoveBuildingForPlayer(playerid, 1232, 1494.3594, -1608.3750, 15.3750, 0.25);
	RemoveBuildingForPlayer(playerid, 1288, 1504.7500, -1705.4063, 13.5938, 0.25);
	RemoveBuildingForPlayer(playerid, 1287, 1504.7500, -1704.4688, 13.5938, 0.25);
	RemoveBuildingForPlayer(playerid, 1286, 1504.7500, -1695.0547, 13.5938, 0.25);
	RemoveBuildingForPlayer(playerid, 1285, 1504.7500, -1694.0391, 13.5938, 0.25);
	RemoveBuildingForPlayer(playerid, 673, 1498.9609, -1684.6094, 12.3984, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1504.1641, -1662.0156, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1504.7188, -1670.9219, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 620, 1503.1875, -1621.1250, 11.8359, 0.25);
	RemoveBuildingForPlayer(playerid, 673, 1501.2813, -1624.5781, 12.3984, 0.25);
	RemoveBuildingForPlayer(playerid, 673, 1498.3594, -1616.9688, 12.3984, 0.25);
	RemoveBuildingForPlayer(playerid, 712, 1508.4453, -1668.7422, 22.2578, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1505.6953, -1654.8359, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1508.5156, -1647.8594, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 625, 1513.2734, -1642.4922, 13.6953, 0.25);
	RemoveBuildingForPlayer(playerid, 1258, 1510.8906, -1607.3125, 13.6953, 0.25);
	return 1;
}

public OnFilterScriptInit()
{
	//Pershing Square
    CreateDynamicObject(18981, 1454.81, -1607.68, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(19378, 1438.04, -1601.92, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1437.89, -1724.30, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1447.40, -1724.24, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1456.83, -1724.21, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1466.08, -1724.15, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1475.49, -1724.19, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1485.06, -1724.24, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1494.49, -1724.34, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1503.99, -1724.17, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1513.62, -1724.09, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(18981, 1454.70, -1706.66, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1479.77, -1657.33, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(19378, 1521.45, -1600.46, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1523.17, -1724.21, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1520.19, -1713.71, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.53, -1703.29, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.51, -1693.22, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.58, -1682.89, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(18981, 1504.47, -1706.65, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1479.56, -1706.69, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1479.76, -1681.70, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1455.00, -1681.88, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1454.77, -1656.97, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1454.85, -1632.62, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1479.71, -1632.54, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1504.52, -1682.08, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1504.34, -1657.35, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(19378, 1437.84, -1713.89, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1437.73, -1703.64, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1437.89, -1693.30, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1437.80, -1683.17, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(18981, 1504.46, -1632.54, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1504.31, -1608.29, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(18981, 1479.64, -1607.63, 11.80,   0.00, 90.00, 0.00);
	CreateDynamicObject(19378, 1437.98, -1672.86, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1438.02, -1662.77, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1438.26, -1652.64, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1437.78, -1642.19, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1437.96, -1632.51, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1437.88, -1622.41, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1437.85, -1612.23, 12.18,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.63, -1672.64, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.66, -1662.15, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.66, -1651.79, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.67, -1641.41, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.42, -1631.16, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.37, -1620.98, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19378, 1521.37, -1610.92, 12.25,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1446.99, -1703.49, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.03, -1713.67, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19447, 1456.30, -1718.96, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1442.20, -1695.51, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1447.24, -1719.00, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1460.23, -1718.94, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1456.89, -1718.90, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1452.70, -1718.85, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1448.99, -1718.98, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1445.76, -1718.92, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1442.87, -1719.02, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1442.35, -1672.71, 11.78,   0.00, 0.00, -0.18);
	CreateDynamicObject(700, 1494.16, -1600.81, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1458.60, -1716.16, 12.26,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1444.65, -1714.98, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1445.00, -1693.60, 12.06,   0.00, 0.00, -0.06);
	CreateDynamicObject(19381, 1465.73, -1686.72, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19428, 1516.92, -1695.32, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.97, -1676.62, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1516.92, -1700.09, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.89, -1704.68, 11.36,   0.00, 0.00, 0.06);
	CreateDynamicObject(19381, 1511.99, -1703.24, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19428, 1516.92, -1704.02, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19381, 1466.45, -1602.79, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.54, -1703.32, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1512.00, -1713.74, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.55, -1695.52, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1512.00, -1695.56, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(700, 1514.40, -1693.32, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1517.03, -1677.05, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1470.80, -1709.02, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.67, -1687.59, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.61, -1693.67, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1488.71, -1704.99, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.65, -1699.37, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1442.72, -1602.34, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.64, -1705.61, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.64, -1711.90, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.64, -1718.50, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1499.43, -1692.79, 12.06,   0.00, 0.00, -0.06);
	CreateDynamicObject(700, 1513.83, -1716.45, 12.26,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1500.12, -1716.37, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1516.92, -1708.48, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1516.95, -1712.48, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.89, -1714.25, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1516.89, -1718.36, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1516.08, -1719.12, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1512.17, -1719.09, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1512.80, -1719.10, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1509.13, -1719.12, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1503.58, -1719.15, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1511.96, -1652.81, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1443.02, -1671.90, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1496.83, -1719.23, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19381, 1456.43, -1677.22, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1456.52, -1703.35, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19447, 1442.24, -1714.24, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1442.23, -1704.92, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(1231, 1470.88, -1681.86, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1461.37, -1718.21, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(19447, 1502.65, -1719.10, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1493.40, -1719.17, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1488.69, -1695.58, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.88, -1695.17, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1488.72, -1714.35, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1470.72, -1714.15, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1470.72, -1704.64, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1470.72, -1695.38, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1465.98, -1718.96, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1470.71, -1686.22, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1447.48, -1653.09, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1488.71, -1686.15, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1465.92, -1681.43, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1447.03, -1671.84, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1466.61, -1643.56, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1498.05, -1648.10, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1511.94, -1671.86, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19381, 1456.63, -1713.75, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1465.82, -1713.62, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1465.91, -1703.33, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1465.90, -1692.89, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1456.35, -1692.86, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1456.52, -1685.78, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1446.99, -1692.95, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.16, -1682.63, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.27, -1677.08, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.38, -1713.76, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.68, -1713.80, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.57, -1703.89, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.71, -1693.42, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.72, -1686.72, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1503.07, -1677.09, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.91, -1685.49, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1512.02, -1685.32, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19447, 1461.27, -1676.67, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1471.31, -1602.05, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1498.09, -1676.77, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1502.95, -1671.89, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1469.90, -1718.98, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1516.22, -1671.84, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19428, 1471.47, -1642.89, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1470.82, -1682.11, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1470.91, -1687.32, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1470.70, -1692.89, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1470.75, -1718.20, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1470.82, -1702.11, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1489.35, -1719.24, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1456.44, -1671.84, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1442.19, -1685.96, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1470.10, -1681.38, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1516.99, -1685.41, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1516.92, -1690.98, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1516.91, -1686.39, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1517.09, -1681.94, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1516.97, -1672.55, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1489.29, -1681.14, 11.78,   0.00, 0.00, 90.00);
	CreateDynamicObject(1231, 1488.48, -1681.65, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.45, -1693.88, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.39, -1705.40, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.59, -1718.37, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.01, -1717.88, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.11, -1708.85, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1470.77, -1702.02, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.24, -1692.99, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1487.99, -1597.56, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(19447, 1502.83, -1652.81, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1493.48, -1681.45, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1447.57, -1597.55, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1461.87, -1648.33, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1488.50, -1602.28, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1471.36, -1629.21, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1471.35, -1619.93, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1471.33, -1610.40, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1471.37, -1638.79, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.67, -1602.37, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1488.47, -1628.76, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1488.55, -1619.61, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1488.56, -1610.21, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1456.95, -1653.10, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1442.23, -1676.71, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1442.78, -1648.11, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1442.80, -1638.57, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1442.80, -1630.10, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1442.76, -1620.84, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1442.77, -1611.36, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1488.52, -1638.37, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.73, -1648.08, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.76, -1638.61, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.75, -1628.99, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.73, -1619.39, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1516.68, -1610.36, 11.36,   0.00, 0.00, 0.00);
	CreateDynamicObject(19447, 1493.33, -1643.27, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1493.12, -1597.48, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1502.62, -1597.47, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19381, 1512.22, -1677.27, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1511.73, -1647.54, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.96, -1647.45, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.61, -1647.87, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1466.30, -1633.12, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1466.50, -1622.90, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1456.75, -1633.10, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.43, -1633.08, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.63, -1623.00, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1456.97, -1622.79, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1466.54, -1612.80, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1457.02, -1612.41, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.61, -1612.73, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.51, -1602.96, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1456.87, -1602.86, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.50, -1617.34, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.44, -1602.43, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.72, -1602.71, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.43, -1607.08, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.10, -1607.24, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1511.95, -1602.75, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1511.76, -1607.07, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1511.84, -1617.18, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.46, -1617.50, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.48, -1627.79, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.66, -1627.56, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1493.42, -1637.88, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1502.99, -1637.76, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1512.02, -1637.91, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1511.89, -1627.72, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1466.33, -1638.32, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1447.65, -1643.30, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1456.81, -1643.34, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19381, 1456.87, -1647.62, 12.29,   0.00, 90.00, 90.00);
	CreateDynamicObject(19447, 1511.93, -1597.47, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1466.44, -1597.53, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(19447, 1457.01, -1597.54, 11.36,   0.00, 0.00, 90.00);
	CreateDynamicObject(1231, 1471.00, -1687.30, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.38, -1687.35, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.49, -1699.40, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.49, -1712.06, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(19428, 1488.60, -1681.94, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.47, -1642.59, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.42, -1636.69, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.41, -1630.08, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.42, -1624.43, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.53, -1616.67, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.54, -1605.23, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1488.45, -1597.98, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1471.37, -1603.51, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1471.34, -1609.43, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1471.49, -1617.19, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1471.49, -1624.02, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(19428, 1471.44, -1635.14, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(1231, 1487.97, -1641.92, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.28, -1636.46, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.00, -1630.10, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.12, -1624.32, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.58, -1642.52, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1488.18, -1604.78, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(19428, 1471.38, -1598.05, 11.78,   0.00, 0.00, 0.00);
	CreateDynamicObject(1231, 1488.13, -1616.62, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.45, -1597.97, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.54, -1603.22, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.34, -1609.44, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.65, -1617.19, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.59, -1623.77, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(1231, 1471.49, -1635.01, 14.39,   356.86, 0.00, 3.14);
	CreateDynamicObject(700, 1458.09, -1693.93, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1462.92, -1601.86, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1446.53, -1601.84, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1464.34, -1629.44, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1446.50, -1629.49, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1493.40, -1630.53, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1510.89, -1630.72, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(700, 1511.10, -1601.13, 12.06,   0.00, 0.00, 0.00);
	CreateDynamicObject(6965, 1480.01, -1663.56, 16.08,   0.00, 0.00, 359.70);
	CreateDynamicObject(1280, 1471.64, -1656.76, 12.59,   0.00, 0.00, 322.59);
	CreateDynamicObject(1280, 1488.56, -1670.38, 12.59,   0.00, 0.00, 141.82);
	CreateDynamicObject(1280, 1480.30, -1674.26, 12.59,   0.00, 0.00, 90.00);
	CreateDynamicObject(1280, 1480.95, -1702.59, 12.59,   0.00, 0.00, 180.00);
	CreateDynamicObject(1280, 1481.78, -1691.04, 12.59,   0.00, 0.00, 180.00);
	CreateDynamicObject(1280, 1480.85, -1712.09, 12.59,   0.00, 0.00, 180.00);
	CreateDynamicObject(1280, 1479.70, -1712.03, 12.59,   0.00, 0.00, 0.00);
	CreateDynamicObject(1280, 1480.06, -1702.64, 12.59,   0.00, 0.00, 0.00);
	CreateDynamicObject(1280, 1480.94, -1691.05, 12.59,   0.00, 0.00, 0.00);
	CreateDynamicObject(1280, 1482.26, -1682.10, 12.59,   0.00, 0.00, 180.00);
	CreateDynamicObject(1280, 1478.49, -1603.73, 12.59,   0.00, 0.00, 0.00);
	CreateDynamicObject(1280, 1469.08, -1663.77, 12.59,   0.00, 0.00, 357.90);
	CreateDynamicObject(1280, 1471.81, -1670.24, 12.59,   0.00, 0.00, 38.91);
	CreateDynamicObject(1280, 1479.90, -1652.54, 12.59,   0.00, 0.00, -90.00);
	CreateDynamicObject(1280, 1488.46, -1656.88, 12.59,   0.00, 0.00, 219.37);
	CreateDynamicObject(1280, 1481.58, -1682.03, 12.59,   0.00, 0.00, 0.00);
	CreateDynamicObject(1280, 1478.79, -1641.40, 12.59,   0.00, 0.00, 0.00);
	CreateDynamicObject(1280, 1478.89, -1628.07, 12.59,   0.00, 0.00, 0.00);
	CreateDynamicObject(1280, 1478.86, -1615.88, 12.59,   0.00, 0.00, 0.00);
	CreateDynamicObject(1280, 1490.86, -1663.07, 12.59,   0.00, 0.00, 182.99);
	CreateDynamicObject(1280, 1479.42, -1603.64, 12.59,   0.00, 0.00, 181.20);
	CreateDynamicObject(1280, 1479.63, -1641.50, 12.59,   0.00, 0.00, 179.91);
	CreateDynamicObject(1280, 1479.67, -1628.04, 12.59,   0.00, 0.00, 180.47);
	CreateDynamicObject(1280, 1479.62, -1615.94, 12.59,   0.00, 0.00, 180.47);
	CreateDynamicObject(970, 1479.63, -1718.79, 12.74,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1488.38, -1715.38, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1482.10, -1718.73, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1477.26, -1718.74, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1470.89, -1713.99, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1470.91, -1704.82, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1470.90, -1697.05, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1470.78, -1690.19, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1470.95, -1684.44, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1488.61, -1684.78, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1488.57, -1690.64, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1488.61, -1696.58, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1488.61, -1702.62, 12.70,   0.00, 0.00, 0.00);
	CreateDynamicObject(19127, 1488.52, -1708.89, 12.70,   0.00, 0.00, 0.00);

	//Simple SuperMarket
	CreateDynamicObject(2412,1728.90002441,-1636.80004883,19.20000076,0.00000000,0.00000000,0.00000000); //object(cj_detector) (1)
	CreateDynamicObject(2412,1725.69921875,-1636.89941406,19.20000076,0.00000000,0.00000000,0.00000000); //object(cj_detector) (2)
	CreateDynamicObject(1346,1710.30004883,-1599.40002441,13.89999962,0.00000000,0.00000000,84.00000000); //object(cj_phone_kiosk2) (1)
	CreateDynamicObject(1257,1706.69995117,-1599.50000000,13.80000019,0.00000000,0.00000000,265.50000000); //object(bustopm) (1)
	CreateDynamicObject(1215,1711.30004883,-1598.90002441,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(3858,1744.50000000,-1617.09960938,15.50000000,0.00000000,0.00000000,314.99450684); //object(ottosmash1) (1)
	CreateDynamicObject(3858,1744.50000000,-1632.50000000,15.50000000,0.00000000,0.00000000,314.99450684); //object(ottosmash1) (2)
	CreateDynamicObject(3858,1744.50000000,-1647.08996582,15.50000000,0.00000000,0.00000000,314.99450684); //object(ottosmash1) (3)
	CreateDynamicObject(3858,1744.50000000,-1661.68005371,15.50000000,0.00000000,0.00000000,314.99450684); //object(ottosmash1) (4)
	CreateDynamicObject(3858,1744.50000000,-1671.40002441,15.50000000,0.00000000,0.00000000,314.99450684); //object(ottosmash1) (5)
	CreateDynamicObject(3440,1744.19995117,-1669.00000000,14.89999962,0.00000000,0.00000000,0.00000000); //object(arptpillar01_lvs) (1)
	CreateDynamicObject(3440,1744.19995117,-1664.09997559,14.89999962,0.00000000,0.00000000,0.00000000); //object(arptpillar01_lvs) (2)
	CreateDynamicObject(3858,1737.19995117,-1679.50000000,15.50000000,0.00000000,0.00000000,225.00000000); //object(ottosmash1) (7)
	CreateDynamicObject(1536,1738.30004883,-1668.50000000,12.50000000,0.00000000,0.00000000,90.00000000); //object(gen_doorext15) (1)
	CreateDynamicObject(1536,1738.30004883,-1658.59997559,12.50000000,0.00000000,0.00000000,90.00000000); //object(gen_doorext15) (2)
	CreateDynamicObject(3811,1738.90002441,-1627.09997559,13.60000038,0.00000000,0.00000000,0.00000000); //object(sfx_winplant08) (1)
	CreateDynamicObject(3811,1738.90002441,-1677.59997559,13.60000038,0.00000000,0.00000000,0.00000000); //object(sfx_winplant08) (3)
	CreateDynamicObject(2253,1738.59997559,-1656.90002441,12.80000019,0.00000000,0.00000000,0.00000000); //object(plant_pot_22) (1)
	CreateDynamicObject(2253,1738.59997559,-1658.80004883,12.80000019,0.00000000,0.00000000,0.00000000); //object(plant_pot_22) (2)
	CreateDynamicObject(2253,1738.50000000,-1668.69995117,12.80000019,0.00000000,0.00000000,0.00000000); //object(plant_pot_22) (3)
	CreateDynamicObject(2253,1738.50000000,-1666.69995117,12.80000019,0.00000000,0.00000000,0.00000000); //object(plant_pot_22) (4)
	CreateDynamicObject(3859,1741.80004883,-1609.50000000,15.50000000,0.00000000,0.00000000,286.00000000); //object(ottosmash04) (2)
	CreateDynamicObject(3859,1736.57910156,-1609.39941406,15.50000000,0.00000000,0.00000000,285.99609375); //object(ottosmash04) (3)
	CreateDynamicObject(1215,1714.59997559,-1599.19995117,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1717.90002441,-1599.59997559,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1721.19995117,-1600.09997559,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1724.19995117,-1600.59997559,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1727.00000000,-1601.09997559,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1729.80004883,-1601.69995117,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1732.40002441,-1602.19995117,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1735.19995117,-1602.69995117,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1737.50000000,-1603.09997559,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1740.00000000,-1603.69995117,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1742.09997559,-1605.09997559,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1743.80004883,-1607.50000000,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1703.59997559,-1598.09997559,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1701.09997559,-1597.80004883,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(1215,1699.30004883,-1599.69995117,13.10000038,0.00000000,0.00000000,0.00000000); //object(bollardlight) (1)
	CreateDynamicObject(2626,1718.50000000,-1625.19995117,19.70000076,0.00000000,0.00000000,0.00000000); //object(cj_urb_counter) (1)
	CreateDynamicObject(2626,1725.90002441,-1625.19995117,19.70000076,0.00000000,0.00000000,0.00000000); //object(cj_urb_counter) (2)
	CreateDynamicObject(2620,1719.80004883,-1625.19995117,20.00000000,0.00000000,0.00000000,0.00000000); //object(cj_trainer_eris) (1)
	CreateDynamicObject(2621,1724.59997559,-1625.30004883,20.00000000,0.00000000,0.00000000,0.00000000); //object(cj_trainer_heat) (1)
	CreateDynamicObject(2424,1715.09997559,-1611.69995117,12.60000038,0.00000000,0.00000000,90.00000000); //object(cj_ff_conter_1) (1)
	CreateDynamicObject(2424,1729.40002441,-1611.80004883,12.60000038,0.00000000,0.00000000,269.99996948); //object(cj_ff_conter_1) (2)
	CreateDynamicObject(2422,1726.69995117,-1624.90002441,20.20000076,0.00000000,0.00000000,0.00000000); //object(cj_ff_till) (1)
	CreateDynamicObject(6986,1718.19995117,-1637.50000000,35.00000000,0.00000000,0.00000000,270.00000000); //object(vgngamblsign1) (1)
	CreateDynamicObject(6986,1735.69921875,-1637.09960938,35.00000000,0.00000000,0.00000000,90.00000000); //object(vgngamblsign1) (2)
	CreateDynamicObject(2714,1727.00000000,-1637.40002441,25.00000000,0.00000000,0.00000000,180.00000000); //object(cj_open_sign_2) (1)
	CreateDynamicObject(7290,1726.90002441,-1637.59997559,27.00000000,0.00000000,0.00000000,0.00000000); //object(casinoblock2_nt) (1)
	CreateDynamicObject(2764,1743.80004883,-1674.50000000,13.00000000,0.00000000,0.00000000,0.00000000); //object(cj_pizza_table03) (1)
	CreateDynamicObject(2748,1742.19995117,-1674.50000000,13.10000038,0.00000000,0.00000000,90.00000000); //object(cj_donut_chair2) (2)
	CreateDynamicObject(2748,1742.19995117,-1677.50000000,13.10000038,0.00000000,0.00000000,90.00000000); //object(cj_donut_chair2) (3)
	CreateDynamicObject(2764,1743.69995117,-1677.50000000,13.00000000,0.00000000,0.00000000,0.00000000); //object(cj_pizza_table03) (2)
	CreateDynamicObject(2746,1743.30004883,-1659.50000000,13.19999981,0.00000000,0.00000000,0.00000000); //object(cj_donut_chair) (1)
	CreateDynamicObject(2746,1743.30004883,-1655.90002441,13.19999981,0.00000000,0.00000000,0.00000000); //object(cj_donut_chair) (2)
	CreateDynamicObject(2764,1743.50000000,-1661.50000000,13.00000000,0.00000000,0.00000000,0.00000000); //object(cj_pizza_table03) (3)
	CreateDynamicObject(2764,1743.50000000,-1654.00000000,13.00000000,0.00000000,0.00000000,0.00000000); //object(cj_pizza_table03) (4)
	CreateDynamicObject(2637,1743.30004883,-1657.69995117,13.00000000,0.00000000,0.00000000,0.00000000); //object(cj_pizza_table2) (1)
	CreateDynamicObject(2010,1744.09997559,-1673.69995117,12.60000038,0.00000000,0.00000000,0.00000000); //object(nu_plant3_ofc) (1)
	CreateDynamicObject(2010,1744.19995117,-1678.30004883,12.60000038,0.00000000,0.00000000,0.00000000); //object(nu_plant3_ofc) (2)
	CreateDynamicObject(2240,1744.00000000,-1676.00000000,13.10000038,0.00000000,0.00000000,0.00000000); //object(plant_pot_8) (1)
	CreateDynamicObject(2240,1743.19995117,-1652.80004883,13.19999981,0.00000000,0.00000000,0.00000000); //object(plant_pot_8) (2)
	CreateDynamicObject(2245,1743.19995117,-1657.69995117,13.69999981,0.00000000,0.00000000,0.00000000); //object(plant_pot_11) (1)
	CreateDynamicObject(2222,1743.50000000,-1654.00000000,13.50000000,0.00000000,0.00000000,0.00000000); //object(rustyhigh) (1)
	CreateDynamicObject(2823,1743.40002441,-1661.30004883,13.39999962,0.00000000,0.00000000,0.00000000); //object(gb_kitchtakeway01) (1)
	CreateDynamicObject(2838,1743.80004883,-1677.59997559,13.42000008,0.00000000,0.00000000,0.00000000); //object(gb_takeaway03) (1)
	CreateDynamicObject(3115,1070.09997559,-290.60000610,78.30000305,0.00000000,0.00000000,0.00000000); //object(carrier_lift1_sfse) (4)
	CreateDynamicObject(3858,1699.59997559,-1610.09997559,15.50000000,0.00000000,0.00000000,314.99450684); //object(ottosmash1) (1)
	CreateDynamicObject(3858,1700.40002441,-1624.59997559,15.50000000,0.00000000,0.00000000,320.99450684); //object(ottosmash1) (1)
	CreateDynamicObject(3440,1699.69995117,-1617.40002441,14.89999962,0.00000000,0.00000000,0.00000000); //object(arptpillar01_lvs) (3)
	CreateDynamicObject(3440,1700.50000000,-1625.50000000,14.89999962,0.00000000,0.00000000,0.00000000); //object(arptpillar01_lvs) (4)
	CreateDynamicObject(3858,1708.59997559,-1621.90002441,15.50000000,0.00000000,0.00000000,314.99450684); //object(ottosmash1) (1)
	CreateDynamicObject(1432,1742.59997559,-1645.50000000,12.50000000,0.00000000,0.00000000,0.00000000); //object(dyn_table_2) (1)
	CreateDynamicObject(1432,1742.69995117,-1650.69995117,12.50000000,0.00000000,0.00000000,310.00000000); //object(dyn_table_2) (2)
	CreateDynamicObject(2864,1742.50000000,-1645.69995117,13.10000038,0.00000000,0.00000000,0.00000000); //object(gb_kitchplatecln04) (1)
	CreateDynamicObject(2863,1742.80004883,-1650.30004883,13.10000038,0.00000000,0.00000000,0.00000000); //object(gb_kitchplatecln03) (1)
	CreateDynamicObject(2851,1742.40002441,-1651.00000000,13.10000038,0.00000000,0.00000000,0.00000000); //object(gb_kitchdirt05) (1)
	CreateDynamicObject(15038,1743.69995117,-1648.30004883,13.19999981,0.00000000,0.00000000,0.00000000); //object(plant_pot_3_sv) (1)
	CreateDynamicObject(15038,1742.90002441,-1648.30004883,13.19999981,0.00000000,0.00000000,0.00000000); //object(plant_pot_3_sv) (2)
	CreateDynamicObject(15038,1742.09997559,-1648.30004883,13.19999981,0.00000000,0.00000000,0.00000000); //object(plant_pot_3_sv) (3)
	CreateDynamicObject(14804,1743.40002441,-1641.80004883,13.50000000,0.00000000,0.00000000,0.00000000); //object(bdups_plant) (1)
	CreateDynamicObject(14804,1739.40002441,-1641.90002441,13.50000000,0.00000000,0.00000000,0.00000000); //object(bdups_plant) (2)
	CreateDynamicObject(2773,1728.50000000,-1635.30004883,19.70000076,0.00000000,0.00000000,0.00000000); //object(cj_airprt_bar) (1)
	CreateDynamicObject(2773,1725.40002441,-1635.30004883,19.70000076,0.00000000,0.00000000,0.00000000); //object(cj_airprt_bar) (2)
	CreateDynamicObject(3801,1728.90002441,-1637.09997559,21.20000076,0.00000000,0.00000000,94.00000000); //object(sfx_lite04) (1)
	CreateDynamicObject(3801,1725.00000000,-1637.09997559,21.20000076,0.00000000,0.00000000,93.99902344); //object(sfx_lite04) (2)
	CreateDynamicObject(970,1699.19995117,-1657.59997559,34.00000000,0.00000000,0.00000000,90.00000000); //object(fencesmallb) (1)
	CreateDynamicObject(970,1699.19995117,-1661.69995117,34.00000000,0.00000000,0.00000000,90.00000000); //object(fencesmallb) (2)
	CreateDynamicObject(970,1699.69995117,-1666.19995117,34.00000000,0.00000000,0.00000000,90.00000000); //object(fencesmallb) (3)
	CreateDynamicObject(970,1699.69995117,-1669.30004883,34.00000000,0.00000000,0.00000000,90.00000000); //object(fencesmallb) (4)
	CreateDynamicObject(970,1699.19995117,-1673.59997559,34.00000000,0.00000000,0.00000000,90.00000000); //object(fencesmallb) (5)
	CreateDynamicObject(970,1699.19995117,-1675.69995117,34.00000000,0.00000000,0.00000000,90.00000000); //object(fencesmallb) (6)
	CreateDynamicObject(970,1703.30004883,-1679.59997559,34.00000000,0.00000000,0.00000000,180.00000000); //object(fencesmallb) (7)
	CreateDynamicObject(970,1707.40002441,-1679.59997559,34.00000000,0.00000000,0.00000000,179.99450684); //object(fencesmallb) (8)
	CreateDynamicObject(970,1711.50000000,-1679.59997559,34.00000000,0.00000000,0.00000000,179.99450684); //object(fencesmallb) (9)
	CreateDynamicObject(970,1715.59997559,-1679.59997559,34.00000000,0.00000000,0.00000000,179.99450684); //object(fencesmallb) (10)
	CreateDynamicObject(970,1719.69995117,-1679.59997559,34.00000000,0.00000000,0.00000000,180.24450684); //object(fencesmallb) (11)
	CreateDynamicObject(1214,1699.40002441,-1664.00000000,33.50000000,0.00000000,0.00000000,0.75000000); //object(bollard) (2)
	CreateDynamicObject(1214,1699.40002441,-1671.59997559,33.50000000,0.00000000,0.00000000,0.74707031); //object(bollard) (3)
	CreateDynamicObject(2395,1701.19995117,-1679.59997559,31.20000076,0.00000000,270.00000000,316.74981689); //object(cj_sports_wall) (1)
	CreateDynamicObject(3472,1722.19995117,-1620.59997559,15.00000000,0.00000000,0.00000000,0.00000000); //object(circuslampost03) (1)
	CreateDynamicObject(2946,1718.00000000,-1678.00000000,33.50000000,0.00000000,0.00000000,0.00000000); //object(cr_door_03) (1)
	CreateDynamicObject(2946,1718.00000000,-1674.80004883,33.50000000,0.00000000,359.00000000,180.00000000); //object(cr_door_03) (2)
	CreateDynamicObject(3644,2572.59960938,-1458.09960938,24.89999962,0.00000000,0.00000000,270.00000000); //object(idlebuild01_lax) (1)
	CreateDynamicObject(8324,2572.60009766,-1458.90002441,27.10000038,0.00000000,0.00000000,180.00000000); //object(vgsbboardsigns10) (1)
	CreateDynamicObject(8324,2572.59960938,-1458.89941406,22.00000000,0.00000000,0.00000000,179.99450684); //object(vgsbboardsigns10) (2)
	CreateDynamicObject(8324,2563.39941406,-1466.89941406,22.00000000,0.00000000,0.00000000,270.00000000); //object(vgsbboardsigns10) (3)
	CreateDynamicObject(8324,2563.30004883,-1478.30004883,22.00000000,0.00000000,0.00000000,270.00000000); //object(vgsbboardsigns10) (4)
	CreateDynamicObject(8324,2563.30004883,-1478.30004883,27.10000038,0.00000000,0.00000000,270.00000000); //object(vgsbboardsigns10) (5)
	CreateDynamicObject(8324,2563.39941406,-1466.89941406,27.10000038,0.00000000,0.00000000,270.00000000); //object(vgsbboardsigns10) (6)
	CreateDynamicObject(3498,2564.19921875,-1458.50000000,25.89999962,0.00000000,0.00000000,0.00000000); //object(wdpillar01_lvs) (1)
	CreateDynamicObject(17698,2565.89941406,-1466.00000000,25.89999962,0.00000000,0.00000000,0.00000000); //object(sweetshou1_lae2) (1)
	CreateDynamicObject(1498,2559.79980469,-1468.50000000,23.39999962,0.00000000,0.00000000,90.00000000); //object(gen_doorext03) (1)
	CreateDynamicObject(4100,2563.29980469,-1449.89941406,23.89999962,0.00000000,0.00000000,329.99633789); //object(meshfence1_lan) (1)
	CreateDynamicObject(1528,2564.09960938,-1452.50000000,25.00000000,0.00000000,0.00000000,0.00000000); //object(tag_seville) (1)
	CreateDynamicObject(947,2559.89941406,-1458.79980469,25.20000076,0.00000000,0.00000000,0.00000000); //object(bskballhub_lax01) (1)
	CreateDynamicObject(1946,2559.10009766,-1457.19995117,23.20000076,0.00000000,0.00000000,0.00000000); //object(baskt_ball_hi) (1)
	CreateDynamicObject(2674,2558.80004883,-1458.59997559,23.00000000,0.00000000,0.00000000,0.00000000); //object(proc_rubbish_2) (1)
	CreateDynamicObject(3594,2558.80004883,-1477.90002441,23.70000076,0.00000000,0.00000000,330.00000000); //object(la_fuckcar1) (1)
	CreateDynamicObject(1442,2558.50000000,-1450.90002441,23.50000000,0.00000000,0.00000000,0.00000000); //object(dyn_firebin0) (1)
	CreateDynamicObject(1462,2559.69995117,-1450.90002441,23.00000000,0.00000000,0.00000000,0.00000000); //object(dyn_woodpile) (1)
	CreateDynamicObject(1710,2561.10009766,-1451.30004883,23.00000000,0.00000000,0.00000000,310.00000000); //object(kb_couch07) (1)
	CreateDynamicObject(1578,2560.19995117,-1452.00000000,23.20000076,0.00000000,0.00000000,0.00000000); //object(drug_green) (1)
	CreateDynamicObject(17951,2557.80004883,-1462.19995117,24.00000000,0.00000000,0.00000000,0.00000000); //object(cjgaragedoor) (1)
	CreateDynamicObject(17951,2557.79980469,-1462.19921875,26.00000000,0.00000000,0.00000000,0.00000000); //object(cjgaragedoor) (2)
	//China town
	CreateDynamicObject(10031, 1612.18, -1841.80, 16.90, 0.00, 0.00, 0.00);
	CreateDynamicObject(10037, 1592.18, -1799.45, 13.40, 0.00, 0.00, 180.00);
	CreateDynamicObject(9595, 1425.75, -1853.41, 17.71, 0.00, 0.00, 270.00);
	CreateDynamicObject(8640, 1485.48, -1859.89, 13.33, 0.00, 180.00, 90.00);
	CreateDynamicObject(8640, 1485.49, -1859.84, 23.64, 0.00, 0.00, 90.00);
	CreateDynamicObject(10037, 1531.89, -1849.49, 18.87, 0.00, 0.00, 90.00);
	CreateDynamicObject(10037, 1531.83, -1849.42, 18.86, 0.00, 0.00, 270.00);
	CreateDynamicObject(10037, 1592.18, -1799.62, 13.40, 0.00, 0.00, 0.00);
	CreateDynamicObject(3471, 1498.50, -1859.95, 15.86, 0.00, 0.00, 270.00);
	CreateDynamicObject(3471, 1472.50, -1859.86, 15.86, 0.00, 0.00, 270.00);
	CreateDynamicObject(1536, 1592.88, -1861.90, 12.52, 0.00, 0.00, 0.00);
	CreateDynamicObject(8640, 1485.47, -1840.45, 13.33, 0.00, 180.00, 90.00);
	CreateDynamicObject(8640, 1485.49, -1840.42, 23.64, 0.00, 0.00, 90.00);
	CreateDynamicObject(3471, 1498.48, -1840.18, 15.86, 0.00, 0.00, 90.00);
	CreateDynamicObject(3471, 1472.42, -1840.16, 15.86, 0.00, 0.00, 90.00);
	CreateDynamicObject(2098, 1593.60, -1861.84, 14.45, 0.00, 0.00, 0.00);
	CreateDynamicObject(1342, 1496.99, -1853.08, 13.48, 0.00, 0.00, 0.00);
	CreateDynamicObject(1342, 1496.65, -1847.21, 13.48, 0.00, 0.00, 0.00);
	CreateDynamicObject(1342, 1473.28, -1846.98, 13.48, 0.00, 0.00, 180.00);
	CreateDynamicObject(1342, 1473.20, -1853.97, 13.48, 0.00, 0.00, 180.00);
	CreateDynamicObject(1570, 1480.20, -1844.09, 13.75, 0.00, 0.00, 62.00);
	CreateDynamicObject(1570, 1480.10, -1849.67, 13.75, 0.00, 0.00, 62.00);
	CreateDynamicObject(1570, 1479.50, -1854.60, 13.75, 0.00, 0.00, 62.00);
	CreateDynamicObject(1570, 1490.35, -1843.33, 13.75, 0.00, 0.00, 309.00);
	CreateDynamicObject(1570, 1490.39, -1850.46, 13.75, 0.00, 0.00, 309.00);
	CreateDynamicObject(1570, 1490.98, -1855.59, 13.75, 0.00, 0.00, 309.00);
	CreateDynamicObject(1342, 1484.78, -1841.84, 13.48, 0.00, 0.00, 90.00);
	CreateDynamicObject(1342, 1480.33, -1860.98, 13.48, 0.00, 0.00, 90.00);
	CreateDynamicObject(1342, 1488.29, -1860.96, 13.48, 0.00, 0.00, 90.00);
	CreateDynamicObject(1349, 1495.12, -1859.84, 13.10, 0.00, 0.00, 84.00);
	CreateDynamicObject(1349, 1490.28, -1846.59, 13.10, 0.00, 0.00, -47.00);
	CreateDynamicObject(1349, 1488.31, -1841.44, 13.10, 0.00, 0.00, 40.00);
	CreateDynamicObject(1568, 1484.91, -1850.29, 12.46, 0.00, 0.00, 0.00);
	CreateDynamicObject(1568, 1489.87, -1861.44, 12.46, 0.00, 0.00, 0.00);
	CreateDynamicObject(1568, 1478.93, -1861.44, 12.46, 0.00, 0.00, 0.00);
	CreateDynamicObject(1568, 1497.06, -1849.94, 12.46, 0.00, 0.00, 0.00);
	CreateDynamicObject(1568, 1473.15, -1850.73, 12.46, 0.00, 0.00, 0.00);
	CreateDynamicObject(7191, 1399.21, -1849.26, -0.53,   90.00, 0.00, 0.00);
	CreateDynamicObject(6057, 1454.66, -1851.63, 5.26, 0.00, 90.00, 90.00);
	CreateDynamicObject(11292, 1447.53, -1854.47, 24.40, 0.00, 0.00, 0.00);
	CreateDynamicObject(1536, 1444.52, -1856.09, 22.99, 0.00, 0.00, 0.00);
	CreateDynamicObject(9482, 1586.17, -1832.72, 15.39, 0.00, 0.00, 0.00);
	CreateDynamicObject(9482, 1604.62, -1832.48, 15.39, 0.00, 0.00, 0.00);
	CreateDynamicObject(9482, 1559.58, -1849.72, 15.67, 0.00, 0.00, 0.00);
	CreateDynamicObject(1536, 1559.53, -1851.02, 12.52, 0.00, 0.00, 90.00);
	CreateDynamicObject(1536, 1559.49, -1848.04, 12.52, 0.00, 0.00, 270.00);
	CreateDynamicObject(2098, 1559.48, -1849.56, 14.03, 0.00, 0.00, 90.00);
	CreateDynamicObject(10031, 1431.12, -1842.63, 17.51, 0.00, 0.00, 0.00);
	CreateDynamicObject(8640, 1409.73, -1872.73, 17.68, 0.00, 0.00, 0.00);
	CreateDynamicObject(8640, 1461.61, -1871.62, 18.17, 0.00, 0.00, 0.00);
	CreateDynamicObject(8640, 1511.11, -1872.22, 18.17, 0.00, 0.00, 0.00);
	CreateDynamicObject(8640, 1554.92, -1872.22, 17.89, 0.00, 0.00, 0.00);
	CreateDynamicObject(8640, 1616.86, -1852.84, 15.64, 0.00, 0.00, 90.00);
	CreateDynamicObject(1536, 1435.33, -1860.81, 12.46, 0.00, 0.00, 0.00);
	
    // Church interior
	CreateDynamicObject(9931,1947.54003906,-368.51269531,1108.01086426,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(church_sfe) (1)
	CreateDynamicObject(3976,1970.65722656,-341.23883057,1100.22949219,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(policest02_lan) (1)
	CreateDynamicObject(9931,1980.55761719,-368.51562500,1108.01086426,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(church_sfe) (2)
	CreateDynamicObject(3976,1962.70117188,-400.46679688,1109.52941895,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(policest02_lan) (2)
	CreateDynamicObject(11472,1964.78710938,-372.02050781,1089.22351074,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(des_swtstairs1) (1)
	CreateDynamicObject(11472,1963.28967285,-372.02139282,1089.22351074,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(des_swtstairs1) (2)
	CreateDynamicObject(11472,1964.04479980,-372.98049927,1089.46386719,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(des_swtstairs1) (3)
	CreateDynamicObject(2896,1959.29248047,-370.91723633,1093.34313965,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(casket_law) (1)
	CreateDynamicObject(11472,1962.66918945,-373.82989502,1087.66955566,90.00000000,180.00000000,270.00000000, .interiorid = 40); //object(des_swtstairs1) (4)
	CreateDynamicObject(11472,1965.41259766,-373.81991577,1087.66992188,90.00000000,180.00000000,90.00000000, .interiorid = 40); //object(des_swtstairs1) (5)
	CreateDynamicObject(970,1970.61437988,-368.20404053,1093.28039551,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (1)
	CreateDynamicObject(970,1968.51074219,-368.20703125,1093.28039551,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (2)
	CreateDynamicObject(970,1957.52185059,-368.25833130,1093.28039551,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (3)
	CreateDynamicObject(970,1959.61914062,-368.25585938,1093.28039551,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(6959,1963.97839355,-368.12149048,1072.75439453,90.00000000,0.00000000,0.25000000, .interiorid = 40); //object(vegasnbball1) (2)
	CreateDynamicObject(2960,1964.05883789,-348.98986816,1101.36645508,0.00000000,90.00000000,89.99450684, .interiorid = 40); //object(kmb_beam) (1)
	CreateDynamicObject(2960,1963.98291016,-349.00000000,1101.70666504,90.00000000,0.00000000,179.99450684, .interiorid = 40); //object(kmb_beam) (2)
	CreateDynamicObject(2960,1964.05871582,-348.99044800,1100.00585938,0.00000000,90.00000000,90.00000000, .interiorid = 40); //object(kmb_beam) (3)
	CreateDynamicObject(3872,1964.02685547,-346.40850830,1102.33020020,0.00000000,155.25000000,90.27026367, .interiorid = 40); //object(ws_floodbeams) (1)
	CreateDynamicObject(1667,1962.98828125,-370.41271973,1093.62292480,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(propwineglass1) (1)
	CreateDynamicObject(1664,1962.83520508,-370.42520142,1093.70104980,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(propwinebotl2) (1)
	CreateDynamicObject(2868,1965.95605469,-370.30142212,1093.53430176,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(gb_ornament03) (1)
	CreateDynamicObject(2869,1964.02185059,-373.78527832,1093.66992188,0.00000000,0.00000000,323.75000000, .interiorid = 40); //object(gb_ornament04) (1)
	CreateDynamicObject(2870,1965.26269531,-373.64062500,1093.66992188,0.00000000,0.00000000,350.03002930, .interiorid = 40); //object(gb_ornament05) (1)
	CreateDynamicObject(2270,1965.47998047,-352.47622681,1093.48364258,0.00000000,0.00000000,270.00000000, .interiorid = 40); //object(frame_wood_6) (1)
	CreateDynamicObject(2257,1964.05615234,-373.94995117,1095.86132812,0.00000000,0.00000000,180.00000000, .interiorid = 40); //object(frame_clip_4) (1)
	CreateDynamicObject(2271,1962.60437012,-352.58059692,1093.48803711,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(frame_wood_1) (1)
	CreateDynamicObject(2357,1964.05090332,-370.68905640,1093.12402344,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(dunc_dinning) (1)
	CreateDynamicObject(2808,1957.51367188,-364.26171875,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (1)
	CreateDynamicObject(2808,1959.68164062,-364.26171875,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (2)
	CreateDynamicObject(2808,1970.61328125,-364.26171875,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (3)
	CreateDynamicObject(2808,1968.44238281,-364.26171875,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (4)
	CreateDynamicObject(2808,1961.85546875,-364.26171875,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (5)
	CreateDynamicObject(2808,1966.27246094,-364.26171875,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2868,1962.14697266,-370.30624390,1093.53430176,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(gb_ornament03) (4)
	CreateDynamicObject(948,1966.09277344,-374.17285156,1092.72888184,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(plant_pot_10) (1)
	CreateDynamicObject(948,1961.96313477,-374.22888184,1092.72888184,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(plant_pot_10) (2)
	CreateDynamicObject(2894,1963.95080566,-370.94277954,1093.53430176,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(kmb_rhymesbook) (1)
	CreateDynamicObject(3462,1959.30407715,-374.06838989,1094.24255371,0.00000000,0.00000000,270.00000000, .interiorid = 40); //object(csrangel_lvs) (1)
	CreateDynamicObject(3462,1968.78125000,-374.06835938,1094.24255371,0.00000000,0.00000000,270.00000000, .interiorid = 40); //object(csrangel_lvs) (2)
	CreateDynamicObject(949,1956.02258301,-353.46194458,1095.83190918,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(plant_pot_4) (1)
	CreateDynamicObject(2946,1965.59985352,-349.21301270,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(cr_door_03) (2)
	CreateDynamicObject(2946,1962.47033691,-349.19955444,1091.94543457,0.00000000,0.00000000,270.00000000, .interiorid = 40); //object(cr_door_03) (3)
	CreateDynamicObject(2808,1970.60681152,-360.67248535,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1968.43054199,-360.67248535,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1966.25378418,-360.67248535,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1957.52233887,-360.67248535,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1959.69580078,-360.67248535,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1961.86865234,-360.67248535,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1957.51660156,-357.18194580,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1959.69250488,-357.18194580,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1961.86779785,-357.18194580,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1970.61279297,-357.18194580,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1968.43701172,-357.18194580,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(2808,1966.26782227,-357.18194580,1092.59191895,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(cj_pizza_chair4) (6)
	CreateDynamicObject(14705,1962.68139648,-373.67498779,1093.91894531,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(int2vase) (1)
	CreateDynamicObject(14410,1968.61401367,-349.16000366,1092.01757812,0.00000000,0.00000000,270.00000000, .interiorid = 40); //object(carter-stairs03) (1)
	CreateDynamicObject(11472,1971.98046875,-351.97091675,1092.19567871,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(des_swtstairs1) (6)
	CreateDynamicObject(11472,1971.98046875,-353.19616699,1092.19567871,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(des_swtstairs1) (7)
	CreateDynamicObject(14410,1959.47412109,-349.41287231,1092.01660156,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(carter-stairs03) (2)
	CreateDynamicObject(11472,1956.10046387,-351.96487427,1092.19567871,0.00000000,0.00000000,270.00000000, .interiorid = 40); //object(des_swtstairs1) (8)
	CreateDynamicObject(11472,1956.10046387,-353.19616699,1092.19567871,0.00000000,0.00000000,270.00000000, .interiorid = 40); //object(des_swtstairs1) (9)
	CreateDynamicObject(11472,1965.10974121,-347.94531250,1095.44091797,0.00000000,90.00000000,180.00000000, .interiorid = 40); //object(des_swtstairs1) (10)
	CreateDynamicObject(11472,1962.98315430,-347.94104004,1095.44018555,0.00000000,270.00000000,179.99450684, .interiorid = 40); //object(des_swtstairs1) (11)
	CreateDynamicObject(1698,1962.46606445,-352.53399658,1095.31420898,0.00000000,0.00000000,270.27026367, .interiorid = 40); //object(esc_step8) (1)
	CreateDynamicObject(1698,1962.87316895,-352.53399658,1095.53918457,0.00000000,0.00000000,270.26916504, .interiorid = 40); //object(esc_step8) (2)
	CreateDynamicObject(1698,1963.24682617,-352.53399658,1095.76416016,0.00000000,0.00000000,270.26916504, .interiorid = 40); //object(esc_step8) (3)
	CreateDynamicObject(1698,1965.60021973,-352.53399658,1095.31420898,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(esc_step8) (4)
	CreateDynamicObject(1698,1965.20434570,-352.53399658,1095.53918457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(esc_step8) (5)
	CreateDynamicObject(1698,1964.72375488,-352.53399658,1095.76416016,0.00000000,0.00000000,270.26916504, .interiorid = 40); //object(esc_step8) (6)
	CreateDynamicObject(970,1964.05688477,-353.88497925,1096.74243164,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(970,1959.94470215,-353.88497925,1095.74719238,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(970,1955.77246094,-353.88589478,1095.74719238,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(970,1968.17297363,-353.88497925,1095.74719238,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(970,1972.25000000,-353.88589478,1095.74719238,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(970,1959.97607422,-351.29064941,1095.74719238,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(970,1968.10302734,-351.29064941,1095.74719238,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(970,1965.96203613,-349.21618652,1096.74169922,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(970,1962.13757324,-349.21618652,1096.74243164,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(fencesmallb) (4)
	CreateDynamicObject(2887,1964.04821777,-349.34906006,1094.78955078,90.00000000,0.00000000,0.00000000, .interiorid = 40); //object(a51_spotbulb) (1)
	CreateDynamicObject(949,1971.95068359,-353.46038818,1095.83190918,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(plant_pot_4) (2)
	CreateDynamicObject(948,1965.68554688,-352.45767212,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(plant_pot_10) (1)
	CreateDynamicObject(948,1962.38427734,-352.45767212,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(plant_pot_10) (1)
	CreateDynamicObject(1742,1955.84399414,-353.83831787,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(med_bookshelf) (1)
	CreateDynamicObject(1742,1957.28173828,-353.83831787,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(med_bookshelf) (2)
	CreateDynamicObject(1742,1958.71166992,-353.83831787,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(med_bookshelf) (3)
	CreateDynamicObject(1742,1960.15112305,-353.83831787,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(med_bookshelf) (4)
	CreateDynamicObject(1742,1971.77673340,-353.83831787,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(med_bookshelf) (5)
	CreateDynamicObject(1742,1970.34277344,-353.83831787,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(med_bookshelf) (6)
	CreateDynamicObject(1742,1968.90930176,-353.83831787,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(med_bookshelf) (7)
	CreateDynamicObject(1742,1967.47534180,-353.83831787,1091.94543457,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(med_bookshelf) (8)
	CreateDynamicObject(949,1961.60729980,-354.34103394,1092.58166504,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(plant_pot_4) (3)
	CreateDynamicObject(949,1966.46325684,-354.34805298,1092.58166504,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(plant_pot_4) (4)
	CreateDynamicObject(1720,1970.09338379,-373.59497070,1092.72888184,0.00000000,0.00000000,180.00000000, .interiorid = 40); //object(rest_chair) (1)
	CreateDynamicObject(1720,1970.91198730,-373.58316040,1092.72888184,0.00000000,0.00000000,179.99450684, .interiorid = 40); //object(rest_chair) (2)
	CreateDynamicObject(741,1969.29675293,-369.22723389,1093.71252441,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(pot_01) (1)
	CreateDynamicObject(3440,1969.29125977,-370.86264038,1091.08007812,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(arptpillar01_lvs) (1)
	CreateDynamicObject(14455,1955.32812500,-348.54144287,1096.87585449,0.00000000,0.00000000,270.00000000, .interiorid = 40); //object(gs_bookcase) (1)
	CreateDynamicObject(14455,1972.78356934,-352.90487671,1096.86743164,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gs_bookcase) (2)
	CreateDynamicObject(2842,1964.51916504,-365.60891724,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (1)
	CreateDynamicObject(2842,1964.51843262,-363.77880859,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (2)
	CreateDynamicObject(2842,1964.51867676,-361.94879150,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (3)
	CreateDynamicObject(2842,1964.52172852,-360.12713623,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (4)
	CreateDynamicObject(2842,1964.52636719,-358.30560303,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (5)
	CreateDynamicObject(2842,1964.52600098,-356.47940063,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (6)
	CreateDynamicObject(2842,1964.52343750,-354.64611816,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (7)
	CreateDynamicObject(2842,1964.52136230,-352.82815552,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (8)
	CreateDynamicObject(2842,1964.51867676,-350.99310303,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (9)
	CreateDynamicObject(2842,1964.52026367,-349.16046143,1091.94543457,0.00000000,0.00000000,90.00000000, .interiorid = 40); //object(gb_bedrug04) (10)
	CreateDynamicObject(2833,1963.55749512,-369.65057373,1092.72888184,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(gb_livingrug02) (1)
	CreateDynamicObject(2834,1968.81579590,-372.52481079,1092.72888184,0.00000000,0.00000000,0.00000000, .interiorid = 40); //object(gb_livingrug03) (1)
	CreateDynamicObject(6959,1951.26586914,-360.22650146,1095.56030273,310.00000000,180.00000000,90.00000000, .interiorid = 40); //object(vegasnbball1) (1)
	CreateDynamicObject(6959,1976.87695312,-356.75421143,1095.51965332,310.00000000,180.00000000,270.00000000, .interiorid = 40); //object(vegasnbball1) (3)
	CreateDynamicObject(6959,1958.95715332,-378.23306274,1096.33813477,309.99572754,179.99450684,180.00000000, .interiorid = 40); //object(vegasnbball1) (4)

	// The Black Hand Restaurant
  	CreateDynamicObject(14623,222.30000000,314.16000000,960.51000000,0.00000000,0.00000000,36.00000000, .interiorid = 39); //
	CreateDynamicObject(10722,221.61000000,324.33000000,976.61000000,270.00000000,180.01000000,359.25000000, .interiorid = 39); //
	CreateDynamicObject(5737,228.51000000,284.75000000,960.95000000,0.00000000,0.00000000,90.50000000, .interiorid = 39); //
	CreateDynamicObject(5737,199.56000000,294.19000000,960.95000000,0.00000000,0.00000000,54.24000000, .interiorid = 39); //
	CreateDynamicObject(5737,192.14000000,311.96000000,960.95000000,0.00000000,0.00000000,16.49000000, .interiorid = 39); //
	CreateDynamicObject(5737,196.56000000,331.01000000,960.95000000,0.00000000,0.00000000,340.24000000, .interiorid = 39); //
	CreateDynamicObject(5737,245.93000000,295.11000000,960.95000000,0.00000000,0.00000000,128.50000000, .interiorid = 39); //
	CreateDynamicObject(5737,253.43000000,312.20000000,960.95000000,0.00000000,0.00000000,161.25000000, .interiorid = 39); //
	CreateDynamicObject(5737,248.32000000,331.52000000,960.95000000,0.00000000,0.00000000,201.73000000, .interiorid = 39); //
	CreateDynamicObject(5737,232.94000000,343.58000000,960.95000000,0.00000000,0.00000000,237.73000000, .interiorid = 39); //
	CreateDynamicObject(5737,214.07000000,344.72000000,960.95000000,0.00000000,0.00000000,271.73000000, .interiorid = 39); //
	CreateDynamicObject(5737,198.07000000,334.42000000,960.95000000,0.00000000,0.00000000,311.73000000, .interiorid = 39); //
	CreateDynamicObject(10153,257.69000000,299.55000000,953.19000000,0.00000000,0.00000000,22.00000000, .interiorid = 39); //
	CreateDynamicObject(10153,258.54000000,297.44000000,953.19000000,0.00000000,0.00000000,22.00000000, .interiorid = 39); //
	CreateDynamicObject(1649,234.71000000,312.37000000,956.63000000,0.00000000,0.00000000,253.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,227.82000000,325.41000000,956.63000000,0.00000000,0.00000000,326.20000000, .interiorid = 39); //
	CreateDynamicObject(1649,234.59000000,316.57000000,956.63000000,0.00000000,0.00000000,289.49000000, .interiorid = 39); //
	CreateDynamicObject(1649,233.37000000,308.64000000,956.63000000,0.00000000,0.00000000,245.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,230.80000000,305.27000000,956.63000000,0.00000000,0.00000000,217.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,227.93000000,303.26000000,956.63000000,0.00000000,0.00000000,213.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,224.00000000,301.98000000,956.63000000,0.00000000,0.00000000,181.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,216.56000000,303.11000000,956.63000000,0.00000000,0.00000000,143.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,220.53000000,301.87000000,956.63000000,0.00000000,0.00000000,181.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,216.55000000,303.11000000,956.63000000,0.00000000,0.00000000,323.98000000, .interiorid = 39); //
	CreateDynamicObject(1649,220.53000000,301.87000000,956.63000000,0.00000000,0.00000000,1.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,224.00000000,301.98000000,956.63000000,0.00000000,0.00000000,1.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,227.93000000,303.26000000,956.63000000,0.00000000,0.00000000,33.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,230.80000000,305.27000000,956.63000000,0.00000000,0.00000000,37.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,233.37000000,308.64000000,956.63000000,0.00000000,0.00000000,65.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,234.71000000,312.37000000,956.63000000,0.00000000,0.00000000,73.99000000, .interiorid = 39); //
	CreateDynamicObject(1649,234.58000000,316.57000000,956.63000000,0.00000000,0.00000000,109.49000000, .interiorid = 39); //
	CreateDynamicObject(1649,223.79000000,326.74000000,956.63000000,0.00000000,0.00000000,358.20000000, .interiorid = 39); //
	CreateDynamicObject(1649,220.53000000,326.85000000,956.63000000,0.00000000,0.00000000,358.20000000, .interiorid = 39); //
	CreateDynamicObject(1649,216.59000000,325.53000000,956.63000000,0.00000000,0.00000000,38.20000000, .interiorid = 39); //
	CreateDynamicObject(1649,213.17000000,322.90000000,956.63000000,0.00000000,0.00000000,38.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,210.83000000,319.41000000,956.63000000,0.00000000,0.00000000,74.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,209.91000000,316.17000000,956.63000000,0.00000000,0.00000000,74.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,209.99000000,312.00000000,956.63000000,0.00000000,0.00000000,108.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,209.99000000,312.00000000,956.63000000,0.00000000,0.00000000,288.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,209.91000000,316.17000000,956.63000000,0.00000000,0.00000000,254.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,210.83000000,319.41000000,956.63000000,0.00000000,0.00000000,254.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,213.17000000,322.90000000,956.63000000,0.00000000,0.00000000,218.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,216.59000000,325.53000000,956.63000000,0.00000000,0.00000000,218.19000000, .interiorid = 39); //
	CreateDynamicObject(1649,220.53000000,326.85000000,956.63000000,0.00000000,0.00000000,180.20000000, .interiorid = 39); //
	CreateDynamicObject(1649,223.81000000,326.75000000,956.63000000,0.00000000,0.00000000,178.20000000, .interiorid = 39); //
	CreateDynamicObject(1649,227.84000000,325.44000000,956.63000000,0.00000000,0.00000000,146.20000000, .interiorid = 39); //
	CreateDynamicObject(643,206.13000000,312.11000000,955.43000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(643,207.03000000,307.96000000,955.43000000,0.00000000,0.00000000,102.00000000, .interiorid = 39); //
	CreateDynamicObject(643,205.49000000,315.05000000,955.43000000,0.00000000,0.00000000,130.00000000, .interiorid = 39); //
	CreateDynamicObject(643,212.80000000,329.74000000,955.43000000,0.00000000,0.00000000,54.00000000, .interiorid = 39); //
	CreateDynamicObject(643,210.15000000,327.17000000,955.43000000,0.00000000,0.00000000,319.99000000, .interiorid = 39); //
	CreateDynamicObject(2637,212.11000000,315.90000000,955.37000000,0.00000000,0.00000000,74.50000000, .interiorid = 39); //
	CreateDynamicObject(2639,210.88000000,316.34000000,955.59000000,0.00000000,0.00000000,254.49000000, .interiorid = 39); //
	CreateDynamicObject(10722,222.82000000,302.18000000,976.64000000,270.00000000,180.00000000,179.25000000, .interiorid = 39); //
	CreateDynamicObject(2784,222.55000000,305.92000000,959.41000000,270.00000000,179.84000000,358.09000000, .interiorid = 39); //
	CreateDynamicObject(2784,228.10000000,310.33000000,959.41000000,270.00000000,180.04000000,88.30000000, .interiorid = 39); //
	CreateDynamicObject(2784,228.19000000,318.48000000,959.41000000,270.00000000,180.04000000,88.30000000, .interiorid = 39); //
	CreateDynamicObject(2784,223.76000000,324.03000000,959.41000000,270.00000000,180.04000000,178.30000000, .interiorid = 39); //
	CreateDynamicObject(2784,218.32000000,319.59000000,959.41000000,270.00000000,180.04000000,268.30000000, .interiorid = 39); //
	CreateDynamicObject(2784,218.12000000,311.42000000,959.41000000,270.00000000,180.03000000,268.29000000, .interiorid = 39); //
	CreateDynamicObject(2638,216.32000000,313.36000000,955.62000000,0.00000000,0.00000000,13.50000000, .interiorid = 39); //
	CreateDynamicObject(638,220.04000000,326.24000000,955.66000000,0.00000000,0.00000000,267.25000000, .interiorid = 39); //
	CreateDynamicObject(2639,210.33000000,314.34000000,955.59000000,0.00000000,0.00000000,254.49000000, .interiorid = 39); //
	CreateDynamicObject(2637,211.56000000,313.95000000,955.37000000,0.00000000,0.00000000,74.50000000, .interiorid = 39); //
	CreateDynamicObject(2639,213.50000000,322.53000000,955.60000000,0.00000000,0.00000000,218.00000000, .interiorid = 39); //
	CreateDynamicObject(2637,214.33000000,321.59000000,955.37000000,0.00000000,0.00000000,38.50000000, .interiorid = 39); //
	CreateDynamicObject(2639,216.90000000,325.12000000,955.59000000,0.00000000,0.00000000,218.00000000, .interiorid = 39); //
	CreateDynamicObject(2637,223.67000000,324.71000000,955.37000000,0.00000000,0.00000000,350.49000000, .interiorid = 39); //
	CreateDynamicObject(638,211.48000000,319.82000000,955.66000000,0.00000000,0.00000000,343.25000000, .interiorid = 39); //
	CreateDynamicObject(16151,222.62000000,297.49000000,955.26000000,0.00000000,0.00000000,270.00000000, .interiorid = 39); //
	CreateDynamicObject(1487,224.67000000,298.49000000,956.06000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(1487,224.48000000,298.36000000,956.06000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(1509,225.41000000,298.45000000,956.06000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(1510,223.53000000,298.37000000,955.87000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(1512,222.86000000,298.46000000,956.06000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(1520,225.99000000,297.88000000,955.89000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(1544,222.39000000,298.42000000,955.87000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2941,220.99000000,298.41000000,955.96000000,0.00000000,0.00000000,177.99000000, .interiorid = 39); //
	CreateDynamicObject(14651,207.65000000,320.22000000,957.00000000,0.00000000,0.00000000,342.00000000, .interiorid = 39); //
	CreateDynamicObject(2639,223.90000000,325.86000000,955.59000000,0.00000000,0.00000000,170.00000000, .interiorid = 39); //
	CreateDynamicObject(2639,225.85000000,325.51000000,955.59000000,0.00000000,0.00000000,169.99000000, .interiorid = 39); //
	CreateDynamicObject(2637,217.69000000,324.04000000,955.37000000,0.00000000,0.00000000,38.49000000, .interiorid = 39); //
	CreateDynamicObject(2637,219.64000000,320.60000000,955.37000000,0.00000000,0.00000000,308.73000000, .interiorid = 39); //
	CreateDynamicObject(2637,225.65000000,324.39000000,955.37000000,0.00000000,0.00000000,350.49000000, .interiorid = 39); //
	CreateDynamicObject(2639,216.21000000,317.72000000,955.59000000,0.00000000,0.00000000,308.99000000, .interiorid = 39); //
	CreateDynamicObject(2638,218.39000000,319.51000000,955.62000000,0.00000000,0.00000000,309.25000000, .interiorid = 39); //
	CreateDynamicObject(2639,220.67000000,321.37000000,955.59000000,0.00000000,0.00000000,128.49000000, .interiorid = 39); //
	CreateDynamicObject(2637,217.15000000,318.45000000,955.37000000,0.00000000,0.00000000,308.73000000, .interiorid = 39); //
	CreateDynamicObject(2639,215.71000000,316.10000000,955.59000000,0.00000000,0.00000000,194.23000000, .interiorid = 39); //
	CreateDynamicObject(2637,215.84000000,314.88000000,955.37000000,0.00000000,0.00000000,13.73000000, .interiorid = 39); //
	CreateDynamicObject(2637,216.59000000,311.83000000,955.37000000,0.00000000,0.00000000,13.72000000, .interiorid = 39); //
	CreateDynamicObject(2639,216.94000000,310.72000000,955.59000000,0.00000000,0.00000000,13.98000000, .interiorid = 39); //
	CreateDynamicObject(2639,220.63000000,302.56000000,955.59000000,0.00000000,0.00000000,353.98000000, .interiorid = 39); //
	CreateDynamicObject(2639,218.57000000,302.77000000,955.59000000,0.00000000,0.00000000,353.97000000, .interiorid = 39); //
	CreateDynamicObject(2637,220.82000000,303.68000000,955.37000000,0.00000000,0.00000000,353.72000000, .interiorid = 39); //
	CreateDynamicObject(2637,218.79000000,303.90000000,955.37000000,0.00000000,0.00000000,353.72000000, .interiorid = 39); //
	CreateDynamicObject(2639,218.76000000,307.36000000,955.59000000,0.00000000,0.00000000,287.98000000, .interiorid = 39); //
	CreateDynamicObject(2637,219.90000000,307.73000000,955.37000000,0.00000000,0.00000000,107.72000000, .interiorid = 39); //
	CreateDynamicObject(2638,221.47000000,308.24000000,955.62000000,0.00000000,0.00000000,287.75000000, .interiorid = 39); //
	CreateDynamicObject(2637,223.06000000,308.69000000,955.37000000,0.00000000,0.00000000,107.72000000, .interiorid = 39); //
	CreateDynamicObject(2638,224.53000000,309.23000000,955.62000000,0.00000000,0.00000000,287.74000000, .interiorid = 39); //
	CreateDynamicObject(2637,224.17000000,312.89000000,955.37000000,0.00000000,0.00000000,109.72000000, .interiorid = 39); //
	CreateDynamicObject(2639,227.18000000,310.03000000,955.59000000,0.00000000,0.00000000,107.98000000, .interiorid = 39); //
	CreateDynamicObject(2639,228.30000000,311.34000000,955.59000000,0.00000000,0.00000000,353.98000000, .interiorid = 39); //
	CreateDynamicObject(2637,228.43000000,312.48000000,955.37000000,0.00000000,0.00000000,173.72000000, .interiorid = 39); //
	CreateDynamicObject(2638,228.56000000,314.04000000,955.62000000,0.00000000,0.00000000,353.74000000, .interiorid = 39); //
	CreateDynamicObject(2637,228.82000000,315.73000000,955.37000000,0.00000000,0.00000000,173.72000000, .interiorid = 39); //
	CreateDynamicObject(2639,228.91000000,316.91000000,955.59000000,0.00000000,0.00000000,173.98000000, .interiorid = 39); //
	CreateDynamicObject(2639,222.20000000,321.81000000,955.59000000,0.00000000,0.00000000,258.49000000, .interiorid = 39); //
	CreateDynamicObject(2637,223.33000000,321.52000000,955.37000000,0.00000000,0.00000000,258.73000000, .interiorid = 39); //
	CreateDynamicObject(2638,224.92000000,321.25000000,955.62000000,0.00000000,0.00000000,259.00000000, .interiorid = 39); //
	CreateDynamicObject(2637,226.54000000,320.90000000,955.37000000,0.00000000,0.00000000,258.72000000, .interiorid = 39); //
	CreateDynamicObject(2639,227.71000000,320.78000000,955.59000000,0.00000000,0.00000000,78.48000000, .interiorid = 39); //
	CreateDynamicObject(638,224.12000000,302.51000000,955.66000000,0.00000000,0.00000000,271.25000000, .interiorid = 39); //
	CreateDynamicObject(2639,227.30000000,303.43000000,955.59000000,0.00000000,0.00000000,35.98000000, .interiorid = 39); //
	CreateDynamicObject(2637,226.70000000,304.36000000,955.37000000,0.00000000,0.00000000,35.72000000, .interiorid = 39); //
	CreateDynamicObject(638,232.75000000,308.46000000,955.66000000,0.00000000,0.00000000,337.24000000, .interiorid = 39); //
	CreateDynamicObject(2639,230.92000000,305.95000000,955.59000000,0.00000000,0.00000000,37.97000000, .interiorid = 39); //
	CreateDynamicObject(2637,230.26000000,306.84000000,955.37000000,0.00000000,0.00000000,37.72000000, .interiorid = 39); //
	CreateDynamicObject(2639,233.77000000,312.26000000,955.59000000,0.00000000,0.00000000,73.97000000, .interiorid = 39); //
	CreateDynamicObject(2639,234.32000000,314.19000000,955.59000000,0.00000000,0.00000000,73.97000000, .interiorid = 39); //
	CreateDynamicObject(2637,233.26000000,314.50000000,955.37000000,0.00000000,0.00000000,73.72000000, .interiorid = 39); //
	CreateDynamicObject(2637,232.69000000,312.56000000,955.37000000,0.00000000,0.00000000,73.71000000, .interiorid = 39); //
	CreateDynamicObject(2639,225.23000000,313.29000000,955.59000000,0.00000000,0.00000000,109.97000000, .interiorid = 39); //
	CreateDynamicObject(2637,226.12000000,309.61000000,955.37000000,0.00000000,0.00000000,107.72000000, .interiorid = 39); //
	CreateDynamicObject(2638,222.86000000,312.49000000,955.62000000,0.00000000,0.00000000,289.74000000, .interiorid = 39); //
	CreateDynamicObject(2637,221.02000000,311.87000000,955.37000000,0.00000000,0.00000000,109.72000000, .interiorid = 39); //
	CreateDynamicObject(2639,219.91000000,311.43000000,955.59000000,0.00000000,0.00000000,289.98000000, .interiorid = 39); //
	CreateDynamicObject(2639,224.97000000,317.30000000,955.59000000,0.00000000,0.00000000,111.97000000, .interiorid = 39); //
	CreateDynamicObject(2637,223.89000000,316.94000000,955.37000000,0.00000000,0.00000000,111.72000000, .interiorid = 39); //
	CreateDynamicObject(2638,222.34000000,316.28000000,955.62000000,0.00000000,0.00000000,291.74000000, .interiorid = 39); //
	CreateDynamicObject(2637,220.83000000,315.75000000,955.37000000,0.00000000,0.00000000,111.72000000, .interiorid = 39); //
	CreateDynamicObject(2639,219.69000000,315.27000000,955.59000000,0.00000000,0.00000000,291.97000000, .interiorid = 39); //
	CreateDynamicObject(2784,225.69000000,319.03000000,959.69000000,358.00000000,180.00000000,62.26000000, .interiorid = 39); //
	CreateDynamicObject(2784,221.34000000,310.98000000,959.69000000,357.99000000,179.99000000,61.51000000, .interiorid = 39); //
	CreateDynamicObject(2784,221.40000000,319.28000000,959.69000000,357.99000000,179.99000000,114.25000000, .interiorid = 39); //
	CreateDynamicObject(2784,225.26000000,310.51000000,959.69000000,357.99000000,179.99000000,114.25000000, .interiorid = 39); //
	CreateDynamicObject(2796,210.79000000,300.42000000,957.77000000,0.00000000,0.00000000,324.00000000, .interiorid = 39); //
	CreateDynamicObject(1536,210.02000000,300.95000000,954.96000000,0.00000000,0.00000000,324.00000000, .interiorid = 39); //
	CreateDynamicObject(3467,228.59000000,320.41000000,955.67000000,0.00000000,0.00000000,312.00000000, .interiorid = 39); //
	CreateDynamicObject(1778,208.38000000,302.49000000,954.96000000,0.00000000,0.00000000,240.00000000, .interiorid = 39); //
	CreateDynamicObject(2718,224.71000000,333.25000000,958.27000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2815,234.45000000,317.03000000,957.07000000,270.25000000,0.00000000,289.25000000, .interiorid = 39); //
	CreateDynamicObject(2815,234.52000000,315.93000000,957.04000000,270.25000000,0.00000000,109.75000000, .interiorid = 39); //
	CreateDynamicObject(2257,233.17000000,308.31000000,956.99000000,0.00000000,0.00000000,246.00000000, .interiorid = 39); //
	CreateDynamicObject(2257,233.25000000,308.26000000,956.99000000,0.00000000,0.00000000,65.99000000, .interiorid = 39); //
	CreateDynamicObject(2255,227.58000000,303.63000000,957.00000000,0.00000000,0.00000000,213.25000000, .interiorid = 39); //
	CreateDynamicObject(2255,228.29000000,302.92000000,957.00000000,0.00000000,0.00000000,33.49000000, .interiorid = 39); //
	CreateDynamicObject(2256,216.82000000,302.99000000,957.08000000,0.00000000,0.00000000,143.75000000, .interiorid = 39); //
	CreateDynamicObject(2256,216.76000000,302.91000000,957.08000000,0.00000000,0.00000000,323.75000000, .interiorid = 39); //
	CreateDynamicObject(2258,209.83000000,312.42000000,956.84000000,0.00000000,0.00000000,288.25000000, .interiorid = 39); //
	CreateDynamicObject(2258,209.88000000,312.43000000,956.84000000,0.00000000,0.00000000,108.25000000, .interiorid = 39); //
	CreateDynamicObject(2266,211.35000000,319.41000000,956.47000000,0.00000000,0.00000000,73.50000000, .interiorid = 39); //
	CreateDynamicObject(2266,210.36000000,319.75000000,956.47000000,0.00000000,0.00000000,253.50000000, .interiorid = 39); //
	CreateDynamicObject(2276,220.26000000,326.34000000,956.96000000,0.00000000,0.00000000,359.00000000, .interiorid = 39); //
	CreateDynamicObject(2276,220.32000000,327.34000000,956.96000000,0.00000000,0.00000000,180.24000000, .interiorid = 39); //
	CreateDynamicObject(2281,227.87000000,324.77000000,956.67000000,0.00000000,0.25000000,326.25000000, .interiorid = 39); //
	CreateDynamicObject(2281,228.46000000,325.61000000,956.67000000,0.00000000,0.25000000,146.25000000, .interiorid = 39); //
	CreateDynamicObject(1367,208.04000000,304.21000000,955.61000000,0.00000000,0.00000000,110.00000000, .interiorid = 39); //
	CreateDynamicObject(1367,228.40000000,324.35000000,955.61000000,0.00000000,0.00000000,326.00000000, .interiorid = 39); //
	CreateDynamicObject(1367,233.83000000,317.14000000,955.61000000,0.00000000,0.00000000,290.00000000, .interiorid = 39); //
	CreateDynamicObject(1367,215.96000000,304.12000000,955.61000000,0.00000000,0.00000000,146.00000000, .interiorid = 39); //
	CreateDynamicObject(1367,210.68000000,311.47000000,955.61000000,0.00000000,0.00000000,110.00000000, .interiorid = 39); //
	CreateDynamicObject(3920,220.57000000,296.86000000,958.40000000,0.00000000,0.00000000,1.00000000, .interiorid = 39); //
	CreateDynamicObject(626,240.38000000,318.19000000,957.02000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(626,238.36000000,323.86000000,957.01000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(628,230.25000000,323.17000000,956.96000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(628,233.32000000,319.03000000,956.96000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(628,214.38000000,305.38000000,956.96000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(628,211.47000000,309.68000000,956.96000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(633,217.12000000,298.06000000,955.96000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(640,239.85000000,310.25000000,955.66000000,0.00000000,0.00000000,340.00000000, .interiorid = 39); //
	CreateDynamicObject(640,231.65000000,329.96000000,955.66000000,0.00000000,0.00000000,58.00000000, .interiorid = 39); //
	CreateDynamicObject(949,238.76000000,317.72000000,955.60000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(949,236.83000000,323.22000000,955.60000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2245,240.29000000,316.21000000,955.27000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2245,236.66000000,325.46000000,955.28000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2245,240.33000000,317.37000000,955.27000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2245,239.86000000,316.80000000,955.27000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2245,239.40000000,317.53000000,955.27000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2245,237.71000000,324.70000000,955.27000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2245,237.19000000,324.06000000,955.27000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2245,236.93000000,324.71000000,955.27000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2345,224.16000000,326.73000000,958.03000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(2345,209.75000000,315.62000000,958.03000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(3920,232.09000000,329.30000000,958.40000000,0.00000000,0.00000000,337.00000000, .interiorid = 39); //
	CreateDynamicObject(9812,239.93000000,296.45000000,961.48000000,0.00000000,0.00000000,302.00000000, .interiorid = 39); //
	CreateDynamicObject(9812,213.58000000,305.26000000,956.15000000,0.00000000,0.00000000,328.00000000, .interiorid = 39); //
	CreateDynamicObject(1594,235.14000000,303.57000000,955.44000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(1594,232.92000000,301.64000000,955.44000000,0.00000000,0.00000000,336.00000000, .interiorid = 39); //
	CreateDynamicObject(1594,230.33000000,299.74000000,955.44000000,0.00000000,0.00000000,27.99000000, .interiorid = 39); //
	CreateDynamicObject(949,221.25000000,322.07000000,955.60000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(949,228.09000000,310.25000000,955.60000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(949,215.12000000,317.33000000,955.60000000,0.00000000,0.00000000,0.00000000, .interiorid = 39); //
	CreateDynamicObject(1523,217.55000000,333.12000000,954.91000000,0.00000000,0.00000000,1.70000000, .interiorid = 39); //
	CreateDynamicObject(1523,220.60000000,333.27000000,954.91000000,0.00000000,0.00000000,181.70000000, .interiorid = 39); //
	CreateDynamicObject(1557,239.22000000,322.99000000,955.70000000,0.00000000,0.00000000,292.00000000, .interiorid = 39); //
	CreateDynamicObject(1557,240.45000000,319.92000000,955.70000000,0.00000000,0.00000000,112.00000000, .interiorid = 39); //

	// The Black Hand Club
	CreateDynamicObject(18018, 1497.58984375, -1820.1455078125, 821.96350097656, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (int_bars) (1)
	CreateDynamicObject(14399, 1489.896484375, -1821.65625, 821.77600097656, 0.000000, 0.000000, 270.16479492188, .interiorid = 38); //object (bar2) (1)
	CreateDynamicObject(14463, 1516.4954833984, -1798.5234375, 827.08135986328, 0.000000, 0.000000, 268.68994140625, .interiorid = 38); //object (gs_barstuff) (1)
	CreateDynamicObject(1665, 1491.9964599609, -1820.84765625, 823.16143798828, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propashtray1) (1)
	CreateDynamicObject(18077, 1495.2956542969, -1815.2360839844, 822.52703857422, 0.000000, 0.000000, 181.75561523438, .interiorid = 38); //object (din_donut_furn) (1)
	CreateDynamicObject(2270, 1514.6025390625, -1814.474609375, 826.29425048828, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (frame_wood_6) (1)
	CreateDynamicObject(1703, 1502.3597412109, -1812.2196044922, 824.40100097656, 0.000000, 0.000000, 89.325012207031, .interiorid = 38); //object (kb_couch02) (1)
	CreateDynamicObject(1703, 1506.1396484375, -1813.2421875, 824.40100097656, 0.000000, 0.000000, 180.14831542969, .interiorid = 38); //object (kb_couch02) (2)
	CreateDynamicObject(1703, 1504.0224609375, -1808.8084716797, 824.40100097656, 0.000000, 0.000000, 0.029327392578125, .interiorid = 38); //object (kb_couch02) (4)
	CreateDynamicObject(5992, 1506.4278564453, -1844.7957763672, 825.32800292969, 0.000000, 0.000000, 89.780029296875, .interiorid = 38); //object (ltsreg01_lawn) (1)
	CreateDynamicObject(5992, 1504.5278320313, -1844.7775878906, 825.32800292969, 0.000000, 0.000000, 89.774780273438, .interiorid = 38); //object (ltsreg01_lawn) (2)
	CreateDynamicObject(5992, 1502.6595458984, -1844.7598876953, 825.32800292969, 0.000000, 0.000000, 89.774780273438, .interiorid = 38); //object (ltsreg01_lawn) (3)
	CreateDynamicObject(5992, 1500.7790527344, -1844.736328125, 825.32800292969, 0.000000, 0.000000, 89.774780273438, .interiorid = 38); //object (ltsreg01_lawn) (4)
	CreateDynamicObject(5992, 1498.9001464844, -1844.7409667969, 825.32800292969, 0.000000, 0.000000, 89.774780273438, .interiorid = 38); //object (ltsreg01_lawn) (5)
	CreateDynamicObject(5992, 1497.0131835938, -1844.7376708984, 825.32800292969, 0.000000, 0.000000, 89.774780273438, .interiorid = 38); //object (ltsreg01_lawn) (6)
	CreateDynamicObject(2780, 1496.857421875, -1821.1115722656, 826.68127441406, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (cj_smoke_mach) (1)
	CreateDynamicObject(13656, 1482.2108154297, -1834.4527587891, 790.13385009766, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (fuckknows) (1)
	CreateDynamicObject(3525, 1487.162109375, -1824.7163085938, 824.255859375, 0.000000, 0.75, 91.590026855469, .interiorid = 38); //object (exbrtorch01) (1)
	CreateDynamicObject(3525, 1487.12890625, -1822.0958251953, 824.255859375, 0.000000, 0.7470703125, 91.587524414063, .interiorid = 38); //object (exbrtorch01) (2)
	CreateDynamicObject(1491, 1517.1494140625, -1813.7041015625, 824.93395996094, 0.000000, 0.000000, 180.087890625, .interiorid = 38); //object (gen_doorint01) (1)
	CreateDynamicObject(1649, 1513.6173095703, -1820.0711669922, 827.34765625, 0.000000, 0.25, 269.68994140625, .interiorid = 38); //object (wglasssmash) (1)
	CreateDynamicObject(1649, 1513.4990234375, -1819.7548828125, 826.30383300781, 0.000000, 0.2471923828125, 90.318603515625, .interiorid = 38); //object (wglasssmash) (2)
	CreateDynamicObject(1649, 1513.8265380859, -1820.1916503906, 826.57061767578, 0.000000, 0.2471923828125, 90.325988769531, .interiorid = 38); //object (wglasssmash) (3)
	CreateDynamicObject(1649, 1513.6827392578, -1820.0108642578, 825.73486328125, 0.000000, 359.99719238281, 270.61407470703, .interiorid = 38); //object (wglasssmash) (4)
	CreateDynamicObject(1509, 1486.94921875, -1813.1239013672, 823.85809326172, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (dyn_wine_3) (1)
	CreateDynamicObject(1487, 1486.94921875, -1812.3529052734, 823.88732910156, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (dyn_wine_1) (1)
	CreateDynamicObject(1541, 1491.36328125, -1819.1094970703, 823.33544921875, 0.000000, 0.0150146484375, 90.385009765625, .interiorid = 38); //object (cj_beer_taps_1) (1)
	CreateDynamicObject(1551, 1490.5705566406, -1821.6905517578, 823.39123535156, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (dyn_wine_big) (1)
	CreateDynamicObject(1551, 1492.0013427734, -1814.4377441406, 823.39123535156, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (dyn_wine_big) (2)
	CreateDynamicObject(1665, 1491.8186035156, -1819.5059814453, 823.16143798828, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propashtray1) (2)
	CreateDynamicObject(1665, 1491.77734375, -1818.1010742188, 823.16143798828, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propashtray1) (3)
	CreateDynamicObject(1665, 1491.7733154297, -1816.5283203125, 823.16143798828, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propashtray1) (4)
	CreateDynamicObject(1665, 1491.724609375, -1815.3297119141, 823.16143798828, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propashtray1) (5)
	CreateDynamicObject(1665, 1491.6629638672, -1813.1821289063, 823.16143798828, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propashtray1) (6)
	CreateDynamicObject(1667, 1506.2225341797, -1812.9118652344, 825.41821289063, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propwineglass1) (1)
	CreateDynamicObject(1669, 1504.0534667969, -1813.1342773438, 825.50634765625, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propwinebotl1) (1)
	CreateDynamicObject(1455, 1502.6872558594, -1812.4241943359, 825.4013671875, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (dyn_glass) (1)
	CreateDynamicObject(3534, 1510.2590332031, -1816.6885986328, 826.97711181641, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (trdlamp01) (1)
	CreateDynamicObject(3534, 1510.2028808594, -1824.9219970703, 826.97711181641, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (trdlamp01) (2)
	CreateDynamicObject(3534, 1496.1624755859, -1816.7270507813, 826.97711181641, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (trdlamp01) (3)
	CreateDynamicObject(3534, 1496.0091552734, -1824.9686279297, 826.97711181641, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (trdlamp01) (4)
	CreateDynamicObject(1557, 1496.0382080078, -1810.0864257813, 822, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (gen_doorext19) (1)
	CreateDynamicObject(1557, 1499.0970458984, -1810.0379638672, 822, 0.000000, 0.000000, 181.17504882813, .interiorid = 38); //object (gen_doorext19) (2)
	CreateDynamicObject(1548, 1491.4423828125, -1820.21875, 823.1533203125, 0.000000, 0.000000, 90.554809570313, .interiorid = 38); //object (cj_drip_tray) (2)
	CreateDynamicObject(3920, 1513.6788330078, -1821.4279785156, 824.36462402344, 0.000000, 0.000000, 90.385009765625, .interiorid = 38); //object (lib_veg3) (1)
	CreateDynamicObject(638, 1502.9124755859, -1814.5249023438, 822.66833496094, 0.000000, 0.25, 269.80493164063, .interiorid = 38); //object (kb_planter_bush) (1)
	CreateDynamicObject(638, 1505.56640625, -1814.5263671875, 822.66833496094, 0.000000, 0.2471923828125, 270.15344238281, .interiorid = 38); //object (kb_planter_bush) (2)
	CreateDynamicObject(638, 1508.2055664063, -1814.5263671875, 822.66833496094, 0.000000, 0.2471923828125, 270.14831542969, .interiorid = 38); //object (kb_planter_bush) (4)
	CreateDynamicObject(638, 1510.4490966797, -1814.5263671875, 822.66833496094, 0.000000, 0.2471923828125, 270.14831542969, .interiorid = 38); //object (kb_planter_bush) (5)
	CreateDynamicObject(627, 1496.720703125, -1819.353515625, 823.81665039063, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (veg_palmkb3) (1)
	CreateDynamicObject(627, 1496.6007080078, -1823.1038818359, 823.81665039063, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (veg_palmkb3) (2)
	CreateDynamicObject(1702, 1485.0297851563, -1827.4351806641, 821.97131347656, 0.000000, 0.000000, 0.5, .interiorid = 38); //object (kb_couch06) (1)
	CreateDynamicObject(1702, 1484.103515625, -1829.6979980469, 821.96350097656, 0.000000, 0.25, 87.800018310547, .interiorid = 38); //object (kb_couch06) (2)
	CreateDynamicObject(1702, 1484.0888671875, -1831.8824462891, 821.96350097656, 0.000000, 0.000000, 90.140014648438, .interiorid = 38); //object (kb_couch06) (3)
	CreateDynamicObject(1702, 1491.2678222656, -1831.8572998047, 821.97131347656, 0.000000, 0.000000, 203.00012207031, .interiorid = 38); //object (kb_couch06) (4)
	CreateDynamicObject(1702, 1488.9896240234, -1832.7951660156, 821.97131347656, 0.000000, 0.000000, 182.93041992188, .interiorid = 38); //object (kb_couch06) (5)
	CreateDynamicObject(1702, 1486.7662353516, -1832.8814697266, 821.97131347656, 0.000000, 0.000000, 173.42858886719, .interiorid = 38); //object (kb_couch06) (6)
	CreateDynamicObject(1702, 1487.5478515625, -1827.4705810547, 821.97131347656, 0.000000, 0.000000, 347.49987792969, .interiorid = 38); //object (kb_couch06) (7)
	CreateDynamicObject(2270, 1507.9501953125, -1808.6042480469, 826.59844970703, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (frame_wood_6) (1)
	CreateDynamicObject(1670, 1491.8314208984, -1830.3572998047, 823.36975097656, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (propcollecttable) (1)
	CreateDynamicObject(2232, 1498.6442871094, -1810.1533203125, 825.65484619141, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (med_speaker_4) (1)
	CreateDynamicObject(2232, 1496.7120361328, -1810.1494140625, 825.65484619141, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (med_speaker_4) (2)
	CreateDynamicObject(2232, 1493.5222167969, -1833.0986328125, 826.45788574219, 0.000000, 0.000000, 179.27001953125, .interiorid = 38); //object (med_speaker_4) (3)
	CreateDynamicObject(2232, 1511.7634277344, -1833.0986328125, 824.79791259766, 0.000000, 0.000000, 179.26940917969, .interiorid = 38); //object (med_speaker_4) (4)
	CreateDynamicObject(2232, 1513.4875488281, -1817.6975097656, 826.53863525391, 0.000000, 359.75, 269.59436035156, .interiorid = 38); //object (med_speaker_4) (5)
	CreateDynamicObject(2232, 1513.400390625, -1822.1938476563, 826.53863525391, 0.000000, 359.74719238281, 269.09350585938, .interiorid = 38); //object (med_speaker_4) (6)
	CreateDynamicObject(2332, 1516.9954833984, -1824.2689208984, 825.44982910156, 0.000000, 0.000000, 180, .interiorid = 38); //object (kev_safe) (1)
	CreateDynamicObject(2004, 1491.2916259766, -1810.6584472656, 822.48474121094, 0.000000, 0.000000, 269.75, .interiorid = 38); //object (cr_safe_door) (1)
	CreateDynamicObject(627, 1484.1717529297, -1832.9442138672, 823.81665039063, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (veg_palmkb3) (1)
	CreateDynamicObject(1491, 1487.1695556641, -1822.0983886719, 820.48132324219, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (gen_doorint01) (1)
	CreateDynamicObject(1491, 1490.1350097656, -1822.0762939453, 820.48132324219, 0.000000, 0.000000, 180, .interiorid = 38); //object (gen_doorint01) (1)
	CreateDynamicObject(2990, 1487.0985107422, -1834.0496826172, 825.88531494141, 0.000000, 0.000000, 179.12005615234, .interiorid = 38); //object (wongs_gate) (1)
	CreateDynamicObject(2293, 1510.68359375, -1812.5281982422, 824.40100097656, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (swk_1_fstool) (1)
	CreateDynamicObject(2293, 1509.2171630859, -1812.7664794922, 824.40100097656, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (swk_1_fstool) (2)
	CreateDynamicObject(2690, 1513.1833496094, -1828.9207763672, 823.72918701172, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (cj_fire_ext) (1)
	CreateDynamicObject(2427, 1491.83203125, -1810.1392822266, 823.12585449219, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (cj_ff_juice_l) (1)
	CreateDynamicObject(16779, 1490.5845947266, -1819.2939453125, 827.08166503906, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (ufo_light02) (1)
	CreateDynamicObject(16779, 1490.2940673828, -1814.6213378906, 827.08166503906, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (ufo_light02) (2)
	CreateDynamicObject(16779, 1487.0045166016, -1830.2224121094, 827.06469726563, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (ufo_light02) (3)
	CreateDynamicObject(2205, 1511.439453125, -1830.6441650391, 823.36975097656, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (med_office8_desk_1) (2)
	CreateDynamicObject(1714, 1512.0447998047, -1832.0383300781, 823.36975097656, 0.000000, 0.000000, 180, .interiorid = 38); //object (kb_swivelchair1) (1)
	CreateDynamicObject(14820, 1512.0557861328, -1830.6936035156, 824.41595458984, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (dj_stuff) (3)
	CreateDynamicObject(2921, 1513.6909179688, -1832.7159423828, 827.08428955078, 0.000000, 0.000000, 315, .interiorid = 38); //object (kmb_cam) (1)
	CreateDynamicObject(2922, 1515.4291992188, -1813.6689453125, 826.13836669922, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (kmb_keypad) (1)
	CreateDynamicObject(1359, 1500.9515380859, -1810.8406982422, 822.66986083984, 0.000000, 0.000000, 0.000000, .interiorid = 38); //object (cj_bin1) (1)
	
	// The Lubu Club
	CreateDynamicObject(4718, -1145.15, 592.19, 1115.00, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(4718, -1028.55, 609.61, 1115.00, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(4718, -1016.80, 560.56, 1115.00, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(4718, -1099.21, 545.61, 1125.57, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(9922, -1073.25, 601.23, 1155.91,   180.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(1536, -1077.52, 614.74, 1115.48, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(8640, -1086.80, 624.38, 1121.28, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(2126, -1092.22, 616.28, 1115.45, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(1713, -1095.16, 616.32, 1115.40, 0.00, 0.00, 91.00, .interiorid = 37);
	CreateDynamicObject(1713, -1093.12, 619.09, 1115.40, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1708, -1093.76, 614.46, 1115.41, 0.00, 0.00, 135.00, .interiorid = 37);
	CreateDynamicObject(1708, -1091.12, 614.80, 1115.41, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1708, -1090.43, 617.24, 1115.41, 0.00, 0.00, 258.00, .interiorid = 37);
	CreateDynamicObject(1670, -1092.62, 617.49, 1115.97, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1665, -1093.16, 616.90, 1115.97, 0.00, 0.00, 200.00, .interiorid = 37);
	CreateDynamicObject(1665, -1093.07, 617.46, 1115.97, 0.00, 0.00, 142.00, .interiorid = 37);
	CreateDynamicObject(1665, -1092.40, 616.29, 1115.97, 0.00, 0.00, 142.00, .interiorid = 37);
	CreateDynamicObject(1665, -1093.04, 616.13, 1115.97, 0.00, 0.00, 62.00, .interiorid = 37);
	CreateDynamicObject(2816, -1092.80, 616.89, 1115.56, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(3044, -1093.03, 615.94, 1116.00, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(3044, -1092.36, 616.05, 1116.00, 0.00, 0.00, 175.00, .interiorid = 37);
	CreateDynamicObject(3044, -1093.35, 616.78, 1116.00, 0.00, 0.00, 95.00, .interiorid = 37);
	CreateDynamicObject(3044, -1098.50, 621.54, 1116.00, 0.00, 0.00, 95.00, .interiorid = 37);
	CreateDynamicObject(3044, -1092.74, 617.73, 1116.00, 0.00, 0.00, 9.00, .interiorid = 37);
	CreateDynamicObject(8476, -1092.18, 626.06, 1117.00,   270.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(644, -1078.36, 610.96, 1115.86, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2249, -1092.87, 616.82, 1116.55, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(644, -1078.33, 615.25, 1115.86, 0.00, 0.00, 149.00, .interiorid = 37);
	CreateDynamicObject(2286, -1096.14, 607.11, 1118.92, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(14629, -1097.59, 619.59, 1123.73, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(627, -1078.35, 605.07, 1117.31, 0.00, 0.00, 40.00, .interiorid = 37);
	CreateDynamicObject(638, -1089.45, 625.85, 1116.18, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(638, -1095.79, 620.67, 1116.18, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(638, -1077.95, 618.74, 1116.18, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1068.40, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1068.40, 626.23, 1120.46, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1072.77, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1072.77, 626.23, 1120.44, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1077.18, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1077.18, 626.23, 1120.48, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1081.58, 626.24, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1081.58, 626.24, 1120.47, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1085.97, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1090.41, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1085.97, 626.23, 1120.45, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1090.41, 626.23, 1120.46, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1094.84, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1094.84, 626.23, 1120.48, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1068.40, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1068.40, 626.23, 1120.46, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1072.77, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1072.77, 626.23, 1120.44, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1077.18, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1077.18, 626.23, 1120.48, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1081.58, 626.24, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1081.58, 626.24, 1120.47, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1085.97, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1090.41, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1085.97, 626.19, 1120.45, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1090.43, 626.15, 1120.46, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1094.84, 626.23, 1117.16, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1649, -1094.84, 626.23, 1120.48, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(3044, -1098.50, 621.54, 1116.00, 0.00, 0.00, 95.00, .interiorid = 37);
	CreateDynamicObject(6189, -1081.25, 559.84, 1101.00, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(14399, -1085.37, 606.85, 1115.26, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1491, -1084.95, 606.57, 1114.13, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(14565, -1093.65, 603.91, 1117.42, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(14399, -1084.70, 602.56, 1115.26, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(14399, -1085.11, 602.26, 1117.14, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1511, -1086.76, 604.69, 1117.54, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1488, -1087.65, 604.70, 1117.52, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1488, -1087.92, 604.71, 1117.52, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1488, -1088.16, 604.70, 1117.52, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1511, -1086.50, 604.72, 1117.54, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1511, -1086.24, 604.73, 1117.54, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1511, -1090.97, 604.72, 1117.54, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1488, -1094.42, 604.68, 1117.52, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1541, -1086.62, 608.14, 1116.83, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1548, -1087.25, 608.05, 1116.40, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1548, -1086.02, 608.06, 1116.40, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1548, -1088.48, 608.05, 1116.40, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1541, -1087.80, 608.16, 1116.83, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1545, -1088.95, 608.14, 1116.83, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1547, -1086.69, 608.53, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1547, -1087.83, 608.52, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1547, -1088.97, 608.59, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1547, -1086.22, 604.61, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1547, -1087.46, 604.61, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1547, -1088.66, 604.63, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1547, -1090.09, 604.65, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(2125, -1086.64, 609.84, 1115.84, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2125, -1088.36, 609.81, 1115.84, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2125, -1090.00, 609.93, 1115.84, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2125, -1091.80, 609.91, 1115.84, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2125, -1093.56, 609.89, 1115.84, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2125, -1095.36, 609.86, 1115.84, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1547, -1091.63, 608.64, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1547, -1094.15, 608.70, 1116.64, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1517, -1092.60, 608.84, 1116.80, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1520, -1092.85, 608.54, 1116.65, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1667, -1092.81, 609.03, 1116.72, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1520, -1090.03, 609.12, 1116.67, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1520, -1091.11, 608.96, 1116.68, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1520, -1094.71, 608.91, 1116.68, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1520, -1095.52, 608.87, 1116.68, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1517, -1093.38, 609.11, 1116.81, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1517, -1094.12, 608.70, 1116.84, 0.00, 0.00, -120.00, .interiorid = 37);
	CreateDynamicObject(1517, -1090.61, 609.08, 1116.81, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1667, -1093.85, 609.05, 1116.72, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1667, -1089.43, 609.10, 1116.72, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1520, -1095.58, 604.37, 1116.65, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1517, -1094.79, 604.39, 1116.80, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(1517, -1094.89, 604.39, 1116.80, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(1517, -1094.98, 604.39, 1116.80, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(1517, -1095.07, 604.39, 1116.80, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(1517, -1095.16, 604.40, 1116.80, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(1517, -1095.24, 604.40, 1116.80, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(1520, -1095.67, 604.39, 1116.65, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(1520, -1095.74, 604.39, 1116.65, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1520, -1095.84, 604.36, 1116.65, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(1520, -1095.95, 604.37, 1116.65, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(357, -1091.97, 604.28, 1118.87, 0.00, 0.00, 11.00, .interiorid = 37);
	CreateDynamicObject(2877, -1091.37, 604.26, 1119.33, 0.00, 90.00, 0.00, .interiorid = 37);
	CreateDynamicObject(357, -1090.89, 604.39, 1118.87, 0.00, 0.00, 188.00, .interiorid = 37);
	CreateDynamicObject(1665, -1088.15, 609.05, 1116.65, 0.00, 0.00, 105.00, .interiorid = 37);
	CreateDynamicObject(1665, -1087.14, 609.07, 1116.65, 0.00, 0.00, 105.00, .interiorid = 37);
	CreateDynamicObject(1665, -1089.57, 609.07, 1116.65, 0.00, 0.00, 105.00, .interiorid = 37);
	CreateDynamicObject(1665, -1090.84, 609.05, 1116.65, 0.00, 0.00, 105.00, .interiorid = 37);
	CreateDynamicObject(1665, -1092.55, 609.12, 1116.65, 0.00, 0.00, 105.00, .interiorid = 37);
	CreateDynamicObject(1665, -1094.29, 609.10, 1116.64, 0.00, 0.00, 105.00, .interiorid = 37);
	CreateDynamicObject(3044, -1092.67, 609.31, 1116.66, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(3044, -1094.41, 609.29, 1116.66, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(3044, -1091.08, 609.14, 1116.66, 0.00, 0.00, 50.00, .interiorid = 37);
	CreateDynamicObject(3044, -1089.85, 609.08, 1116.67, 0.00, 4.00, 55.00, .interiorid = 37);
	CreateDynamicObject(3044, -1088.38, 609.14, 1116.67, 0.00, 0.00, 50.00, .interiorid = 37);
	CreateDynamicObject(3044, -1087.38, 609.18, 1116.66, 0.00, 0.00, 50.00, .interiorid = 37);
	CreateDynamicObject(14693, -1091.03, 604.54, 1116.41, 0.00, 0.00, 198.00, .interiorid = 37);
	CreateDynamicObject(2964, -1082.60, 619.42, 1115.51, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(2964, -1086.10, 619.00, 1115.51, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(2964, -1082.38, 623.21, 1115.51, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(2964, -1086.17, 623.27, 1115.51, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(2965, -1082.58, 618.66, 1116.41, 0.00, 0.00, 31.00, .interiorid = 37);
	CreateDynamicObject(2965, -1070.52, 601.93, 1116.19, 0.00, 0.00, 91.00, .interiorid = 37);
	CreateDynamicObject(3122, -1095.28, 591.81, 1116.54, 0.00, 0.00, 49.00, .interiorid = 37);
	CreateDynamicObject(2995, -1082.56, 619.45, 1116.43, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2995, -1082.51, 618.79, 1116.43, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2995, -1082.42, 618.74, 1116.43, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(3101, -1082.58, 618.66, 1116.44, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(3101, -1082.73, 619.74, 1116.44, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(3101, -1082.37, 618.62, 1116.44, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(3101, -1086.47, 619.60, 1116.43, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2995, -1085.81, 619.48, 1116.43, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(2995, -1086.26, 618.36, 1116.43, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1713, -1079.92, 604.98, 1115.40, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1713, -1078.17, 608.03, 1115.40, 0.00, 0.00, 270.00, .interiorid = 37);
	CreateDynamicObject(1713, -1081.67, 608.86, 1115.40, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(14629, -1105.86, 618.97, 1123.90, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(1713, -1091.56, 620.89, 1115.40, 0.00, 0.00, 180.00, .interiorid = 37);
	CreateDynamicObject(1708, -1090.24, 623.63, 1115.41, 0.00, 0.00, 258.00, .interiorid = 37);
	CreateDynamicObject(1708, -1094.42, 622.65, 1115.41, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(1708, -1093.14, 625.02, 1115.41, 0.00, 0.00, 40.00, .interiorid = 37);
	CreateDynamicObject(2126, -1091.98, 622.76, 1115.45, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(1520, -1092.28, 622.57, 1116.00, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1520, -1091.98, 623.04, 1116.00, 0.00, 0.00, 207.00, .interiorid = 37);
	CreateDynamicObject(1520, -1092.85, 622.88, 1116.00, 0.00, 0.00, -33.00, .interiorid = 37);
	CreateDynamicObject(1520, -1092.85, 623.38, 1116.00, 0.00, 0.00, 47.00, .interiorid = 37);
	CreateDynamicObject(1520, -1092.19, 623.89, 1116.00, 0.00, 0.00, 295.00, .interiorid = 37);
	CreateDynamicObject(1665, -1092.04, 623.54, 1115.98, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(1665, -1092.91, 623.16, 1115.98, 0.00, 0.00, 193.00, .interiorid = 37);
	CreateDynamicObject(1665, -1092.70, 622.53, 1115.98, 0.00, 0.00, -120.00, .interiorid = 37);
	CreateDynamicObject(1665, -1092.73, 623.99, 1115.98, 0.00, 0.00, 105.00, .interiorid = 37);
	CreateDynamicObject(338, -1085.51, 618.80, 1115.67, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(338, -1085.51, 618.69, 1115.67, 0.00, 0.00, 0.00, .interiorid = 37);
	CreateDynamicObject(338, -1083.36, 619.74, 1115.61, 0.00, 0.00, 55.00, .interiorid = 37);
	CreateDynamicObject(338, -1083.36, 620.01, 1115.61, 0.00, 0.00, 55.00, .interiorid = 37);
	CreateDynamicObject(338, -1082.70, 622.72, 1116.50, 0.00, 90.00, 69.00, .interiorid = 37);
	CreateDynamicObject(338, -1082.63, 622.69, 1116.50, 0.00, 90.00, 69.00, .interiorid = 37);
	CreateDynamicObject(2266, -1095.63, 614.97, 1118.50, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(2271, -1095.64, 619.01, 1118.67, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(2270, -1095.61, 622.48, 1118.69, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(6330, -1144.93, 637.08, 1103.81, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(6340, -1058.39, 699.35, 1114.91, 0.00, 0.00, 91.00, .interiorid = 37);
	CreateDynamicObject(6371, -1131.31, 696.01, 1135.17, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(6329, -1010.50, 669.46, 1104.35, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(6307, -957.80, 603.37, 1109.40, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(6389, -953.89, 698.05, 1120.14, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(6302, -1181.81, 687.92, 1103.10, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(6336, -1224.95, 681.81, 1121.36, 0.00, 0.00, 90.00, .interiorid = 37);
	CreateDynamicObject(1536, -1077.48, 611.73, 1115.48, 0.00, 0.00, 90.00, .interiorid = 37);
	
	// The Tableau Club
	CreateDynamicObject(18769, 324.65, 1034.73, 1097.25, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(19129, 324.65, 1034.77, 1097.65, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(19272, 312.52, 1034.59, 1097.54, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(8133, 307.96, 1027.17, 1097.53, 0.00, 90.00, 0.00, .interiorid = 36);
	CreateDynamicObject(19129, 312.25, 1009.90, 1102.72,   90.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(19129, 327.96, 1013.48, 1102.72,   90.00, 0.00, 200.00, .interiorid = 36);
	CreateDynamicObject(19129, 333.26, 1019.11, 1102.72,   90.00, 0.00, 220.00, .interiorid = 36);
	CreateDynamicObject(19129, 335.69, 1025.02, 1102.72,   90.00, 0.00, 240.00, .interiorid = 36);
	CreateDynamicObject(19129, 337.84, 1034.80, 1102.72,   90.00, 0.00, 260.00, .interiorid = 36);
	CreateDynamicObject(19129, 337.01, 1039.71, 1102.72,   90.00, 0.00, 280.00, .interiorid = 36);
	CreateDynamicObject(19129, 333.33, 1048.40, 1102.72,   90.00, 0.00, 300.00, .interiorid = 36);
	CreateDynamicObject(19129, 326.30, 1055.39, 1102.72,   90.00, 0.00, 320.00, .interiorid = 36);
	CreateDynamicObject(19129, 321.83, 1057.49, 1102.72,   90.00, 0.00, 340.00, .interiorid = 36);
	CreateDynamicObject(19129, 312.37, 1059.56, 1102.72,   90.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18754, 312.38, 1058.27, 1097.02, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18774, 306.92, 1034.18, 1106.06, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.50, 1030.54, 1104.60, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1030.54, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1030.54, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1033.38, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1033.38, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1033.38, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1036.22, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1036.22, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1036.22, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1039.06, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1039.06, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1039.06, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.50, 1030.54, 1104.60, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1030.54, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1030.54, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1033.38, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1033.38, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1033.38, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1036.22, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1036.22, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1036.22, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1039.06, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1039.06, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1039.06, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.50, 1030.54, 1104.60, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1030.54, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1030.54, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1033.38, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1033.38, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1033.38, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1036.22, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1036.22, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1036.22, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1039.06, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1039.06, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1039.06, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.50, 1030.54, 1104.60, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1030.54, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1030.54, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1033.38, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1033.38, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1033.38, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1036.22, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1036.22, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1036.22, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 308.52, 1039.06, 1104.66, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.07, 1039.06, 1106.69, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1651, 309.31, 1039.06, 1107.63, 0.00, 15.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18763, 308.18, 1040.87, 1106.28, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18763, 308.19, 1027.43, 1106.28, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.61, 1041.67, 1108.01, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.61, 1041.67, 1106.80, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.61, 1041.67, 1105.58, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.66, 1040.16, 1105.58, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.66, 1040.16, 1106.76, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.66, 1040.16, 1107.93, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.68, 1028.17, 1107.96, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.68, 1028.17, 1106.78, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.68, 1028.17, 1105.57, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.72, 1026.84, 1105.57, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.72, 1026.84, 1106.76, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 309.72, 1026.84, 1107.96, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2229, 309.31, 1025.99, 1104.16, 0.00, 90.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2229, 309.31, 1028.79, 1104.78, 0.00, 270.00, 90.00, .interiorid = 36);
	CreateDynamicObject(18647, 309.69, 1027.35, 1103.99, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18647, 309.68, 1040.83, 1104.15, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2229, 309.30, 1039.50, 1104.15, 0.00, 90.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2229, 309.32, 1042.27, 1104.77, 0.00, 270.00, 90.00, .interiorid = 36);
	CreateDynamicObject(18090, 311.84, 1011.42, 1100.06, 0.00, 0.00, 270.00, .interiorid = 36);
	CreateDynamicObject(18102, 307.05, 1014.45, 1103.27,   -40.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(2670, 309.06, 1014.08, 1097.62, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2670, 311.40, 1014.32, 1097.62, 0.00, 0.00, 76.00, .interiorid = 36);
	CreateDynamicObject(2670, 313.34, 1014.49, 1097.62, 0.00, 0.00, 40.00, .interiorid = 36);
	CreateDynamicObject(2670, 315.22, 1013.87, 1097.62, 0.00, 0.00, 25.00, .interiorid = 36);
	CreateDynamicObject(2670, 309.47, 1015.02, 1097.62, 0.00, 0.00, 25.00, .interiorid = 36);
	CreateDynamicObject(2670, 312.68, 1013.79, 1097.62, 0.00, 0.00, 25.00, .interiorid = 36);
	CreateDynamicObject(2674, 317.20, 1012.07, 1097.56, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1508, 307.59, 1053.81, 1099.18, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1536, 307.51, 1024.83, 1097.49, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2670, 326.89, 1022.55, 1097.62, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2670, 315.24, 1023.14, 1097.62, 0.00, 0.00, 171.00, .interiorid = 36);
	CreateDynamicObject(1541, 314.35, 1012.09, 1098.73, 0.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(1541, 313.37, 1012.09, 1098.73, 0.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(1548, 313.86, 1012.64, 1098.54, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1547, 314.92, 1012.65, 1098.54, 0.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(1547, 312.86, 1012.66, 1098.54, 0.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(1511, 313.81, 1010.50, 1099.95, 0.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(1488, 313.39, 1010.49, 1099.95, 0.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(1668, 312.86, 1010.14, 1099.86, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1668, 312.24, 1010.19, 1099.86, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1668, 310.69, 1010.16, 1099.86, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1668, 310.69, 1010.16, 1099.33, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1668, 309.18, 1010.18, 1099.87, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1544, 309.12, 1010.27, 1099.72, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1544, 310.88, 1010.25, 1099.72, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1544, 310.90, 1010.15, 1099.15, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1544, 311.72, 1010.11, 1099.15, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1544, 312.40, 1010.11, 1099.15, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1544, 313.00, 1010.18, 1099.15, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1544, 313.00, 1010.18, 1099.67, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1520, 311.38, 1010.14, 1099.71, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1520, 312.27, 1010.14, 1099.21, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1520, 312.45, 1010.14, 1099.75, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1520, 314.46, 1010.16, 1099.75, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1517, 314.30, 1010.16, 1099.89, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18765, 300.67, 1034.31, 1101.06, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(7493, 305.69, 1033.45, 1113.86,   180.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(4718, 271.72, 970.62, 1112.06, 0.00, 0.00, 270.00, .interiorid = 36);
	CreateDynamicObject(4718, 289.10, 1097.88, 1112.06, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(18765, 290.70, 1034.18, 1101.06, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(19129, 287.43, 1035.34, 1103.55,   90.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(1536, 293.83, 1029.39, 1103.52, 0.00, 0.00, 180.00, .interiorid = 36);
	CreateDynamicObject(14463, 278.04, 1028.03, 1106.44, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(16151, 300.42, 1030.14, 1103.87, 0.00, 0.00, 270.00, .interiorid = 36);
	CreateDynamicObject(2292, 288.87, 1038.72, 1103.54, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2291, 289.30, 1038.75, 1103.52, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2291, 290.22, 1038.76, 1103.52, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2291, 291.10, 1038.77, 1103.52, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2291, 292.00, 1038.77, 1103.52, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.87, 1037.34, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.88, 1036.48, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.88, 1035.58, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.89, 1034.71, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.90, 1033.81, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.90, 1032.93, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.90, 1032.04, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.90, 1031.12, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2291, 288.90, 1030.22, 1103.52, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2292, 288.89, 1029.77, 1103.50, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2290, 300.59, 1038.89, 1103.54, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2290, 296.12, 1038.81, 1103.54, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1665, 303.77, 1030.80, 1104.52, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(1665, 302.87, 1031.15, 1104.52, 0.00, 0.00, 69.00, .interiorid = 36);
	CreateDynamicObject(1665, 301.69, 1031.32, 1104.52, 0.00, 0.00, 164.00, .interiorid = 36);
	CreateDynamicObject(1665, 300.45, 1031.24, 1104.52, 0.00, 0.00, 69.00, .interiorid = 36);
	CreateDynamicObject(1665, 299.35, 1031.22, 1104.52, 0.00, 0.00, 98.00, .interiorid = 36);
	CreateDynamicObject(1665, 298.29, 1031.27, 1104.52, 0.00, 0.00, 69.00, .interiorid = 36);
	CreateDynamicObject(1665, 297.26, 1031.03, 1104.52, 0.00, 0.00, 127.00, .interiorid = 36);
	CreateDynamicObject(5992, 297.91, 1052.65, 1104.53, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(5992, 297.89, 1056.41, 1104.53, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(5992, 307.23, 1033.95, 1115.64, 0.00, 0.00, 270.00, .interiorid = 36);
	CreateDynamicObject(5992, 297.41, 1021.58, 1104.53, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(5992, 297.43, 1019.72, 1104.53, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(5992, 297.47, 1023.29, 1104.53, 0.00, 0.00, 1.26, .interiorid = 36);
	CreateDynamicObject(18765, 305.66, 1034.91, 1096.33, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(11472, 302.51, 1030.67, 1095.79, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(11472, 304.10, 1030.67, 1095.79, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(18649, 310.65, 1031.79, 1098.21, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18649, 310.67, 1034.81, 1098.21, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18649, 310.74, 1038.09, 1098.21, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(2232, 310.51, 1036.52, 1098.21, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 310.51, 1039.52, 1098.21, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 310.50, 1033.18, 1098.21, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2232, 310.54, 1030.31, 1098.21, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(18649, 309.08, 1039.94, 1098.57, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(18650, 309.12, 1039.92, 1097.68, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(18651, 309.06, 1039.92, 1098.09, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2208, 309.96, 1031.42, 1098.79, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(2208, 309.91, 1035.75, 1098.75, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(14820, 309.92, 1032.70, 1099.67, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(14820, 309.90, 1037.08, 1099.67, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(970, 310.62, 1032.03, 1099.34, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(970, 310.62, 1036.16, 1099.34, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(970, 308.59, 1039.90, 1099.34, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(970, 310.62, 1037.75, 1099.34, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(970, 310.62, 1033.03, 1099.34, 0.00, 0.00, 90.00, .interiorid = 36);
	CreateDynamicObject(18650, 310.45, 1037.15, 1099.36, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18650, 310.46, 1032.76, 1099.36, 0.00, 0.00, 0.00, .interiorid = 36);
	CreateDynamicObject(18653, 334.57, 1044.60, 1097.11, 0.00, 0.00, 47.00, .interiorid = 36);
	CreateDynamicObject(18655, 334.24, 1025.10, 1097.53, 0.00, 0.00, 324.00, .interiorid = 36);
	CreateDynamicObject(18654, 315.04, 1025.15, 1097.61, 0.00, 0.00, 215.00, .interiorid = 36);
	CreateDynamicObject(18655, 314.84, 1044.48, 1097.61, 0.00, 0.00, 149.00, .interiorid = 36);
	
	// Santa Maria Surfer's Lounge
	CreateDynamicObject(18783, 262.18, 1086.09, 5093.26, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(18783, 242.16, 1086.12, 5093.26, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(18783, 262.19, 1066.19, 5093.25, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(18783, 242.20, 1066.14, 5093.26, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(19074, 262.50, 1069.60, 5105.76,   90.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(19074, 242.32, 1098.31, 5105.63,   90.00, 0.00, 180.00, .interiorid = 35);
	CreateDynamicObject(19074, 262.17, 1098.32, 5105.63,   90.00, 0.00, 180.00, .interiorid = 35);
	CreateDynamicObject(19074, 274.68, 1068.73, 5105.63,   90.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(19074, 237.36, 1087.25, 5105.63,   90.00, 0.00, 270.00, .interiorid = 35);
	CreateDynamicObject(19074, 242.50, 1069.60, 5105.76,   90.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(3361, 262.14, 1073.13, 5097.70, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(13007, 262.95, 1086.76, 5096.40,   270.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(13007, 259.00, 1086.76, 5096.40,   270.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(6188, 241.35, 1072.35, 5086.40, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(3361, 262.13, 1075.14, 5097.70, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(3361, 262.14, 1077.14, 5097.70, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(11472, 258.02, 1083.15, 5096.74, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(11472, 258.00, 1081.59, 5096.74, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(11472, 258.00, 1080.01, 5096.74, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(11472, 258.00, 1078.44, 5096.74, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(13007, 258.99, 1086.82, 5108.33,   270.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(2404, 256.77, 1079.65, 5100.50, 0.00, 90.00, 270.00, .interiorid = 35);
	CreateDynamicObject(16151, 255.79, 1086.29, 5099.14, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2406, 256.81, 1084.82, 5099.95, 0.00, 0.00, 270.00, .interiorid = 35);
	CreateDynamicObject(625, 256.60, 1093.45, 5098.67, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(3806, 262.52, 1078.91, 5101.55, 0.00, 0.00, 270.00, .interiorid = 35);
	CreateDynamicObject(2252, 255.58, 1082.96, 5099.98, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(19074, 237.36, 1067.25, 5105.63,   90.00, 0.00, 270.00, .interiorid = 35);
	CreateDynamicObject(1646, 241.96, 1073.69, 5099.06, 0.00, 0.00, 185.00, .interiorid = 35);
	CreateDynamicObject(1646, 244.11, 1073.72, 5099.06, 0.00, 0.00, 164.00, .interiorid = 35);
	CreateDynamicObject(1646, 245.69, 1073.74, 5099.06, 0.00, 0.00, 180.00, .interiorid = 35);
	CreateDynamicObject(1281, 249.58, 1090.33, 5099.51, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(1281, 244.24, 1090.38, 5099.51, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(628, 241.36, 1094.68, 5100.57, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(1281, 244.23, 1086.14, 5099.51, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(1281, 249.67, 1086.18, 5099.51, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(1281, 249.74, 1081.89, 5099.51, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(1281, 244.45, 1081.90, 5099.51, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(6209, 228.92, 1102.15, 5103.03, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(6209, 224.06, 1084.63, 5103.51, 0.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(6209, 217.71, 1061.23, 5103.19, 0.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(2725, 243.23, 1074.02, 5098.98, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2725, 246.73, 1073.86, 5098.98, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(1646, 247.87, 1073.67, 5099.06, 0.00, 0.00, 164.00, .interiorid = 35);
	CreateDynamicObject(748, 254.84, 1094.81, 5098.59, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2405, 239.89, 1084.68, 5100.52, 0.00, 90.00, 90.00, .interiorid = 35);
	CreateDynamicObject(19172, 248.45, 1095.79, 5101.63, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2405, 239.88, 1082.02, 5100.52, 0.00, 90.00, 90.00, .interiorid = 35);
	CreateDynamicObject(2405, 239.88, 1087.36, 5100.52, 0.00, 90.00, 90.00, .interiorid = 35);
	CreateDynamicObject(19317, 247.20, 1072.13, 5102.06, 0.00, 55.00, 180.00, .interiorid = 35);
	CreateDynamicObject(2395, 248.64, 1072.15, 5102.29, 0.00, 90.00, 180.00, .interiorid = 35);
	CreateDynamicObject(19317, 247.20, 1072.13, 5101.07, 0.00, 55.00, 180.00, .interiorid = 35);
	CreateDynamicObject(19317, 247.20, 1072.13, 5100.08, 0.00, 55.00, 180.00, .interiorid = 35);
	CreateDynamicObject(18783, 249.33, 1076.99, 5107.38,   180.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(18783, 249.31, 1096.91, 5107.38,   180.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(18783, 269.65, 1069.24, 5105.61,   190.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(13007, 273.97, 1085.53, 5103.00, 0.00, 0.00, 180.00, .interiorid = 35);
	CreateDynamicObject(19173, 256.83, 1086.41, 5103.05, 0.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(3961, 277.30, 1089.58, 5097.73, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(13007, 265.49, 1084.32, 5096.49,   270.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2395, 272.14, 1081.73, 5098.92, 0.00, 0.00, 270.00, .interiorid = 35);
	CreateDynamicObject(3095, 284.06, 1087.47, 5095.75,   90.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(14399, 258.11, 1080.55, 5095.69, 0.00, 0.00, 180.00, .interiorid = 35);
	CreateDynamicObject(1514, 268.15, 1078.66, 5097.33, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(1514, 266.52, 1078.64, 5097.33, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2394, 265.28, 1083.27, 5097.66, 0.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(2394, 266.25, 1083.27, 5097.66, 0.00, 0.00, 270.00, .interiorid = 35);
	CreateDynamicObject(2394, 267.32, 1083.29, 5097.66, 0.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(2394, 268.34, 1083.26, 5097.66, 0.00, 0.00, 270.00, .interiorid = 35);
	CreateDynamicObject(2252, 269.16, 1078.64, 5097.34, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2406, 269.40, 1081.24, 5097.81, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2406, 269.46, 1081.72, 5097.81, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2406, 269.41, 1082.33, 5097.81, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2404, 269.44, 1082.02, 5097.84, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2404, 269.42, 1081.47, 5097.84, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(18762, 269.10, 1078.69, 5094.55, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(18762, 272.70, 1078.22, 5096.66, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(2289, 263.93, 1078.09, 5098.63, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(625, 242.41, 1073.19, 5099.10, 0.00, 0.00, 0.00, .interiorid = 35);
	CreateDynamicObject(1557, 272.21, 1072.86, 5095.74, 0.00, 0.00, 90.00, .interiorid = 35);
	CreateDynamicObject(1557, 272.20, 1075.88, 5095.74, 0.00, 0.00, 270.00, .interiorid = 35);
	CreateDynamicObject(2404, 268.87, 1072.11, 5098.46, 0.00, 90.00, 180.00, .interiorid = 35);
	
	// Grove Street Families HQ
	CreateDynamicObject(14412, 879.76, 1843.06, 8063.64, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(8133, 881.33, 1844.64, 8058.83, 0.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(8133, 881.33, 1844.64, 8057.67, 0.00, 180.00, 0.00, .interiorid = 34);
	CreateDynamicObject(7191, 863.31, 1837.07, 8058.30, 0.00, 270.00, 0.00, .interiorid = 34);
	CreateDynamicObject(7191, 863.31, 1837.07, 8058.20, 0.00, 270.00, 0.00, .interiorid = 34);
	CreateDynamicObject(14407, 858.99, 1850.11, 8055.27, 0.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(970, 861.41, 1850.98, 8058.96, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(970, 861.41, 1846.84, 8058.96, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(970, 861.41, 1842.70, 8058.96, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(970, 861.37, 1837.19, 8058.96, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(970, 861.37, 1835.11, 8058.96, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(970, 861.40, 1839.23, 8058.96, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(970, 859.28, 1833.03, 8058.96, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(970, 858.66, 1833.03, 8058.96, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18766, 848.51, 1846.76, 8058.76, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18766, 848.51, 1846.73, 8063.56, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1499, 856.49, 1846.53, 8058.45, 0.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(1499, 853.50, 1846.51, 8058.45, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18766, 851.77, 1846.76, 8063.45, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1508, 848.46, 1836.67, 8059.36, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.94, 1848.74, 8063.87, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.94, 1848.65, 8060.57, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.92, 1845.04, 8063.88, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.97, 1840.79, 8063.80, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.97, 1836.63, 8063.78, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.93, 1844.82, 8060.57, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.97, 1840.79, 8060.48, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.67, 1836.64, 8060.54, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1851.43, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 855.13, 1851.43, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 855.12, 1852.59, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1852.58, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 855.12, 1853.74, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1853.73, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1854.88, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 855.13, 1854.88, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 855.13, 1856.02, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1856.00, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1857.16, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 855.13, 1857.16, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.25, 1851.98, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1853.29, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.25, 1854.43, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1855.47, 8058.76, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 853.24, 1856.49, 8058.75, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 850.41, 1851.42, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 848.50, 1851.41, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 850.39, 1852.54, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 848.51, 1852.55, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 850.38, 1853.68, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 850.37, 1854.82, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 850.38, 1855.96, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 850.40, 1857.09, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 848.52, 1853.70, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 848.49, 1854.83, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 848.49, 1855.97, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(936, 848.54, 1857.09, 8058.77, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(945, 849.77, 1851.88, 8068.70, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18649, 854.14, 1853.76, 8059.24, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(18649, 854.17, 1851.53, 8059.24, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(3409, 854.20, 1853.43, 8058.71, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3409, 854.10, 1858.08, 8058.63, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18649, 854.07, 1855.96, 8059.24, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(18649, 849.85, 1851.49, 8059.24, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(18649, 849.83, 1853.78, 8059.24, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(18649, 849.95, 1856.03, 8059.24, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(3409, 849.53, 1853.29, 8058.69, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3409, 849.51, 1857.84, 8058.78, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2509, 851.77, 1846.23, 8060.10, 0.00, 90.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2509, 849.89, 1846.23, 8060.10, 0.00, 90.00, 0.00, .interiorid = 34);
	CreateDynamicObject(355, 852.15, 1846.21, 8060.35, 0.00, 0.00, 184.00, .interiorid = 34);
	CreateDynamicObject(355, 852.15, 1846.21, 8059.84, 0.00, 0.00, 184.00, .interiorid = 34);
	CreateDynamicObject(349, 850.88, 1846.24, 8060.43, 0.00, 0.00, -177.00, .interiorid = 34);
	CreateDynamicObject(349, 850.86, 1846.22, 8059.92, 0.00, 0.00, -177.00, .interiorid = 34);
	CreateDynamicObject(352, 849.63, 1846.19, 8060.45, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(352, 849.63, 1846.19, 8059.86, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(352, 849.13, 1846.16, 8059.86, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(352, 849.13, 1846.20, 8060.41, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3788, 849.26, 1844.19, 8058.92, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(3793, 848.88, 1844.20, 8059.24, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(355, 848.93, 1844.27, 8058.80,   273.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(355, 849.25, 1844.29, 8058.80,   273.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(355, 849.29, 1843.82, 8058.80,   273.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(355, 849.03, 1843.82, 8058.80,   273.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(355, 848.84, 1844.72, 8058.80,   273.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(355, 849.21, 1843.01, 8058.92,   -76.00, -84.00, 0.00, .interiorid = 34);
	CreateDynamicObject(355, 849.45, 1843.01, 8058.92,   -76.00, -84.00, 4.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.97, 1836.63, 8060.50, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(3800, 849.00, 1841.40, 8058.45, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3800, 849.00, 1840.33, 8058.45, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2043, 849.09, 1840.29, 8059.64, 0.00, 0.00, 40.00, .interiorid = 34);
	CreateDynamicObject(2043, 849.12, 1840.81, 8059.64, 0.00, 0.00, 40.00, .interiorid = 34);
	CreateDynamicObject(2043, 849.17, 1841.37, 8059.64, 0.00, 0.00, 40.00, .interiorid = 34);
	CreateDynamicObject(2358, 851.87, 1846.10, 8058.56, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2358, 852.59, 1846.09, 8058.56, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2358, 852.29, 1846.08, 8058.79, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.51, 1836.65, 8060.54, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.51, 1836.65, 8063.82, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.58, 1840.53, 8063.82, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.57, 1840.57, 8060.50, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.49, 1845.11, 8063.82, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.49, 1845.11, 8060.53, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.49, 1849.49, 8060.53, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1649, 856.49, 1849.49, 8063.84, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1763, 850.25, 1830.32, 8058.35, 0.00, 0.00, 135.00, .interiorid = 34);
	CreateDynamicObject(1759, 848.95, 1834.60, 8058.38, 0.00, 0.00, 55.00, .interiorid = 34);
	CreateDynamicObject(1763, 849.05, 1832.41, 8058.35, 0.00, 0.00, 91.00, .interiorid = 34);
	CreateDynamicObject(1763, 852.61, 1830.12, 8058.35, 0.00, 0.00, 178.00, .interiorid = 34);
	CreateDynamicObject(2370, 850.98, 1832.46, 8058.13, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(348, 852.04, 1832.19, 8058.98,   91.00, 0.00, 193.00, .interiorid = 34);
	CreateDynamicObject(346, 850.64, 1833.49, 8058.96,   91.00, 0.00, 40.00, .interiorid = 34);
	CreateDynamicObject(346, 851.17, 1833.48, 8058.96,   91.00, 0.00, 40.00, .interiorid = 34);
	CreateDynamicObject(346, 850.78, 1832.14, 8058.96,   91.00, 0.00, 178.00, .interiorid = 34);
	CreateDynamicObject(2852, 850.96, 1832.62, 8058.96, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2816, 851.34, 1832.93, 8058.98, 0.00, 0.00, 127.00, .interiorid = 34);
	CreateDynamicObject(1665, 851.44, 1832.10, 8058.99, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1665, 850.88, 1832.07, 8058.99, 0.00, 0.00, -62.00, .interiorid = 34);
	CreateDynamicObject(1665, 850.61, 1832.57, 8058.99, 0.00, 0.00, 193.00, .interiorid = 34);
	CreateDynamicObject(1665, 850.63, 1833.30, 8058.99, 0.00, 0.00, 193.00, .interiorid = 34);
	CreateDynamicObject(2866, 851.78, 1833.09, 8058.98, 0.00, 0.00, -33.00, .interiorid = 34);
	CreateDynamicObject(2674, 849.61, 1834.41, 8058.47, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2670, 850.06, 1831.98, 8058.53, 0.00, 0.00, 324.00, .interiorid = 34);
	CreateDynamicObject(2670, 851.79, 1831.24, 8058.53, 0.00, 0.00, 171.00, .interiorid = 34);
	CreateDynamicObject(2673, 851.71, 1832.93, 8059.05, 0.00, 0.00, 229.00, .interiorid = 34);
	CreateDynamicObject(2670, 850.01, 1837.26, 8058.53, 0.00, 0.00, 324.00, .interiorid = 34);
	CreateDynamicObject(2670, 853.40, 1841.23, 8058.53, 0.00, 0.00, 265.00, .interiorid = 34);
	CreateDynamicObject(2670, 851.53, 1843.84, 8058.53, 0.00, 0.00, 18.00, .interiorid = 34);
	CreateDynamicObject(2670, 852.97, 1836.50, 8058.53, 0.00, 0.00, 135.00, .interiorid = 34);
	CreateDynamicObject(2670, 854.88, 1838.97, 8058.53, 0.00, 0.00, 62.00, .interiorid = 34);
	CreateDynamicObject(2332, 848.83, 1839.39, 8058.88, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(2332, 848.84, 1837.68, 8058.88, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1829, 849.19, 1838.54, 8058.91, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(349, 848.78, 1838.81, 8059.37,   84.00, 0.00, -76.00, .interiorid = 34);
	CreateDynamicObject(2670, 863.85, 1852.05, 8054.38, 0.00, 0.00, 55.00, .interiorid = 34);
	CreateDynamicObject(2670, 865.57, 1852.18, 8054.38, 0.00, 0.00, 91.00, .interiorid = 34);
	CreateDynamicObject(2670, 864.04, 1853.70, 8054.38, 0.00, 0.00, 91.00, .interiorid = 34);
	CreateDynamicObject(2670, 863.57, 1855.06, 8054.38, 0.00, 0.00, 149.00, .interiorid = 34);
	CreateDynamicObject(2674, 862.37, 1851.73, 8054.32, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(14467, 858.77, 1835.88, 8056.90, 0.00, 0.00, 135.00, .interiorid = 34);
	CreateDynamicObject(18649, 859.41, 1836.12, 8054.37, 0.00, 0.00, 45.15, .interiorid = 34);
	CreateDynamicObject(18649, 859.41, 1834.73, 8054.37, 0.00, 0.00, 134.00, .interiorid = 34);
	CreateDynamicObject(18649, 857.98, 1836.09, 8054.37, 0.00, 0.00, 134.00, .interiorid = 34);
	CreateDynamicObject(13607, 867.17, 1845.12, 8054.29, 0.00, 90.00, 180.00, .interiorid = 34);
	CreateDynamicObject(1495, 864.18, 1829.57, 8054.27, 0.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(1533, 862.68, 1829.54, 8054.27, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18649, 858.02, 1834.74, 8054.37, 0.00, 0.00, 45.15, .interiorid = 34);
	CreateDynamicObject(2674, 865.51, 1855.05, 8054.32, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2674, 868.32, 1852.60, 8054.32, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2670, 868.48, 1854.69, 8054.38, 0.00, 0.00, 47.00, .interiorid = 34);
	CreateDynamicObject(2670, 867.29, 1854.72, 8054.38, 0.00, 0.00, 76.00, .interiorid = 34);
	CreateDynamicObject(2670, 866.87, 1852.11, 8054.38, 0.00, 0.00, 55.00, .interiorid = 34);
	CreateDynamicObject(17951, 856.54, 1854.99, 8059.48, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(17951, 856.90, 1855.29, 8059.31, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1490, 870.69, 1851.08, 8061.71,   4.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1525, 870.71, 1848.12, 8060.33, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1526, 870.71, 1845.58, 8061.65,   11.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1527, 870.71, 1843.42, 8062.30, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1528, 870.71, 1841.12, 8061.02,   -18.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1529, 870.72, 1838.36, 8061.59, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1531, 870.70, 1835.93, 8063.05,   -4.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(17969, 870.68, 1833.27, 8060.59,   -4.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(14840, 870.70, 1854.47, 8056.51,   -11.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.65, 1854.93, 8056.68, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(4227, 870.80, 1841.37, 8055.67, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1529, 870.71, 1853.59, 8055.57,   -11.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1527, 870.71, 1851.57, 8055.78, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(5663, 820.51, 1836.02, 8060.63, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.67, 1853.57, 8055.54,   -18.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.70, 1851.61, 8055.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.67, 1851.09, 8061.71, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.68, 1848.13, 8060.35, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.69, 1845.55, 8061.59,   11.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.68, 1843.40, 8062.35, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.67, 1841.12, 8061.04,   -18.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.70, 1838.32, 8061.59, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.67, 1835.92, 8063.07, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(18659, 859.35, 1857.02, 8061.11, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(5078, 850.21, 1842.81, 8056.09, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(17504, 904.62, 1804.48, 8061.75, 0.00, 0.00, -90.00, .interiorid = 34);
	CreateDynamicObject(18659, 852.12, 1829.55, 8061.73, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(5078, 860.30, 1834.19, 8056.02, 0.00, 0.00, 193.00, .interiorid = 34);
	CreateDynamicObject(1531, 867.44, 1829.54, 8056.04,   -25.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(18659, 867.45, 1829.58, 8056.05,   -25.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1763, 864.79, 1840.77, 8058.33, 0.00, 0.00, 91.00, .interiorid = 34);
	CreateDynamicObject(1758, 867.17, 1839.16, 8058.40, 0.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(1759, 865.01, 1846.26, 8058.35, 0.00, 0.00, 62.00, .interiorid = 34);
	CreateDynamicObject(1721, 868.14, 1845.54, 8058.39, 0.00, 0.00, 98.00, .interiorid = 34);
	CreateDynamicObject(1764, 868.56, 1841.86, 8058.31, 0.00, 0.00, -98.00, .interiorid = 34);
	CreateDynamicObject(937, 849.41, 1847.84, 8058.90, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(937, 851.30, 1847.83, 8058.90, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1575, 851.76, 1847.99, 8059.37, 0.00, 0.00, 98.00, .interiorid = 34);
	CreateDynamicObject(1575, 851.50, 1847.99, 8059.49, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1575, 851.33, 1848.01, 8059.37, 0.00, 0.00, 84.00, .interiorid = 34);
	CreateDynamicObject(1575, 849.86, 1847.94, 8059.37, 0.00, 0.00, 84.00, .interiorid = 34);
	CreateDynamicObject(1575, 849.41, 1847.93, 8059.35, 0.00, 0.00, 84.00, .interiorid = 34);
	CreateDynamicObject(1575, 849.41, 1847.93, 8058.97, 0.00, 0.00, 171.00, .interiorid = 34);
	CreateDynamicObject(1575, 849.41, 1847.93, 8058.58, 0.00, 0.00, 171.00, .interiorid = 34);
	CreateDynamicObject(1575, 851.32, 1847.99, 8058.58, 0.00, 0.00, 171.00, .interiorid = 34);
	CreateDynamicObject(349, 851.02, 1847.91, 8058.98,   81.20, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(945, 849.76, 1853.36, 8068.70, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(945, 849.76, 1854.86, 8068.70, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1764, 868.31, 1844.59, 8058.31, 0.00, 0.00, -84.00, .interiorid = 34);
	CreateDynamicObject(1763, 864.63, 1843.62, 8058.33, 0.00, 0.00, 76.00, .interiorid = 34);
	CreateDynamicObject(1721, 868.11, 1846.41, 8058.39, 0.00, 0.00, 113.00, .interiorid = 34);
	CreateDynamicObject(1721, 868.01, 1847.22, 8058.39, 0.00, 0.00, 113.00, .interiorid = 34);
	CreateDynamicObject(2762, 866.57, 1841.34, 8058.50, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(2762, 866.59, 1845.02, 8058.50, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(2670, 867.96, 1851.19, 8058.49, 0.00, 0.00, 91.00, .interiorid = 34);
	CreateDynamicObject(2674, 863.06, 1851.93, 8058.43, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2670, 869.29, 1848.30, 8058.52, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2673, 867.44, 1844.27, 8058.49, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2673, 867.25, 1839.36, 8058.49, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2673, 864.49, 1842.88, 8058.49, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2673, 865.40, 1846.04, 8058.49, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2670, 866.56, 1843.24, 8058.49, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2674, 866.70, 1840.83, 8058.42, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2670, 865.63, 1839.49, 8058.53, 0.00, 0.00, 113.00, .interiorid = 34);
	CreateDynamicObject(2670, 865.53, 1841.55, 8058.58, 0.00, 0.00, 280.00, .interiorid = 34);
	CreateDynamicObject(2670, 867.64, 1846.61, 8058.58, 0.00, 0.00, 280.00, .interiorid = 34);
	CreateDynamicObject(2674, 867.05, 1846.83, 8058.43, 0.00, 0.00, 62.00, .interiorid = 34);
	CreateDynamicObject(2670, 865.82, 1851.23, 8058.51, 0.00, 0.00, 91.00, .interiorid = 34);
	CreateDynamicObject(2674, 869.55, 1850.21, 8058.43, 0.00, 0.00, 62.00, .interiorid = 34);
	CreateDynamicObject(2670, 864.95, 1847.27, 8058.51, 0.00, 0.00, 33.00, .interiorid = 34);
	CreateDynamicObject(2670, 863.80, 1844.61, 8058.51, 0.00, 0.00, 113.00, .interiorid = 34);
	CreateDynamicObject(2670, 867.62, 1838.31, 8058.58, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2677, 865.02, 1840.06, 8058.64, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2677, 868.65, 1845.88, 8058.64, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2866, 866.93, 1841.86, 8058.92, 0.00, 0.00, 135.00, .interiorid = 34);
	CreateDynamicObject(2866, 868.53, 1842.25, 8058.42, 0.00, 0.00, 200.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.80, 1840.65, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.86, 1840.84, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.67, 1840.52, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.10, 1842.27, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.29, 1842.27, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.18, 1844.19, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.34, 1844.17, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.84, 1844.70, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.91, 1845.00, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.22, 1845.06, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.89, 1845.95, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.22, 1845.99, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.13, 1841.36, 8058.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 867.98, 1841.97, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 868.02, 1842.22, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 867.98, 1842.37, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 867.94, 1842.52, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 865.33, 1842.02, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 865.32, 1841.81, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.16, 1839.70, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.03, 1839.58, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 866.02, 1839.44, 8058.40, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(928, 868.21, 1839.46, 8058.68, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(928, 870.35, 1833.27, 8058.68, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2866, 866.77, 1845.46, 8058.92, 0.00, 0.00, 135.00, .interiorid = 34);
	CreateDynamicObject(346, 866.12, 1845.72, 8058.91,   90.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(346, 866.46, 1845.20, 8058.91,   90.00, 0.00, 33.00, .interiorid = 34);
	CreateDynamicObject(346, 866.58, 1844.19, 8058.91,   90.00, 0.00, 76.00, .interiorid = 34);
	CreateDynamicObject(346, 866.29, 1841.81, 8058.91,   90.00, 0.00, 76.00, .interiorid = 34);
	CreateDynamicObject(346, 866.96, 1841.10, 8058.91,   90.00, 0.00, -164.00, .interiorid = 34);
	CreateDynamicObject(346, 866.14, 1840.89, 8058.91,   90.00, 0.00, 47.00, .interiorid = 34);
	CreateDynamicObject(352, 866.29, 1840.49, 8058.93,   91.00, 4.00, 113.00, .interiorid = 34);
	CreateDynamicObject(352, 866.30, 1844.31, 8058.93,   91.00, 4.00, 113.00, .interiorid = 34);
	CreateDynamicObject(352, 866.84, 1844.93, 8058.93,   91.00, 4.00, 258.00, .interiorid = 34);
	CreateDynamicObject(352, 866.92, 1841.51, 8058.93,   91.00, 4.00, 258.00, .interiorid = 34);
	CreateDynamicObject(372, 866.97, 1844.34, 8058.90,   90.00, 0.00, -113.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.13, 1845.65, 8058.93, 0.00, 0.00, 193.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.12, 1845.25, 8058.93, 0.00, 0.00, -62.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.11, 1844.84, 8058.93, 0.00, 0.00, -62.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.98, 1844.47, 8058.93, 0.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(1665, 867.01, 1845.25, 8058.93, 0.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(1665, 867.00, 1845.52, 8058.93, 0.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(1665, 867.03, 1845.87, 8058.93, 0.00, 0.00, 69.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.08, 1842.03, 8058.93, 0.00, 0.00, -91.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.10, 1841.59, 8058.93, 0.00, 0.00, -91.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.09, 1841.16, 8058.93, 0.00, 0.00, -91.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.43, 1840.44, 8058.93, 0.00, 0.00, -91.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.69, 1840.98, 8058.93, 0.00, 0.00, -91.00, .interiorid = 34);
	CreateDynamicObject(1665, 866.45, 1844.79, 8058.93, 0.00, 0.00, -62.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.00, 1841.13, 8058.95, 0.00, 0.00, -4.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.07, 1841.83, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.12, 1841.37, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.66, 1841.19, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.53, 1840.23, 8058.95, 0.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.08, 1842.25, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.05, 1845.10, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.12, 1845.50, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.28, 1845.81, 8058.95, 0.00, 0.00, -47.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.45, 1845.05, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.90, 1844.73, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.92, 1845.52, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.95, 1845.76, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 866.96, 1846.10, 8058.95, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(355, 866.65, 1840.17, 8058.69,   -25.00, 287.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1420, 850.63, 1847.23, 8062.92,   270.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3027, 866.16, 1845.10, 8058.92,   90.00, 0.00, 171.00, .interiorid = 34);
	CreateDynamicObject(3027, 866.52, 1844.66, 8058.92,   90.00, 0.00, 171.00, .interiorid = 34);
	CreateDynamicObject(3095, 867.37, 1849.14, 8053.82,   90.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(1499, 861.38, 1849.24, 8054.29, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3095, 867.35, 1849.71, 8053.82,   90.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1533, 863.84, 1849.28, 8058.29, 0.00, 90.00, 180.00, .interiorid = 34);
	CreateDynamicObject(3092, 869.81, 1856.72, 8054.54,   98.00, 4.00, 84.00, .interiorid = 34);
	CreateDynamicObject(1756, 868.05, 1856.16, 8054.27, 0.00, 0.00, -18.00, .interiorid = 34);
	CreateDynamicObject(1756, 870.18, 1854.09, 8054.27, 0.00, 0.00, -91.00, .interiorid = 34);
	CreateDynamicObject(1757, 869.19, 1851.07, 8054.29, 0.00, 0.00, 200.00, .interiorid = 34);
	CreateDynamicObject(2100, 864.84, 1849.84, 8054.29, 0.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(1757, 864.66, 1856.62, 8054.29, 0.00, 0.00, -4.00, .interiorid = 34);
	CreateDynamicObject(1735, 862.97, 1856.30, 8054.22, 0.00, 0.00, 34.00, .interiorid = 34);
	CreateDynamicObject(1735, 862.09, 1854.94, 8054.22, 0.00, 0.00, 76.00, .interiorid = 34);
	CreateDynamicObject(2726, 863.56, 1855.09, 8054.65, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2726, 865.95, 1855.40, 8054.65, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2726, 868.72, 1854.89, 8054.65, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2726, 869.12, 1853.13, 8054.65, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2726, 867.82, 1851.63, 8054.65, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 867.73, 1851.77, 8054.87, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 869.05, 1853.31, 8054.86, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 867.76, 1851.79, 8054.86, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 863.51, 1855.21, 8054.86, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(2637, 868.01, 1853.46, 8054.29, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(2637, 864.39, 1854.21, 8054.29, 0.00, 0.00, 47.00, .interiorid = 34);
	CreateDynamicObject(1544, 868.39, 1852.63, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 868.01, 1852.60, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 868.33, 1854.30, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 867.47, 1854.37, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 867.24, 1856.05, 8054.27, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 864.26, 1856.23, 8054.27, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 862.81, 1855.67, 8054.27, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 862.51, 1855.35, 8054.27, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 862.39, 1854.36, 8054.27, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 863.57, 1853.86, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 863.64, 1853.71, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 863.80, 1853.58, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 863.85, 1853.79, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 865.33, 1854.54, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 864.95, 1854.84, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 865.06, 1854.58, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 865.16, 1854.47, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 864.15, 1854.72, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1544, 864.26, 1853.41, 8054.72, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(346, 864.26, 1853.25, 8054.72,   90.00, 0.00, 178.00, .interiorid = 34);
	CreateDynamicObject(372, 868.30, 1853.93, 8054.70,   90.00, 0.00, -55.00, .interiorid = 34);
	CreateDynamicObject(349, 864.08, 1856.46, 8054.54, 0.00, -47.00, 0.00, .interiorid = 34);
	CreateDynamicObject(352, 867.59, 1852.71, 8054.72,   90.00, 0.00, 47.00, .interiorid = 34);
	CreateDynamicObject(335, 864.76, 1854.33, 8054.69,   90.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(352, 867.54, 1854.09, 8054.72,   90.00, 0.00, 47.00, .interiorid = 34);
	CreateDynamicObject(352, 864.69, 1854.99, 8054.73,   90.00, 18.00, 47.00, .interiorid = 34);
	CreateDynamicObject(1668, 864.52, 1854.40, 8054.88, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1668, 864.35, 1854.24, 8054.88, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1668, 867.77, 1853.57, 8054.88, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1668, 867.88, 1853.46, 8054.88, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1665, 863.97, 1854.50, 8054.73, 0.00, 0.00, 185.00, .interiorid = 34);
	CreateDynamicObject(1665, 863.74, 1854.28, 8054.73, 0.00, 0.00, 185.00, .interiorid = 34);
	CreateDynamicObject(1665, 864.50, 1855.07, 8054.73, 0.00, 0.00, 185.00, .interiorid = 34);
	CreateDynamicObject(1665, 865.04, 1854.29, 8054.73, 0.00, 0.00, 18.00, .interiorid = 34);
	CreateDynamicObject(1665, 867.78, 1854.34, 8054.73, 0.00, 0.00, 113.00, .interiorid = 34);
	CreateDynamicObject(1665, 868.13, 1854.33, 8054.73, 0.00, 0.00, 113.00, .interiorid = 34);
	CreateDynamicObject(3044, 863.74, 1854.44, 8054.75, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 863.94, 1854.71, 8054.75, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 864.29, 1854.95, 8054.75, 0.00, 0.00, 91.00, .interiorid = 34);
	CreateDynamicObject(3044, 864.91, 1854.53, 8054.75, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 865.88, 1855.50, 8054.82, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(3044, 867.63, 1854.10, 8054.76, 0.00, 0.00, 142.00, .interiorid = 34);
	CreateDynamicObject(3044, 868.00, 1854.08, 8054.76, 0.00, 0.00, 142.00, .interiorid = 34);
	CreateDynamicObject(3044, 868.67, 1854.73, 8054.76, 0.00, 0.00, 142.00, .interiorid = 34);
	CreateDynamicObject(3044, 865.97, 1855.26, 8054.76, 0.00, 0.00, 142.00, .interiorid = 34);
	CreateDynamicObject(18659, 869.33, 1849.72, 8056.56,   1.51, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(18659, 865.91, 1849.71, 8056.82,   25.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(1530, 869.35, 1849.70, 8056.59, 0.00, 0.00, 270.00, .interiorid = 34);
	CreateDynamicObject(17969, 865.92, 1849.10, 8055.78, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(18659, 869.20, 1849.12, 8057.12,   10.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(2204, 867.94, 1856.98, 8058.10, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(942, 869.61, 1837.78, 8056.62, 0.00, 0.00, 90.00, .interiorid = 34);
	CreateDynamicObject(1520, 868.14, 1856.68, 8059.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1520, 868.89, 1856.70, 8059.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1520, 869.04, 1856.71, 8059.89, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(1512, 868.67, 1856.71, 8060.02, 0.00, 0.00, 16.00, .interiorid = 34);
	CreateDynamicObject(1512, 867.93, 1856.64, 8060.02, 0.00, 0.00, 16.00, .interiorid = 34);
	CreateDynamicObject(1512, 868.38, 1856.69, 8060.02, 0.00, 0.00, 16.00, .interiorid = 34);
	CreateDynamicObject(1512, 869.44, 1856.64, 8060.02, 0.00, 0.00, 16.00, .interiorid = 34);
	CreateDynamicObject(348, 870.15, 1856.74, 8059.15,   90.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(348, 869.31, 1856.80, 8058.85,   90.00, 0.00, 180.00, .interiorid = 34);
	CreateDynamicObject(18659, 870.67, 1854.85, 8058.57, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(945, 853.77, 1851.88, 8068.70, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(945, 853.77, 1853.38, 8068.70, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(945, 853.77, 1856.38, 8068.70, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(945, 853.75, 1854.86, 8068.70, 0.00, 0.00, 0.00, .interiorid = 34);
	CreateDynamicObject(945, 849.76, 1856.36, 8068.70, 0.00, 0.00, 0.00, .interiorid = 34);
	
	// Government interior
	CreateDynamicObject(14602, -1199.60, -156.13, 4896.20, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(14593, -1216.27, -126.06, 4893.16, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(14598, -1211.39, -155.99, 4906.37, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3657, -1214.97, -120.59, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1219.91, -120.65, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1214.97, -122.59, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1219.91, -122.65, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1219.91, -124.65, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1214.97, -124.59, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1214.97, -126.09, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1219.91, -126.15, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1214.97, -127.59, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(3657, -1219.91, -127.65, 4891.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2773, -1219.67, -118.17, 4891.33, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2773, -1217.75, -118.18, 4891.33, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2773, -1215.83, -118.19, 4891.33, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2773, -1213.91, -118.20, 4891.33, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2773, -1221.60, -118.18, 4891.33, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2773, -1211.99, -118.21, 4891.33, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(950, -1210.83, -118.22, 4892.03, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(950, -1210.82, -118.16, 4890.97, 0.00, 180.00, 90.00, .interiorid = 33);
	CreateDynamicObject(950, -1210.82, -118.16, 4890.61, 0.00, 180.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2395, -1222.22, -118.06, 4891.35,   270.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2395, -1218.51, -118.06, 4891.35,   270.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2395, -1214.78, -118.06, 4891.23,   -76.00, 90.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2395, -1218.51, -118.12, 4888.57, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2395, -1222.23, -118.11, 4888.57, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2395, -1216.60, -118.12, 4888.57, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2395, -1213.85, -117.95, 4888.56, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2395, -1222.78, -115.31, 4890.82, 0.00, 90.00, 270.00, .interiorid = 33);
	CreateDynamicObject(1721, -1221.78, -116.03, 4891.28, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1721, -1221.06, -116.08, 4891.28, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1721, -1220.32, -116.11, 4891.28, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2491, -1217.71, -117.38, 4890.34, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2614, -1218.23, -115.46, 4893.04, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2894, -1218.15, -117.61, 4892.23, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2491, -1218.11, -117.38, 4890.34, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(14596, -1201.99, -171.28, 4901.52, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1892, -1210.02, -139.14, 4890.83, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1892, -1210.05, -134.23, 4890.83, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(14595, -1211.41, -156.03, 4900.58, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3095, -1206.96, -166.46, 4912.11,   90.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(2198, -1214.18, -136.85, 4896.62, 0.00, 0.00, 45.00, .interiorid = 33);
	CreateDynamicObject(2198, -1214.14, -135.41, 4896.62, 0.00, 0.00, 135.00, .interiorid = 33);
	CreateDynamicObject(2198, -1215.58, -135.42, 4896.62, 0.00, 0.00, 316.00, .interiorid = 33);
	CreateDynamicObject(2198, -1215.52, -134.00, 4896.62, 0.00, 0.00, 225.00, .interiorid = 33);
	CreateDynamicObject(2356, -1215.80, -136.68, 4896.60, 0.00, 0.00, -25.00, .interiorid = 33);
	CreateDynamicObject(2356, -1213.06, -137.15, 4896.60, 0.00, 0.00, 40.00, .interiorid = 33);
	CreateDynamicObject(2356, -1213.97, -134.11, 4896.60, 0.00, 0.00, 142.00, .interiorid = 33);
	CreateDynamicObject(2356, -1216.81, -133.75, 4896.60, 0.00, 0.00, 215.00, .interiorid = 33);
	CreateDynamicObject(2198, -1218.35, -137.65, 4896.62, 0.00, 0.00, 135.00, .interiorid = 33);
	CreateDynamicObject(2198, -1221.14, -139.01, 4896.62, 0.00, 0.00, 315.00, .interiorid = 33);
	CreateDynamicObject(2198, -1219.73, -139.07, 4896.62, 0.00, 0.00, 45.00, .interiorid = 33);
	CreateDynamicObject(2198, -1219.75, -137.62, 4896.62, 0.00, 0.00, 225.00, .interiorid = 33);
	CreateDynamicObject(2356, -1220.77, -137.40, 4896.60, 0.00, 0.00, 215.00, .interiorid = 33);
	CreateDynamicObject(2356, -1217.81, -136.92, 4896.60, 0.00, 0.00, 105.00, .interiorid = 33);
	CreateDynamicObject(2356, -1218.53, -139.48, 4896.60, 0.00, 0.00, 55.00, .interiorid = 33);
	CreateDynamicObject(2356, -1221.20, -140.23, 4896.60, 0.00, 0.00, 331.00, .interiorid = 33);
	CreateDynamicObject(2202, -1209.37, -137.21, 4896.63, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2186, -1226.94, -131.93, 4896.62, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1227.52, -137.14, 4896.63, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1227.52, -138.48, 4896.63, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1223.32, -142.44, 4896.63, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2198, -1223.80, -132.92, 4896.62, 0.00, 0.00, 225.00, .interiorid = 33);
	CreateDynamicObject(2198, -1222.37, -134.26, 4896.62, 0.00, 0.00, 135.00, .interiorid = 33);
	CreateDynamicObject(2198, -1223.85, -134.31, 4896.62, 0.00, 0.00, 316.00, .interiorid = 33);
	CreateDynamicObject(2198, -1222.43, -135.68, 4896.62, 0.00, 0.00, 45.00, .interiorid = 33);
	CreateDynamicObject(2356, -1223.86, -135.49, 4896.60, 0.00, 0.00, 331.00, .interiorid = 33);
	CreateDynamicObject(2356, -1221.26, -135.76, 4896.60, 0.00, 0.00, 55.00, .interiorid = 33);
	CreateDynamicObject(2356, -1221.97, -133.26, 4896.60, 0.00, 0.00, 142.00, .interiorid = 33);
	CreateDynamicObject(2356, -1224.76, -132.86, 4896.60, 0.00, 0.00, 215.00, .interiorid = 33);
	CreateDynamicObject(2163, -1227.53, -140.25, 4896.62, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2163, -1227.53, -140.25, 4897.52, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2193, -1222.54, -167.34, 4896.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2193, -1221.52, -165.44, 4896.60, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2193, -1224.44, -166.33, 4896.60, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(2193, -1223.43, -164.42, 4896.60, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2356, -1224.19, -164.61, 4896.60, 0.00, 0.00, 178.00, .interiorid = 33);
	CreateDynamicObject(2356, -1224.59, -167.37, 4896.60, 0.00, 0.00, 280.00, .interiorid = 33);
	CreateDynamicObject(2356, -1221.55, -167.38, 4896.60, 0.00, 0.00, 25.00, .interiorid = 33);
	CreateDynamicObject(2356, -1221.48, -164.70, 4896.60, 0.00, 0.00, 69.00, .interiorid = 33);
	CreateDynamicObject(2186, -1227.51, -169.07, 4896.56, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(644, -1227.07, -162.52, 4896.62, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2256, -1219.01, -165.36, 4898.83, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(2281, -1224.34, -169.35, 4898.96, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2258, -1221.03, -142.39, 4899.35, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2266, -1227.03, -136.35, 4898.96, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2271, -1211.19, -132.31, 4899.06, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(2270, -1211.20, -133.34, 4899.08, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(2286, -1210.72, -134.55, 4899.41, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(2265, -1227.03, -133.81, 4898.75, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1536, -1235.00, -160.91, 4896.63, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(14600, -1209.02, -141.99, 4898.12, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1713, -1205.78, -160.33, 4896.58, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1713, -1203.02, -160.36, 4896.58, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1713, -1202.81, -156.69, 4896.59, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(1713, -1202.81, -153.68, 4896.59, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(2257, -1202.37, -155.50, 4899.29, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(2126, -1204.94, -157.45, 4896.88, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2852, -1205.49, -157.35, 4897.37, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2816, -1205.47, -156.55, 4897.39, 0.00, 0.00, 207.00, .interiorid = 33);
	CreateDynamicObject(644, -1203.14, -152.01, 4896.80, 0.00, 0.00, 164.00, .interiorid = 33);
	CreateDynamicObject(14632, -1211.60, -132.96, 4898.09, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(14632, -1218.91, -133.20, 4898.09, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1225.60, -142.44, 4896.63, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1713, -1242.68, -151.56, 4896.57, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1713, -1238.02, -151.47, 4896.57, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1708, -1240.03, -151.56, 4896.62, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(19172, -1239.68, -150.96, 4899.09, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(19173, -1229.31, -160.95, 4899.72, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(644, -1224.83, -160.04, 4896.88, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(644, -1247.76, -159.76, 4896.88, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(14595, -1217.05, -210.16, 4900.58, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1536, -1217.85, -196.58, 4896.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2206, -1222.00, -191.84, 4896.57, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2206, -1222.98, -191.84, 4896.57, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2206, -1223.94, -191.85, 4896.57, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2206, -1224.88, -191.85, 4896.57, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2206, -1225.86, -191.86, 4896.57, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2206, -1226.84, -191.86, 4896.57, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2206, -1227.83, -189.98, 4896.57, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(1714, -1229.37, -190.91, 4896.61, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1671, -1227.66, -188.97, 4897.04, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1671, -1225.94, -188.88, 4897.04, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1671, -1224.01, -188.82, 4897.04, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1671, -1222.32, -188.74, 4897.04, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1671, -1220.72, -190.85, 4897.04, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(1671, -1222.71, -192.74, 4897.04, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1671, -1224.41, -192.71, 4897.04, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1671, -1225.99, -192.81, 4897.04, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1671, -1227.51, -192.79, 4897.04, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2253, -1223.32, -191.01, 4897.68, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2253, -1225.27, -191.06, 4897.68, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2253, -1227.21, -191.11, 4897.68, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2894, -1227.84, -190.46, 4897.52, 0.00, 0.00, 287.00, .interiorid = 33);
	CreateDynamicObject(14532, -1232.83, -195.12, 4897.59, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(19175, -1216.33, -187.41, 4899.21, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(19172, -1223.49, -195.95, 4899.01, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2257, -1233.13, -190.95, 4898.94, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2002, -1215.73, -190.49, 4896.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1721, -1214.87, -192.69, 4896.63, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1721, -1214.88, -193.53, 4896.63, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1721, -1214.89, -194.29, 4896.63, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1721, -1214.85, -195.14, 4896.63, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1721, -1214.86, -196.05, 4896.63, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2001, -1232.54, -185.12, 4896.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2266, -1215.23, -193.38, 4899.11, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(1536, -1207.17, -168.28, 4902.43, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1508, -1207.14, -165.88, 4903.76, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2240, -1196.40, -164.94, 4902.87, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(948, -1196.33, -177.88, 4900.43, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(950, -1196.13, -177.82, 4895.10, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(638, -1197.04, -164.96, 4897.27, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(4186, -1357.12, -206.09, 5896.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3985, -1357.07, -144.56, 5889.06, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3980, -1365.88, -296.59, 5899.58, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4163, -1367.37, -244.73, 5889.56, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3997, -1365.09, -313.45, 5889.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4148, -1409.62, -174.76, 5889.57, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4150, -1304.57, -174.78, 5889.54, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3975, -1257.96, -188.16, 5889.59, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3976, -1264.82, -187.49, 5912.06, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3994, -1357.09, -105.78, 5889.64, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4016, -1339.34, -56.24, 5894.48, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4005, -1433.92, -194.59, 5902.44, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(3978, -1456.22, -168.07, 5887.91, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4006, -1442.92, -131.01, 5908.08, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4197, -1456.12, -168.12, 5887.94, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(4008, -1429.34, -55.83, 5896.75, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4144, -1394.46, -31.23, 5889.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4550, -1278.63, 72.01, 5845.30, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4601, -1319.59, 27.23, 5933.22, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4007, -1418.84, 19.11, 5911.08, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4129, -1248.12, -95.08, 5900.27, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4113, -1464.47, -96.28, 5922.92, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4603, -1208.87, -10.64, 5905.98, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(713, -1339.79, -214.66, 5890.54, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(700, -1373.59, -200.93, 5890.54, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(673, -1378.44, -213.11, 5890.54, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(700, -1373.30, -210.38, 5890.54, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(673, -1378.39, -223.93, 5890.54, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(712, -1363.95, -180.04, 5899.97, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(712, -1352.84, -180.56, 5899.97, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(713, -1378.86, -133.12, 5890.98, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4206, -1357.31, -152.67, 5890.61, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4003, -1365.72, -258.51, 5911.98, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(620, -1289.08, -202.32, 5886.38, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(620, -1289.13, -173.99, 5886.38, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(647, -1289.21, -175.02, 5890.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(647, -1289.73, -170.21, 5890.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(647, -1289.76, -199.15, 5890.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(647, -1289.78, -204.24, 5890.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(620, -1294.45, -221.02, 5886.38, 0.00, 0.00, -0.06, .interiorid = 33);
	CreateDynamicObject(620, -1294.64, -155.85, 5886.38, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(14623, -1364.72, -311.57, 5923.54, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(14623, -1364.76, -311.57, 5916.39,   180.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(14455, -1358.79, -279.10, 5919.62, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(14455, -1358.81, -285.31, 5919.62, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(14455, -1370.76, -280.19, 5919.62, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(4148, -1367.06, -272.98, 5919.81, 0.00, 90.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1649, -1369.17, -272.89, 5920.22, 0.00, 90.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1649, -1365.90, -272.92, 5920.22, 0.00, 90.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1649, -1362.58, -272.93, 5920.22, 0.00, 90.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1649, -1359.26, -272.93, 5920.22, 0.00, 90.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2207, -1365.53, -277.16, 5917.99, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2614, -1364.49, -272.98, 5920.89, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1714, -1364.54, -275.24, 5917.96, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2894, -1364.39, -277.07, 5918.77, 0.00, 0.00, 215.00, .interiorid = 33);
	CreateDynamicObject(2190, -1365.87, -276.50, 5918.76, 0.00, 0.00, 113.00, .interiorid = 33);
	CreateDynamicObject(14455, -1358.82, -291.36, 5919.62, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1671, -1363.07, -277.29, 5918.43, 0.00, 0.00, 222.00, .interiorid = 33);
	CreateDynamicObject(1671, -1364.07, -277.94, 5918.43, 0.00, 0.00, 200.00, .interiorid = 33);
	CreateDynamicObject(1671, -1365.34, -277.91, 5918.43, 0.00, 0.00, 156.00, .interiorid = 33);
	CreateDynamicObject(1671, -1366.46, -277.22, 5918.43, 0.00, 0.00, 135.00, .interiorid = 33);
	CreateDynamicObject(19172, -1370.86, -276.92, 5920.62, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(19174, -1370.85, -288.73, 5920.59, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1726, -1370.35, -289.65, 5917.96, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1727, -1368.07, -290.62, 5917.96, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(1727, -1368.90, -286.82, 5917.96, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1822, -1369.17, -289.18, 5917.94, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2852, -1368.70, -288.71, 5918.03, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1455, -1368.79, -288.98, 5918.50, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1455, -1369.06, -288.73, 5918.50, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1455, -1369.03, -288.46, 5918.50, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1455, -1368.71, -288.28, 5918.50, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1536, -1364.26, -293.13, 5917.99, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(4005, -1340.70, -303.98, 5921.35, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(4005, -1352.23, -303.99, 5921.35, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(19173, -1361.51, -293.14, 5920.39, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(644, -1359.84, -292.39, 5918.26, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(644, -1369.66, -275.65, 5918.26, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2253, -1368.61, -288.64, 5918.69, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(948, -1370.31, -292.47, 5917.94, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2252, -1363.68, -276.53, 5919.04, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2258, -1368.02, -293.05, 5920.34, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(4107, -1475.82, -314.60, 5889.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4158, -1227.30, -244.75, 5889.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(4158, -1507.23, -105.55, 5889.34, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1533, -1184.92, -156.86, 4890.83, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1768, -1206.15, -140.87, 4890.81, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1768, -1202.43, -140.95, 4890.81, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1768, -1199.10, -142.53, 4890.81, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(1768, -1199.01, -147.32, 4890.81, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(1769, -1199.05, -145.52, 4890.83, 0.00, 0.00, 270.00, .interiorid = 33);
	CreateDynamicObject(644, -1199.43, -141.22, 4891.05, 0.00, 0.00, 215.00, .interiorid = 33);
	CreateDynamicObject(2126, -1203.79, -143.42, 4890.83, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2126, -1200.45, -146.35, 4890.83, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2253, -1201.01, -146.44, 4891.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2253, -1203.94, -142.92, 4891.60, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2852, -1203.20, -142.90, 4890.94, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2816, -1200.74, -145.60, 4891.33, 0.00, 0.00, 105.00, .interiorid = 33);
	CreateDynamicObject(1455, -1203.31, -142.52, 4891.41, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1455, -1203.03, -142.51, 4891.41, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1455, -1202.57, -142.52, 4891.41, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1455, -1200.62, -145.15, 4891.41, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1455, -1200.55, -146.14, 4891.41, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1775, -1204.10, -149.64, 4891.93, 0.00, 0.00, 180.00, .interiorid = 33);
	CreateDynamicObject(2190, -1216.55, -158.58, 4891.54, 0.00, 0.00, -149.00, .interiorid = 33);
	CreateDynamicObject(2190, -1216.57, -154.10, 4891.54, 0.00, 0.00, -55.00, .interiorid = 33);
	CreateDynamicObject(2356, -1217.78, -157.41, 4890.79, 0.00, 0.00, -127.00, .interiorid = 33);
	CreateDynamicObject(2356, -1217.80, -154.96, 4890.79, 0.00, 0.00, -55.00, .interiorid = 33);
	CreateDynamicObject(2191, -1222.13, -158.15, 4890.83, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2191, -1222.06, -153.96, 4890.83, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2202, -1221.74, -141.03, 4890.78, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2197, -1221.60, -156.87, 4890.83, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2197, -1221.60, -156.20, 4890.83, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2197, -1221.60, -155.51, 4890.83, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2197, -1221.60, -154.83, 4890.83, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2252, -1222.41, -155.84, 4892.79, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(950, -1198.88, -151.07, 4891.33, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(948, -1198.99, -162.82, 4890.83, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2253, -1218.91, -153.72, 4892.03, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2253, -1218.92, -158.83, 4892.03, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(948, -1214.25, -140.68, 4890.83, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2161, -1222.47, -152.23, 4890.87, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1222.46, -150.91, 4890.87, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1222.45, -149.61, 4890.87, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1222.46, -148.30, 4890.87, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1222.49, -159.75, 4890.87, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1222.50, -161.08, 4890.87, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1222.50, -162.41, 4890.87, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2161, -1222.49, -163.73, 4890.87, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(2001, -1211.76, -130.40, 4890.83, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(2001, -1219.77, -130.46, 4890.83, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1890, -1205.54, -151.11, 4896.62, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1977, -1206.45, -151.60, 4896.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1977, -1205.48, -151.59, 4896.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1536, -1206.96, -168.21, 4908.20, 0.00, 0.00, 90.00, .interiorid = 33);
	CreateDynamicObject(1977, -1204.50, -151.62, 4896.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1890, -1206.38, -151.09, 4896.62, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1977, -1207.44, -151.59, 4896.63, 0.00, 0.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1508, -1209.99, -140.06, 4890.69, 0.00, 90.00, 0.00, .interiorid = 33);
	CreateDynamicObject(1508, -1203.27, -167.62, 4893.99, 0.00, 90.00, 0.00, .interiorid = 33);
	
	// BBS HQ
	CreateDynamicObject(14408, 870.70, 1821.96, 5078.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(13607, 863.98, 1816.49, 5075.19, 0.00, 90.00, 0.00, .interiorid = 32);
	CreateDynamicObject(8133, 852.36, 1819.65, 5075.62, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(8133, 852.36, 1819.65, 5074.44,   180.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(7191, 870.40, 1830.00, 5075.09, 0.00, 90.00, 0.00, .interiorid = 32);
	CreateDynamicObject(7191, 870.40, 1828.08, 5074.99, 0.00, 90.00, 0.00, .interiorid = 32);
	CreateDynamicObject(10008, 876.03, 1829.85, 5073.47, 0.00, 0.00, -156.00, .interiorid = 32);
	CreateDynamicObject(970, 872.33, 1833.47, 5075.72, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(970, 872.34, 1824.22, 5075.72, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(970, 872.34, 1820.07, 5075.72, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(970, 872.35, 1815.92, 5075.72, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(970, 872.36, 1811.79, 5075.72, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(970, 872.37, 1807.63, 5075.72, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(3095, 876.63, 1835.57, 5070.83,   90.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.79, 1817.80, 5077.47, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.78, 1822.19, 5077.47, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.78, 1826.59, 5077.47, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.78, 1830.99, 5077.47, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.42, 1831.07, 5077.47, 0.00, 0.00, 270.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.42, 1826.63, 5077.47, 0.00, 0.00, 270.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.42, 1822.22, 5077.47, 0.00, 0.00, 270.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.42, 1817.80, 5077.47, 0.00, 0.00, 270.00, .interiorid = 32);
	CreateDynamicObject(14409, 890.44, 1818.67, 5072.02, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1492, 869.23, 1808.12, 5068.82, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.42, 1821.80, 5070.80, 0.00, 0.00, 270.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.43, 1829.80, 5070.80, 0.00, 0.00, 270.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.81, 1829.68, 5070.81, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1649, 880.81, 1821.60, 5070.81, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(14746, 897.96, 1814.46, 5076.98, 0.00, 0.00, 179.99, .interiorid = 32);
	CreateDynamicObject(5153, 901.96, 1809.17, 5076.28,   90.00, 24.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1495, 902.51, 1809.31, 5074.81, 0.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(5153, 892.84, 1808.77, 5076.28, 0.00, 114.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1490, 860.44, 1809.73, 5079.25,   6.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1525, 860.43, 1821.17, 5079.15,   -10.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1527, 860.45, 1815.71, 5079.08, 0.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1525, 860.46, 1812.59, 5076.63,   10.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1490, 860.45, 1831.71, 5079.25,   6.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(17969, 860.49, 1826.67, 5077.23, 0.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1527, 860.47, 1828.74, 5076.34, 0.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(14840, 885.49, 1808.12, 5070.65, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(4227, 860.36, 1821.99, 5070.27, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(17969, 860.46, 1830.14, 5072.42,   20.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1527, 860.48, 1832.05, 5070.62, 0.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1531, 860.44, 1821.37, 5073.16,   5.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(949, 902.70, 1809.50, 5075.80, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(949, 900.70, 1809.40, 5075.80, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1766, 900.40, 1818.90, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2315, 900.70, 1817.20, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(3119, 900.00, 1817.50, 5075.49, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1666, 900.38, 1816.86, 5075.75, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 901.10, 1817.40, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1951, 902.46, 1817.50, 5075.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1664, 900.33, 1816.96, 5075.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(16151, 893.90, 1816.70, 5075.50, 0.00, 0.00, 178.00, .interiorid = 32);
	CreateDynamicObject(1950, 894.90, 1815.60, 5076.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1950, 894.50, 1813.60, 5076.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1950, 894.90, 1817.60, 5076.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1950, 894.70, 1816.80, 5076.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1950, 895.00, 1814.60, 5076.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(949, 881.20, 1808.40, 5075.80, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(949, 882.20, 1814.80, 5075.80, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(949, 886.50, 1814.90, 5075.80, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2173, 889.50, 1829.10, 5075.20, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1671, 890.00, 1829.60, 5075.70, 0.00, 0.00, 294.00, .interiorid = 32);
	CreateDynamicObject(2190, 889.10, 1829.20, 5076.00, 0.00, 0.00, 98.00, .interiorid = 32);
	CreateDynamicObject(2229, 889.70, 1836.00, 5076.60, 0.00, 0.00, 12.00, .interiorid = 32);
	CreateDynamicObject(646, 889.20, 1830.80, 5076.60, 0.00, 0.00, 64.00, .interiorid = 32);
	CreateDynamicObject(2773, 886.00, 1816.80, 5075.70, 0.00, 0.00, 14.00, .interiorid = 32);
	CreateDynamicObject(2773, 883.00, 1816.60, 5075.70, 0.00, 0.00, 342.00, .interiorid = 32);
	CreateDynamicObject(2670, 864.20, 1812.10, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2671, 865.50, 1817.70, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2672, 861.90, 1818.20, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 864.50, 1831.30, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2674, 865.20, 1826.60, 5075.20, 0.00, 0.00, 28.00, .interiorid = 32);
	CreateDynamicObject(2676, 864.80, 1822.70, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2231, 860.40, 1808.30, 5076.71, 0.00, 0.00, 144.00, .interiorid = 32);
	CreateDynamicObject(2225, 863.21, 1808.74, 5075.00, 0.00, 0.00, 176.00, .interiorid = 32);
	CreateDynamicObject(2231, 864.70, 1835.60, 5078.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2231, 868.50, 1835.60, 5078.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2231, 860.40, 1829.60, 5078.70, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1764, 860.80, 1811.20, 5075.20, 0.00, 0.00, 87.99, .interiorid = 32);
	CreateDynamicObject(2673, 860.60, 1812.50, 5075.70, 0.00, 0.00, 256.00, .interiorid = 32);
	CreateDynamicObject(3593, 863.10, 1832.40, 5069.20, 0.00, 0.00, 154.00, .interiorid = 32);
	CreateDynamicObject(1428, 864.40, 1835.20, 5076.80, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1473, 865.50, 1832.70, 5069.00,   9.99, 2.03, 65.65, .interiorid = 32);
	CreateDynamicObject(3496, 860.50, 1808.50, 5068.90, 0.00, 0.00, 312.00, .interiorid = 32);
	CreateDynamicObject(3109, 869.70, 1808.40, 5070.10, 0.00, 0.00, 268.00, .interiorid = 32);
	CreateDynamicObject(2114, 866.10, 1813.60, 5069.00, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2232, 892.30, 1835.80, 5075.80, 0.00, 0.00, 330.00, .interiorid = 32);
	CreateDynamicObject(2232, 881.10, 1835.60, 5075.80, 0.00, 0.00, 54.00, .interiorid = 32);
	CreateDynamicObject(2894, 889.50, 1830.20, 5076.00, 0.00, 0.00, 36.00, .interiorid = 32);
	CreateDynamicObject(2231, 860.60, 1814.00, 5075.20, 0.00, 0.00, 70.00, .interiorid = 32);
	CreateDynamicObject(2231, 880.40, 1813.10, 5077.00, 0.00, 0.00, 260.00, .interiorid = 32);
	CreateDynamicObject(1829, 891.80, 1828.90, 5075.70, 0.00, 0.00, 230.00, .interiorid = 32);
	CreateDynamicObject(2194, 889.20, 1829.70, 5076.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2269, 892.00, 1832.50, 5076.50, 0.00, 0.00, 270.00, .interiorid = 32);
	CreateDynamicObject(2173, 889.10, 1834.40, 5075.20, 0.00, 0.00, 46.00, .interiorid = 32);
	CreateDynamicObject(2194, 889.20, 1829.70, 5076.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1671, 890.10, 1834.40, 5075.70, 0.00, 0.00, 266.00, .interiorid = 32);
	CreateDynamicObject(2190, 888.90, 1834.60, 5076.00, 0.00, 0.00, 68.00, .interiorid = 32);
	CreateDynamicObject(2922, 891.65, 1829.54, 5075.73, 0.00, 0.00, 320.00, .interiorid = 32);
	CreateDynamicObject(2894, 889.60, 1834.80, 5076.00, 0.00, 0.00, 44.00, .interiorid = 32);
	CreateDynamicObject(2710, 889.20, 1829.40, 5076.10, 0.00, 0.00, 114.00, .interiorid = 32);
	CreateDynamicObject(2671, 866.50, 1817.30, 5068.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2671, 868.00, 1814.60, 5068.90, 0.00, 0.00, 38.00, .interiorid = 32);
	CreateDynamicObject(2671, 874.00, 1813.80, 5068.90, 0.00, 0.00, 70.00, .interiorid = 32);
	CreateDynamicObject(2671, 873.70, 1829.20, 5069.00, 0.00, 0.00, 83.99, .interiorid = 32);
	CreateDynamicObject(2671, 865.10, 1829.60, 5068.90, 0.00, 0.00, 101.99, .interiorid = 32);
	CreateDynamicObject(2671, 868.70, 1823.30, 5068.90, 0.00, 0.00, 101.99, .interiorid = 32);
	CreateDynamicObject(2671, 864.90, 1822.50, 5068.90, 0.00, 0.00, 115.98, .interiorid = 32);
	CreateDynamicObject(2673, 868.40, 1823.40, 5068.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 864.90, 1830.00, 5068.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 874.00, 1829.20, 5068.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 871.20, 1813.40, 5068.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 881.20, 1813.20, 5068.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 870.40, 1819.30, 5068.90, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1764, 862.70, 1814.90, 5075.20, 0.00, 0.00, 11.99, .interiorid = 32);
	CreateDynamicObject(1764, 867.30, 1813.20, 5075.20, 0.00, 0.00, 259.99, .interiorid = 32);
	CreateDynamicObject(1764, 866.15, 1809.62, 5075.20, 0.00, 0.00, 191.98, .interiorid = 32);
	CreateDynamicObject(2315, 862.39, 1809.11, 5075.20, 0.00, 0.00, 149.00, .interiorid = 32);
	CreateDynamicObject(2673, 860.40, 1814.80, 5075.29, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 864.50, 1814.40, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 864.20, 1812.00, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 866.50, 1812.00, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 869.60, 1811.90, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 868.90, 1825.00, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 869.80, 1818.30, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 864.30, 1824.00, 5068.90, 0.00, 0.00, 30.00, .interiorid = 32);
	CreateDynamicObject(2673, 901.10, 1814.90, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2673, 897.70, 1810.70, 5075.30, 0.00, 0.00, 2.75, .interiorid = 32);
	CreateDynamicObject(2673, 897.30, 1815.30, 5075.30, 0.00, 0.00, 3.75, .interiorid = 32);
	CreateDynamicObject(1666, 866.80, 1814.40, 5075.70, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1666, 867.17, 1812.86, 5075.66, 0.00, 278.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1666, 867.30, 1811.40, 5075.70, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1666, 864.40, 1815.20, 5075.70,   272.00, 360.00, 360.00, .interiorid = 32);
	CreateDynamicObject(928, 863.10, 1833.10, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(928, 862.30, 1833.40, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(928, 862.60, 1832.90, 5075.50, 0.00, 0.00, 34.00, .interiorid = 32);
	CreateDynamicObject(928, 863.90, 1834.90, 5075.50, 0.00, 0.00, 34.00, .interiorid = 32);
	CreateDynamicObject(928, 863.20, 1832.80, 5075.50, 0.00, 0.00, 34.00, .interiorid = 32);
	CreateDynamicObject(928, 892.10, 1812.90, 5075.50, 0.00, 0.00, 34.00, .interiorid = 32);
	CreateDynamicObject(928, 888.30, 1814.90, 5075.50, 0.00, 0.00, 34.00, .interiorid = 32);
	CreateDynamicObject(928, 892.10, 1814.10, 5075.50, 0.00, 0.00, 34.00, .interiorid = 32);
	CreateDynamicObject(928, 891.70, 1813.30, 5075.50, 0.00, 0.00, 98.00, .interiorid = 32);
	CreateDynamicObject(2671, 891.30, 1813.60, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2675, 889.30, 1813.60, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2675, 885.10, 1811.90, 5075.30, 0.00, 0.00, 22.00, .interiorid = 32);
	CreateDynamicObject(2675, 891.60, 1810.50, 5075.30, 0.00, 0.00, 21.99, .interiorid = 32);
	CreateDynamicObject(2971, 882.30, 1834.20, 5068.90, 0.00, 0.00, 18.00, .interiorid = 32);
	CreateDynamicObject(2968, 860.90, 1835.50, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2968, 861.60, 1835.40, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2968, 860.90, 1834.90, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2968, 861.60, 1834.80, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2968, 861.00, 1835.40, 5076.10, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2968, 861.40, 1834.90, 5076.10, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(851, 862.70, 1817.20, 5069.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2971, 870.80, 1823.30, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(850, 863.90, 1827.60, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1815, 861.07, 1813.96, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1815, 865.23, 1812.76, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1763, 902.52, 1815.18, 5075.14, 0.00, 0.00, -135.00, .interiorid = 32);
	CreateDynamicObject(1665, 865.86, 1813.64, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1668, 865.55, 1813.46, 5075.85, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1950, 865.78, 1813.34, 5075.86, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2670, 864.20, 1812.10, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2370, 868.50, 1817.70, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1668, 869.10, 1818.00, 5076.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1481, 871.80, 1818.10, 5075.90, 0.00, 0.00, 260.00, .interiorid = 32);
	CreateDynamicObject(2821, 868.60, 1818.20, 5076.05, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2839, 868.70, 1817.60, 5076.05, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2703, 871.60, 1818.00, 5076.10,   282.16, 260.68, 260.47, .interiorid = 32);
	CreateDynamicObject(2703, 871.70, 1818.20, 5076.10,   282.16, 260.67, 260.46, .interiorid = 32);
	CreateDynamicObject(2703, 871.60, 1817.80, 5076.10,   282.16, 260.67, 260.46, .interiorid = 32);
	CreateDynamicObject(2703, 871.70, 1818.40, 5076.10,   282.16, 260.67, 260.46, .interiorid = 32);
	CreateDynamicObject(2830, 869.20, 1818.60, 5076.10, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2968, 891.70, 1812.50, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2968, 891.50, 1813.90, 5075.50, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2968, 891.10, 1813.30, 5075.50, 0.00, 0.00, 334.00, .interiorid = 32);
	CreateDynamicObject(2968, 882.20, 1834.10, 5071.00, 0.00, 0.00, 334.00, .interiorid = 32);
	CreateDynamicObject(2968, 882.60, 1835.00, 5070.10, 0.00, 0.00, 334.00, .interiorid = 32);
	CreateDynamicObject(2968, 886.90, 1826.90, 5069.20, 0.00, 0.00, 334.00, .interiorid = 32);
	CreateDynamicObject(2968, 882.70, 1822.00, 5069.20, 0.00, 0.00, 334.00, .interiorid = 32);
	CreateDynamicObject(2654, 866.30, 1834.20, 5069.10, 0.00, 0.00, 324.00, .interiorid = 32);
	CreateDynamicObject(2669, 863.10, 1823.10, 5070.20, 0.00, 0.00, 150.00, .interiorid = 32);
	CreateDynamicObject(2370, 861.80, 1821.40, 5069.00, 0.00, 0.00, 330.00, .interiorid = 32);
	CreateDynamicObject(344, 862.80, 1821.70, 5070.10, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(346, 862.20, 1821.80, 5069.85,   77.22, 38.98, 299.72, .interiorid = 32);
	CreateDynamicObject(349, 862.07, 1822.17, 5069.85,   81.76, 256.05, 6.09, .interiorid = 32);
	CreateDynamicObject(355, 861.60, 1821.00, 5070.30, 0.00, 0.00, 342.00, .interiorid = 32);
	CreateDynamicObject(355, 861.60, 1821.00, 5070.70, 0.00, 0.00, 338.00, .interiorid = 32);
	CreateDynamicObject(346, 862.40, 1822.40, 5069.87,   77.22, 38.98, 299.71, .interiorid = 32);
	CreateDynamicObject(346, 861.93, 1821.80, 5069.85,   77.22, 38.98, 299.71, .interiorid = 32);
	CreateDynamicObject(346, 862.50, 1821.90, 5069.85,   77.22, 38.98, 299.71, .interiorid = 32);
	CreateDynamicObject(346, 862.42, 1821.47, 5069.85,   77.22, 38.98, 27.71, .interiorid = 32);
	CreateDynamicObject(349, 862.16, 1822.18, 5069.88,   90.00, 10.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2679, 863.80, 1825.80, 5070.06, 0.00, 0.00, 190.00, .interiorid = 32);
	CreateDynamicObject(2964, 871.00, 1819.00, 5068.90, 0.00, 0.00, 76.00, .interiorid = 32);
	CreateDynamicObject(2671, 870.50, 1821.20, 5068.90, 0.00, 0.00, 62.00, .interiorid = 32);
	CreateDynamicObject(2967, 861.98, 1814.45, 5075.70, 0.00, 0.00, 24.00, .interiorid = 32);
	CreateDynamicObject(3004, 871.00, 1818.90, 5069.80, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(338, 871.60, 1818.50, 5069.30, 0.00, 0.00, 232.00, .interiorid = 32);
	CreateDynamicObject(2965, 870.70, 1818.50, 5069.80, 0.00, 0.00, 16.00, .interiorid = 32);
	CreateDynamicObject(2332, 862.89, 1821.89, 5069.34, 0.00, 0.00, 150.00, .interiorid = 32);
	CreateDynamicObject(2332, 862.20, 1822.34, 5069.34, 0.00, 0.00, 150.00, .interiorid = 32);
	CreateDynamicObject(1550, 861.23, 1822.07, 5069.32, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1550, 861.54, 1822.62, 5069.32, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1550, 863.03, 1820.73, 5069.32, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1550, 863.42, 1821.49, 5069.32, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(5153, 892.84, 1812.43, 5076.28, 0.00, 114.00, 0.00, .interiorid = 32);
	CreateDynamicObject(335, 889.43, 1829.81, 5076.25, 0.00, 180.00, 175.00, .interiorid = 32);
	CreateDynamicObject(321, 889.22, 1834.39, 5075.28, 0.00, 105.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1815, 866.29, 1809.70, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 866.19, 1813.21, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 865.91, 1812.81, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 865.46, 1812.92, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 866.45, 1810.03, 5075.71, 0.00, 0.00, 236.00, .interiorid = 32);
	CreateDynamicObject(1665, 866.38, 1810.38, 5075.71, 0.00, 0.00, 236.00, .interiorid = 32);
	CreateDynamicObject(1665, 866.75, 1810.63, 5075.71, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(1668, 865.73, 1812.95, 5075.85, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1668, 866.59, 1810.26, 5075.85, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(372, 861.84, 1814.17, 5075.67,   90.00, 0.00, 175.00, .interiorid = 32);
	CreateDynamicObject(372, 865.66, 1813.13, 5075.68,   90.00, 0.00, 175.00, .interiorid = 32);
	CreateDynamicObject(1544, 866.93, 1810.06, 5075.70, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1544, 867.14, 1810.43, 5075.70, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1544, 866.86, 1810.50, 5075.70, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1544, 866.69, 1810.22, 5075.70, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1544, 866.41, 1811.19, 5075.19, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1544, 866.51, 1811.06, 5075.19, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1544, 866.37, 1811.04, 5075.19, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1544, 866.26, 1811.30, 5075.19, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1759, 866.03, 1814.85, 5075.10, 0.00, 0.00, -25.00, .interiorid = 32);
	CreateDynamicObject(1786, 861.29, 1809.35, 5075.68, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(349, 861.27, 1809.77, 5075.29,   90.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(352, 862.38, 1809.30, 5075.29,   90.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2823, 861.38, 1810.98, 5075.22, 0.00, 0.00, -156.00, .interiorid = 32);
	CreateDynamicObject(2823, 861.49, 1814.71, 5075.71, 0.00, 0.00, 25.00, .interiorid = 32);
	CreateDynamicObject(1665, 861.93, 1814.73, 5075.72, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 861.36, 1814.09, 5075.72, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 861.66, 1813.94, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1080, 863.23, 1830.08, 5068.83, 0.00, 0.00, -25.00, .interiorid = 32);
	CreateDynamicObject(355, 862.69, 1832.87, 5068.97,   90.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(355, 862.57, 1832.58, 5068.97,   90.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(355, 862.35, 1832.30, 5068.97,   90.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(355, 862.97, 1832.29, 5068.97,   90.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(349, 863.59, 1832.68, 5068.93,   90.00, 0.00, 149.00, .interiorid = 32);
	CreateDynamicObject(349, 863.18, 1831.78, 5068.93,   90.00, 0.00, 171.00, .interiorid = 32);
	CreateDynamicObject(349, 863.06, 1832.99, 5068.93,   90.00, 0.00, 171.00, .interiorid = 32);
	CreateDynamicObject(351, 863.12, 1832.65, 5068.91,   90.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(18651, 861.84, 1820.87, 5071.40, 0.00, 0.00, 58.50, .interiorid = 32);
	CreateDynamicObject(955, 861.00, 1817.50, 5069.17,   280.00, 0.00, 266.00, .interiorid = 32);
	CreateDynamicObject(1527, 860.46, 1821.59, 5073.10, 0.00, 0.00, 180.00, .interiorid = 32);
	CreateDynamicObject(1490, 864.21, 1821.98, 5070.32,   6.00, 0.00, 149.00, .interiorid = 32);
	CreateDynamicObject(3044, 865.35, 1812.76, 5075.75, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 865.79, 1812.63, 5075.75, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 866.08, 1813.06, 5075.75, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 865.93, 1813.89, 5075.75, 0.00, 0.00, -55.00, .interiorid = 32);
	CreateDynamicObject(3044, 866.32, 1810.17, 5075.75, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 866.61, 1810.39, 5075.75, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 866.38, 1809.81, 5075.75, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 865.39, 1810.41, 5075.75, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 861.58, 1813.88, 5075.74, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 861.25, 1813.94, 5075.74, 0.00, 0.00, 135.00, .interiorid = 32);
	CreateDynamicObject(3044, 862.13, 1814.88, 5075.74, 0.00, 0.00, -76.00, .interiorid = 32);
	CreateDynamicObject(2344, 863.01, 1814.75, 5075.64, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(17969, 887.08, 1835.68, 5071.99, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1490, 889.14, 1835.70, 5071.10, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(2691, 880.36, 1812.23, 5073.79, 0.00, 5.00, 270.00, .interiorid = 32);
	CreateDynamicObject(2696, 873.92, 1824.85, 5072.40, 0.00, 0.00, 295.00, .interiorid = 32);
	CreateDynamicObject(3029, 892.89, 1809.64, 5075.20, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(18651, 873.25, 1831.14, 5076.25, 0.00, 0.00, 73.00, .interiorid = 32);
	CreateDynamicObject(18651, 871.94, 1825.53, 5076.25, 0.00, 0.00, 24.00, .interiorid = 32);
	CreateDynamicObject(1735, 899.01, 1815.43, 5075.17, 0.00, 0.00, 105.00, .interiorid = 32);
	CreateDynamicObject(1665, 901.72, 1816.80, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(3044, 901.65, 1816.65, 5075.73, 0.00, 0.00, 142.00, .interiorid = 32);
	CreateDynamicObject(1665, 901.09, 1816.81, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 900.60, 1816.88, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 902.30, 1816.82, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 901.57, 1817.51, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1665, 900.70, 1817.50, 5075.71, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(3044, 900.99, 1816.63, 5075.73, 0.00, 0.00, 142.00, .interiorid = 32);
	CreateDynamicObject(3044, 900.52, 1816.69, 5075.73, 0.00, 0.00, 142.00, .interiorid = 32);
	CreateDynamicObject(3044, 902.21, 1816.66, 5075.73, 0.00, 0.00, 142.00, .interiorid = 32);
	CreateDynamicObject(3044, 901.47, 1817.33, 5075.73, 0.00, 0.00, 142.00, .interiorid = 32);
	CreateDynamicObject(3044, 900.63, 1817.35, 5075.73, 0.00, 0.00, 142.00, .interiorid = 32);
	CreateDynamicObject(3027, 901.25, 1816.83, 5075.70,   90.00, 0.00, -105.00, .interiorid = 32);
	CreateDynamicObject(349, 902.17, 1817.16, 5075.26,   89.00, 0.00, 170.00, .interiorid = 32);
	CreateDynamicObject(349, 902.09, 1816.97, 5075.26,   89.00, 0.00, 170.00, .interiorid = 32);
	CreateDynamicObject(2674, 900.00, 1817.68, 5075.23, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2675, 900.93, 1814.92, 5075.28, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2670, 899.99, 1816.06, 5075.28, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2670, 866.45, 1813.42, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2670, 863.62, 1814.29, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2670, 861.88, 1812.52, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2670, 863.08, 1810.44, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(2670, 864.75, 1810.93, 5075.30, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(14600, 881.28, 1808.84, 5070.25, 0.00, 0.00, 270.00, .interiorid = 32);
	CreateDynamicObject(1431, 886.79, 1809.46, 5069.36, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1431, 886.76, 1810.05, 5069.36, 0.00, 0.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1431, 887.57, 1811.58, 5069.36, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1431, 886.93, 1811.52, 5069.36, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1431, 887.21, 1809.71, 5070.44, 0.00, 0.00, 10.00, .interiorid = 32);
	CreateDynamicObject(1431, 887.27, 1811.31, 5070.44, 0.00, 0.00, 90.00, .interiorid = 32);
	CreateDynamicObject(1484, 895.11, 1816.10, 5076.46,   -10.00, 25.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1484, 894.97, 1816.59, 5076.46,   -10.00, 25.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1484, 895.15, 1817.38, 5076.46,   -10.00, 25.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1484, 895.12, 1814.80, 5076.46,   -10.00, 25.00, 0.00, .interiorid = 32);
	CreateDynamicObject(1484, 894.73, 1813.85, 5076.46,   -10.00, 25.00, 0.00, .interiorid = 32);
	
	// Idlewood bloods external doors
	CreateDynamicObject(1533, 1918.12, -1786.44, 12.53, 0.00, 0.00, 180.00);
	CreateDynamicObject(1533, 1919.60, -1786.44, 12.53, 0.00, 0.00, 180.00);

	// Customized Dojo (used by Triads & Yakuza)
	CreateDynamicObject(14789, 217.10, 1892.52, 6016.56, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(14534, 230.86, 1861.89, 6016.95, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2755, 237.52, 1866.25, 6013.50, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2755, 236.00, 1866.18, 6013.39, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(3117, 236.76, 1867.20, 6012.19, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2395, 236.03, 1865.42, 6014.52, 0.00, 90.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2395, 237.48, 1868.20, 6014.52, 0.00, 90.00, 270.00, .interiorid = 29);
	CreateDynamicObject(3117, 236.75, 1863.66, 6012.19, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2395, 237.50, 1867.08, 6014.52, 0.00, 90.00, 270.00, .interiorid = 29);
	CreateDynamicObject(2395, 236.03, 1864.31, 6014.52, 0.00, 90.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2395, 238.27, 1865.46, 6014.77,   90.00, 90.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2395, 238.27, 1864.47, 6014.77,   90.00, 90.00, 90.00, .interiorid = 29);
	CreateDynamicObject(14786, 230.58, 1885.73, 6016.29, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(14787, 229.64, 1888.39, 6012.41, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(14788, 217.22, 1892.44, 6014.36, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(14788, 217.22, 1878.43, 6014.42, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2755, 224.56, 1890.17, 6014.01, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2755, 230.88, 1890.25, 6014.01, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2755, 237.00, 1890.25, 6014.01, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(14790, 230.57, 1885.76, 6016.45, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1713, 224.46, 1864.48, 6012.25, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(1713, 227.20, 1867.39, 6012.25, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1713, 230.12, 1866.33, 6012.25, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(1708, 225.31, 1867.31, 6012.37, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2311, 226.43, 1865.27, 6012.28, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2762, 223.61, 1867.42, 6012.32, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2762, 230.54, 1867.63, 6012.32, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2253, 224.18, 1867.43, 6013.00, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 224.22, 1867.02, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 224.41, 1867.01, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 224.58, 1867.26, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 224.60, 1867.42, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2253, 229.98, 1867.68, 6013.00, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 229.61, 1867.74, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 229.62, 1867.47, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 229.86, 1867.21, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 230.13, 1867.25, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 230.32, 1867.20, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(3471, 236.24, 1859.62, 6013.52, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(3471, 234.33, 1859.64, 6013.52, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(18647, 234.24, 1860.63, 6012.34, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(18647, 236.18, 1860.64, 6012.34, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(1455, 226.41, 1865.60, 6012.85, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2251, 227.13, 1865.23, 6013.63, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2816, 227.84, 1865.28, 6012.78, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2852, 227.72, 1865.27, 6012.36, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2855, 227.18, 1865.10, 6012.35, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2854, 226.50, 1865.26, 6012.35, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 226.10, 1865.34, 6012.85, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 226.33, 1864.96, 6012.85, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 228.24, 1865.62, 6012.85, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 227.56, 1865.63, 6012.85, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1665, 226.04, 1865.64, 6012.80, 0.00, 0.00, -127.00, .interiorid = 29);
	CreateDynamicObject(1665, 226.05, 1865.06, 6012.80, 0.00, 0.00, -127.00, .interiorid = 29);
	CreateDynamicObject(1665, 226.65, 1865.64, 6012.80, 0.00, 0.00, 120.00, .interiorid = 29);
	CreateDynamicObject(1665, 227.15, 1865.66, 6012.81, 0.00, 0.00, 120.00, .interiorid = 29);
	CreateDynamicObject(1665, 227.95, 1865.66, 6012.81, 0.00, 0.00, 120.00, .interiorid = 29);
	CreateDynamicObject(1665, 228.31, 1865.00, 6012.81, 0.00, 0.00, 120.00, .interiorid = 29);
	CreateDynamicObject(3044, 225.94, 1864.86, 6012.83, 0.00, 0.00, 127.00, .interiorid = 29);
	CreateDynamicObject(3044, 225.92, 1865.39, 6012.83, 0.00, 0.00, 127.00, .interiorid = 29);
	CreateDynamicObject(3044, 226.45, 1865.82, 6012.83, 0.00, 0.00, 25.00, .interiorid = 29);
	CreateDynamicObject(3044, 226.96, 1865.82, 6012.83, 0.00, 0.00, 25.00, .interiorid = 29);
	CreateDynamicObject(3044, 227.76, 1865.82, 6012.83, 0.00, 0.00, 25.00, .interiorid = 29);
	CreateDynamicObject(3044, 228.13, 1865.16, 6012.83, 0.00, 0.00, 25.00, .interiorid = 29);
	CreateDynamicObject(19175, 226.99, 1868.02, 6014.72, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(19173, 229.26, 1860.80, 6015.66, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2266, 231.58, 1857.00, 6017.10, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(2271, 225.91, 1859.43, 6014.48, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(2240, 224.08, 1856.14, 6012.82, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2258, 225.60, 1858.43, 6019.47, 0.00, 0.00, 180.00, .interiorid = 29);
	CreateDynamicObject(2281, 225.14, 1867.55, 6019.55, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(19172, 226.42, 1866.08, 6019.97, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(2207, 234.58, 1865.90, 6017.48, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(1714, 236.20, 1865.02, 6017.50, 0.00, 0.00, -84.00, .interiorid = 29);
	CreateDynamicObject(2190, 235.01, 1866.11, 6018.26, 0.00, 0.00, 40.00, .interiorid = 29);
	CreateDynamicObject(2894, 234.72, 1864.72, 6018.26, 0.00, 0.00, 120.00, .interiorid = 29);
	CreateDynamicObject(18870, 235.37, 1866.04, 6018.26, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2253, 235.22, 1864.02, 6018.40, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1671, 234.02, 1866.62, 6017.94, 0.00, 0.00, 55.00, .interiorid = 29);
	CreateDynamicObject(1671, 233.44, 1865.58, 6017.94, 0.00, 0.00, 84.00, .interiorid = 29);
	CreateDynamicObject(1671, 233.46, 1864.36, 6017.94, 0.00, 0.00, 113.00, .interiorid = 29);
	CreateDynamicObject(1671, 233.99, 1863.40, 6017.94, 0.00, 0.00, 113.00, .interiorid = 29);
	CreateDynamicObject(9482, 242.70, 1858.14, 6019.50, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2755, 232.38, 1860.13, 6018.59, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2755, 238.07, 1860.18, 6018.59, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2755, 235.39, 1858.76, 6018.73, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2395, 235.06, 1858.78, 6019.67, 0.00, 90.00, 180.00, .interiorid = 29);
	CreateDynamicObject(2395, 237.63, 1858.80, 6019.67, 0.00, 90.00, 180.00, .interiorid = 29);
	CreateDynamicObject(2395, 239.23, 1858.78, 6019.67, 0.00, 90.00, 180.00, .interiorid = 29);
	CreateDynamicObject(2332, 235.39, 1858.55, 6018.81, 0.00, 0.00, 180.00, .interiorid = 29);
	CreateDynamicObject(19174, 235.33, 1868.06, 6020.18, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(339, 230.28, 1867.99, 6019.33, 0.00, 55.00, 0.00, .interiorid = 29);
	CreateDynamicObject(339, 230.98, 1868.01, 6019.34, 0.00, 55.00, 180.00, .interiorid = 29);
	CreateDynamicObject(1738, 229.95, 1861.90, 6018.17, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(339, 238.00, 1863.11, 6019.47, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(339, 238.02, 1863.45, 6019.47, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(339, 238.04, 1866.42, 6019.47, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(339, 238.04, 1866.74, 6019.47, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(2833, 226.67, 1865.45, 6020.43, 0.00, 90.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2834, 227.71, 1868.06, 6020.30, 0.00, 90.00, 270.00, .interiorid = 29);
	CreateDynamicObject(1703, 228.37, 1867.57, 6017.47, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1703, 227.22, 1864.61, 6017.47, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(1815, 228.72, 1865.23, 6017.52, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 228.80, 1865.62, 6018.09, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 228.88, 1865.44, 6018.09, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 229.52, 1866.06, 6018.09, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1455, 229.24, 1866.10, 6018.09, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(948, 231.77, 1862.10, 6017.52, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1568, 227.30, 1867.71, 6017.38, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1568, 232.83, 1867.36, 6017.38, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1568, 227.00, 1862.01, 6017.38, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2001, 237.60, 1867.55, 6017.54, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2252, 229.23, 1865.71, 6018.24, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(325, 229.24, 1865.69, 6018.01, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1568, 233.37, 1860.07, 6012.24, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(1568, 237.21, 1860.19, 6012.24, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(2271, 230.12, 1865.94, 6015.23, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(638, 225.11, 1867.56, 6018.13, 0.00, 0.00, 90.00, .interiorid = 29);
	CreateDynamicObject(948, 231.76, 1860.27, 6014.73, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(3117, 239.35, 1860.77, 6016.77, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(14775, 237.62, 1861.32, 6016.98, 0.00, 0.00, 270.00, .interiorid = 29);
	CreateDynamicObject(3117, 239.35, 1860.77, 6017.00, 0.00, 0.00, 0.00, .interiorid = 29);
	CreateDynamicObject(3117, 239.35, 1860.77, 6017.23, 0.00, 0.00, 0.00, .interiorid = 29);
	
	// 1Nation HQ
	CreateDynamicObject(14475, 2334.45, -1179.93, 51030.76, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(14474, 2337.05, -1179.83, 51028.76, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(7191, 2338.39, -1182.56, 51032.95,   90.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(7191, 2337.95, -1182.54, 51032.95,   90.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(7191, 2338.42, -1182.35, 51032.95,   90.00, 180.00, 90.25, .interiorid = 28);
	CreateDynamicObject(7191, 2337.97, -1182.33, 51032.95,   90.00, 179.99, 90.25, .interiorid = 28);
	CreateDynamicObject(7191, 2328.97, -1180.82, 51034.71, 0.00, 270.00, 88.50, .interiorid = 28);
	CreateDynamicObject(3055, 2319.78, -1184.83, 51032.36,   63.75, 270.00, 178.50, .interiorid = 28);
	CreateDynamicObject(7191, 2328.84, -1186.81, 51030.70, 0.00, 90.75, 359.99, .interiorid = 28);
	CreateDynamicObject(7191, 2326.85, -1187.03, 51030.70, 0.00, 90.75, 359.99, .interiorid = 28);
	CreateDynamicObject(7191, 2337.32, -1186.56, 51030.70, 0.00, 90.75, 359.99, .interiorid = 28);
	CreateDynamicObject(7191, 2339.07, -1186.13, 51030.70, 0.00, 91.25, 359.99, .interiorid = 28);
	CreateDynamicObject(7191, 2337.95, -1179.41, 51032.95,   90.00, 180.00, 270.00, .interiorid = 28);
	CreateDynamicObject(7191, 2338.38, -1179.43, 51032.95,   90.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(7191, 2337.97, -1179.24, 51032.95,   90.00, 179.99, 90.25, .interiorid = 28);
	CreateDynamicObject(1508, 2346.59, -1182.34, 51032.61, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(14384, 2324.38, -1174.92, 51028.48, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(2762, 2329.84, -1177.62, 51027.39, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(2762, 2329.82, -1175.43, 51027.39, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(1721, 2328.65, -1178.36, 51026.98, 0.00, 0.00, -55.00, .interiorid = 28);
	CreateDynamicObject(1721, 2328.64, -1177.19, 51026.96, 0.00, 0.00, -98.00, .interiorid = 28);
	CreateDynamicObject(2121, 2328.78, -1175.97, 51027.42, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(2121, 2328.82, -1174.86, 51027.42, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(2840, 2329.61, -1175.00, 51027.80, 0.00, 0.00, 62.00, .interiorid = 28);
	CreateDynamicObject(2857, 2329.85, -1175.71, 51027.80, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2823, 2329.52, -1177.03, 51027.81, 0.00, 0.00, -105.00, .interiorid = 28);
	CreateDynamicObject(2823, 2329.87, -1174.87, 51027.81, 0.00, 0.00, -105.00, .interiorid = 28);
	CreateDynamicObject(2823, 2330.02, -1176.76, 51027.81, 0.00, 0.00, -47.00, .interiorid = 28);
	CreateDynamicObject(2860, 2329.64, -1178.04, 51027.81, 0.00, 0.00, -120.00, .interiorid = 28);
	CreateDynamicObject(2840, 2329.86, -1177.43, 51027.80, 0.00, 0.00, 280.00, .interiorid = 28);
	CreateDynamicObject(1665, 2330.17, -1174.46, 51027.82, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2330.08, -1174.24, 51027.84, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(355, 2329.91, -1174.16, 51027.20, 0.00, 316.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2812, 2321.33, -1173.16, 51028.09, 0.00, 0.00, 55.00, .interiorid = 28);
	CreateDynamicObject(2829, 2323.05, -1171.92, 51028.10, 0.00, 0.00, 149.00, .interiorid = 28);
	CreateDynamicObject(2829, 2322.57, -1171.88, 51028.10, 0.00, 0.00, 149.00, .interiorid = 28);
	CreateDynamicObject(2814, 2322.11, -1178.13, 51028.10, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(2814, 2321.49, -1178.11, 51028.10, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(2814, 2321.59, -1178.13, 51028.18, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(2814, 2322.11, -1178.19, 51028.18, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(2814, 2321.54, -1178.17, 51028.24, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(2814, 2322.15, -1178.15, 51028.24, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(2814, 2321.90, -1178.13, 51028.35, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(2837, 2321.20, -1176.50, 51028.11, 0.00, 0.00, 84.00, .interiorid = 28);
	CreateDynamicObject(2837, 2321.17, -1177.22, 51028.11, 0.00, 0.00, 84.00, .interiorid = 28);
	CreateDynamicObject(1763, 2345.41, -1185.24, 51026.94, 0.00, 0.00, 47.00, .interiorid = 28);
	CreateDynamicObject(1368, 2349.40, -1185.01, 51027.41, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(1815, 2346.93, -1186.19, 51026.98, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2103, 2323.96, -1171.93, 51028.92, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1756, 2347.77, -1187.59, 51026.97, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(1839, 2349.40, -1187.89, 51027.85, 0.00, 0.00, 316.00, .interiorid = 28);
	CreateDynamicObject(2231, 2349.50, -1188.02, 51026.98, 0.00, 0.00, -135.00, .interiorid = 28);
	CreateDynamicObject(2231, 2349.16, -1188.37, 51026.98, 0.00, 0.00, -135.00, .interiorid = 28);
	CreateDynamicObject(352, 2347.74, -1185.74, 51027.47,   93.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(335, 2347.52, -1185.12, 51027.75, 0.00, 156.00, 229.00, .interiorid = 28);
	CreateDynamicObject(349, 2346.85, -1185.77, 51027.19,   55.00, 40.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1665, 2347.76, -1185.35, 51027.49, 0.00, 0.00, 76.00, .interiorid = 28);
	CreateDynamicObject(1665, 2347.64, -1186.13, 51027.49, 0.00, 0.00, -11.00, .interiorid = 28);
	CreateDynamicObject(1665, 2347.24, -1186.11, 51027.49, 0.00, 0.00, -40.00, .interiorid = 28);
	CreateDynamicObject(1665, 2347.00, -1185.84, 51027.49, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(1665, 2347.34, -1185.22, 51027.49, 0.00, 0.00, 171.00, .interiorid = 28);
	CreateDynamicObject(3044, 2347.66, -1185.09, 51027.52, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2347.30, -1185.04, 51027.52, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2346.83, -1185.89, 51027.52, 0.00, 0.00, 98.00, .interiorid = 28);
	CreateDynamicObject(3044, 2347.06, -1186.17, 51027.52, 0.00, 0.00, 98.00, .interiorid = 28);
	CreateDynamicObject(3044, 2347.88, -1186.12, 51027.52, 0.00, 0.00, -120.00, .interiorid = 28);
	CreateDynamicObject(3027, 2347.39, -1186.18, 51027.49,   90.00, 0.00, 229.00, .interiorid = 28);
	CreateDynamicObject(3027, 2347.13, -1185.96, 51027.49,   90.00, 0.00, 229.00, .interiorid = 28);
	CreateDynamicObject(3027, 2347.78, -1186.20, 51027.49,   90.00, 0.00, 229.00, .interiorid = 28);
	CreateDynamicObject(3027, 2347.45, -1185.40, 51027.49,   90.00, 0.00, 229.00, .interiorid = 28);
	CreateDynamicObject(3027, 2347.82, -1185.47, 51027.49,   90.00, 0.00, 229.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.09, -1185.40, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.10, -1185.56, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.00, -1185.66, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.17, -1185.92, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.31, -1185.89, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.18, -1185.41, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1951, 2346.78, -1184.24, 51027.14, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1668, 2347.40, -1185.66, 51027.63, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1668, 2347.59, -1185.60, 51027.63, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1520, 2347.20, -1185.81, 51027.47, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1512, 2347.80, -1185.98, 51027.66, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1520, 2347.57, -1185.92, 51027.47, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.56, -1185.75, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.49, -1186.05, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2347.88, -1185.58, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2348.00, -1185.76, 51027.07, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2674, 2348.59, -1184.77, 51026.99, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2346.53, -1184.16, 51027.07, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2673, 2348.16, -1184.24, 51027.06, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2673, 2348.80, -1186.50, 51027.06, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2673, 2348.01, -1187.38, 51027.06, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(2675, 2345.88, -1184.10, 51027.05, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2675, 2345.05, -1187.21, 51027.05, 0.00, 0.00, 113.00, .interiorid = 28);
	CreateDynamicObject(2677, 2345.22, -1185.25, 51027.25, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2677, 2348.77, -1186.25, 51027.25, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2345.32, -1186.11, 51027.07, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2347.77, -1183.64, 51027.07, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2823, 2345.32, -1187.54, 51026.98, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2823, 2348.85, -1184.30, 51026.98, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2814, 2346.63, -1186.20, 51026.99, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(17969, 2340.19, -1179.55, 51028.66, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(1526, 2342.32, -1179.53, 51028.04, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(14840, 2350.17, -1172.88, 51028.75, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(4227, 2338.07, -1182.31, 51032.31, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(1526, 2338.23, -1179.54, 51033.46,   10.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(2204, 2343.44, -1188.57, 51026.97, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(1668, 2342.54, -1188.18, 51027.89, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1668, 2342.27, -1188.19, 51027.89, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1668, 2341.92, -1188.15, 51027.89, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(346, 2341.31, -1188.28, 51028.02,   93.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(355, 2341.17, -1188.33, 51028.80,   90.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(14746, 2358.96, -1177.03, 51028.76, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(1495, 2354.02, -1180.10, 51027.05, 0.00, 4.00, 34.50, .interiorid = 28);
	CreateDynamicObject(3576, 2354.98, -1174.36, 51028.48, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3577, 2355.44, -1177.50, 51027.72, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3800, 2355.30, -1176.89, 51028.45, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1224, 2355.21, -1178.36, 51029.00, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3788, 2359.59, -1173.14, 51027.47, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3793, 2359.55, -1172.66, 51027.98, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(355, 2359.52, -1172.83, 51027.36,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(355, 2359.75, -1173.09, 51027.36,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(355, 2359.74, -1173.39, 51027.36,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(355, 2360.28, -1173.32, 51027.36,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(355, 2360.22, -1172.98, 51027.36,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(349, 2360.79, -1172.73, 51027.34,   93.00, 0.00, 193.00, .interiorid = 28);
	CreateDynamicObject(349, 2360.87, -1173.53, 51027.34,   93.00, 0.00, 193.00, .interiorid = 28);
	CreateDynamicObject(349, 2359.27, -1172.71, 51027.36,   93.00, 0.00, 193.00, .interiorid = 28);
	CreateDynamicObject(349, 2359.41, -1173.56, 51027.34,   93.00, 0.00, 193.00, .interiorid = 28);
	CreateDynamicObject(352, 2361.04, -1173.10, 51027.32,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(346, 2358.43, -1172.87, 51027.32,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(346, 2358.74, -1172.96, 51027.32,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(346, 2358.60, -1173.07, 51027.32,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(346, 2358.34, -1173.10, 51027.32,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(346, 2358.83, -1173.18, 51027.32,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(348, 2358.45, -1173.40, 51027.32,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(348, 2358.79, -1173.38, 51027.32,   93.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(2358, 2362.10, -1172.78, 51027.08, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2358, 2362.83, -1172.79, 51027.08, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2358, 2363.61, -1172.79, 51027.08, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2358, 2363.51, -1172.79, 51027.30, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2358, 2362.84, -1172.75, 51027.30, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2358, 2362.16, -1172.71, 51027.30, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3109, 2331.35, -1171.29, 51032.19, 0.00, 0.00, 270.00, .interiorid = 28);
	CreateDynamicObject(1431, 2349.08, -1178.64, 51027.52, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1431, 2349.01, -1177.94, 51027.52, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1431, 2349.79, -1176.44, 51027.52, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(1431, 2349.01, -1176.34, 51027.52, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(349, 2343.05, -1178.93, 51027.21,   11.00, 280.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1431, 2349.19, -1177.08, 51028.60, 0.00, 0.00, 47.00, .interiorid = 28);
	CreateDynamicObject(1526, 2342.84, -1173.56, 51028.96,   11.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(2762, 2337.52, -1172.57, 51027.38, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(2762, 2337.46, -1174.94, 51027.38, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(2867, 2337.49, -1175.48, 51027.78, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2866, 2337.45, -1171.88, 51027.80, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2823, 2337.26, -1175.13, 51027.77, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2840, 2337.38, -1172.60, 51027.80, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2857, 2337.40, -1174.25, 51027.79, 0.00, 0.00, 4.00, .interiorid = 28);
	CreateDynamicObject(2837, 2337.56, -1173.03, 51027.81, 0.00, 0.00, -55.00, .interiorid = 28);
	CreateDynamicObject(349, 2337.13, -1173.25, 51027.79,   87.00, 0.00, 105.00, .interiorid = 28);
	CreateDynamicObject(14840, 2330.84, -1187.29, 51028.89, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(14840, 2339.36, -1187.14, 51032.78, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(1526, 2337.90, -1182.69, 51029.16,   5.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(1757, 2321.40, -1180.73, 51026.98, 0.00, 0.00, 33.00, .interiorid = 28);
	CreateDynamicObject(1756, 2321.45, -1184.25, 51027.02, 0.00, 0.00, 91.00, .interiorid = 28);
	CreateDynamicObject(1759, 2329.83, -1182.55, 51026.88, 0.00, 0.00, -84.00, .interiorid = 28);
	CreateDynamicObject(1710, 2328.15, -1188.04, 51026.93, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(1735, 2329.83, -1186.21, 51026.98, 0.00, 0.00, 244.00, .interiorid = 28);
	CreateDynamicObject(1815, 2329.02, -1188.29, 51026.98, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2234, 2323.33, -1183.70, 51026.87, 0.00, 0.00, 93.00, .interiorid = 28);
	CreateDynamicObject(1764, 2327.65, -1179.63, 51026.84, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2322.84, -1183.72, 51027.38, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2322.88, -1183.61, 51027.38, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2322.96, -1183.47, 51027.38, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2322.48, -1182.71, 51027.38, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2322.77, -1182.68, 51027.38, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2322.70, -1183.84, 51027.38, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2321.41, -1184.85, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2321.63, -1181.28, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2323.47, -1180.30, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2327.25, -1179.38, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2327.35, -1179.51, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2327.43, -1179.76, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2330.02, -1179.75, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2330.25, -1179.71, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2330.19, -1179.50, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.94, -1182.17, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.85, -1182.28, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.71, -1182.20, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2330.12, -1185.85, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2323.86, -1187.98, 51026.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.85, -1187.92, 51027.46, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2328.64, -1186.41, 51027.07, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2328.42, -1182.82, 51027.06, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2327.04, -1180.45, 51027.06, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2322.38, -1181.13, 51027.05, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2321.55, -1185.06, 51027.06, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2674, 2324.31, -1180.12, 51026.99, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2674, 2329.49, -1180.74, 51026.99, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2673, 2321.04, -1182.93, 51027.60, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2673, 2323.90, -1180.13, 51027.08, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2675, 2327.19, -1186.62, 51027.05, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2675, 2322.68, -1184.71, 51027.05, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2677, 2324.44, -1186.91, 51027.25, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2324.86, -1184.69, 51027.06, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2324.88, -1183.22, 51027.06, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2670, 2328.21, -1184.32, 51027.06, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2674, 2326.11, -1185.13, 51026.99, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.68, -1188.02, 51027.46, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.04, -1187.72, 51027.46, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2328.88, -1187.62, 51026.95, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.22, -1187.59, 51027.46, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.73, -1187.51, 51027.46, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1544, 2329.54, -1188.27, 51027.44, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1665, 2322.60, -1183.72, 51027.39, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1665, 2322.55, -1182.94, 51027.39, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1665, 2322.56, -1183.35, 51027.39, 0.00, 0.00, -149.00, .interiorid = 28);
	CreateDynamicObject(1665, 2322.98, -1182.66, 51027.39, 0.00, 0.00, 142.00, .interiorid = 28);
	CreateDynamicObject(1665, 2329.36, -1187.49, 51027.48, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1665, 2329.23, -1188.14, 51027.48, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1665, 2329.65, -1187.39, 51027.48, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(346, 2329.47, -1187.77, 51027.47,   93.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2329.56, -1187.12, 51027.52, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2329.28, -1187.21, 51027.52, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2329.14, -1187.87, 51027.52, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2322.51, -1182.86, 51027.38, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(17969, 2323.41, -1177.63, 51032.45, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(1793, 2350.25, -1184.33, 51030.94, 0.00, 0.00, 98.00, .interiorid = 28);
	CreateDynamicObject(1812, 2347.18, -1187.84, 51030.98, 0.00, 0.00, 273.00, .interiorid = 28);
	CreateDynamicObject(1796, 2344.16, -1188.06, 51030.80, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(1812, 2341.75, -1183.31, 51030.98, 0.00, 0.00, 273.00, .interiorid = 28);
	CreateDynamicObject(1526, 2350.19, -1185.82, 51032.93, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1763, 2331.89, -1183.42, 51030.89, 0.00, 0.00, 11.00, .interiorid = 28);
	CreateDynamicObject(2819, 2345.56, -1184.76, 51030.96, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1764, 2331.86, -1186.97, 51030.92, 0.00, 0.00, 91.00, .interiorid = 28);
	CreateDynamicObject(2121, 2337.18, -1186.15, 51031.40, 0.00, 0.00, -91.00, .interiorid = 28);
	CreateDynamicObject(2121, 2335.84, -1186.74, 51031.40, 0.00, 0.00, 178.00, .interiorid = 28);
	CreateDynamicObject(2121, 2335.31, -1185.67, 51031.40, 0.00, 0.00, 76.00, .interiorid = 28);
	CreateDynamicObject(2121, 2336.34, -1184.99, 51031.40, 0.00, 0.00, -4.00, .interiorid = 28);
	CreateDynamicObject(2726, 2336.28, -1185.96, 51031.32, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2336.24, -1185.83, 51031.51, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2336.21, -1185.82, 51031.51, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2336.21, -1185.82, 51031.53, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2336.23, -1185.81, 51031.53, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3044, 2336.21, -1185.93, 51031.41,   270.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2332, 2360.65, -1181.61, 51027.43, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(1829, 2359.80, -1181.30, 51027.42, 0.00, 0.00, 180.00, .interiorid = 28);
	CreateDynamicObject(1575, 2360.49, -1181.74, 51027.87, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1575, 2359.89, -1181.75, 51027.89, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(9345, 2360.64, -1192.56, 51026.98, 0.00, 0.00, 270.00, .interiorid = 28);
	CreateDynamicObject(3409, 2360.54, -1190.30, 51026.68, 0.00, 0.00, 90.00, .interiorid = 28);
	CreateDynamicObject(3117, 2353.84, -1180.94, 51031.25, 0.00, 90.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3117, 2353.89, -1180.88, 51031.25, 0.00, 90.00, 0.00, .interiorid = 28);
	CreateDynamicObject(14443, 2336.06, -1179.94, 51030.97, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(1800, 2350.98, -1178.41, 51030.88, 0.00, 0.00, 94.00, .interiorid = 28);
	CreateDynamicObject(1799, 2348.47, -1174.86, 51030.98, 0.00, 0.00, 1.00, .interiorid = 28);
	CreateDynamicObject(1793, 2344.49, -1175.12, 51030.98, 0.00, 0.00, 11.00, .interiorid = 28);
	CreateDynamicObject(1800, 2349.30, -1178.01, 51030.88, 0.00, 0.00, 4.00, .interiorid = 28);
	CreateDynamicObject(3029, 2353.42, -1181.85, 51026.98, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3260, 2364.08, -1188.20, 51028.82, 0.00, 0.00, 270.00, .interiorid = 28);
	CreateDynamicObject(3260, 2364.16, -1192.27, 51028.82, 0.00, 0.00, 270.00, .interiorid = 28);
	CreateDynamicObject(3260, 2364.10, -1184.12, 51028.82, 0.00, 0.00, 270.00, .interiorid = 28);
	CreateDynamicObject(13607, 2360.68, -1170.96, 51026.97,   90.00, 0.00, 270.00, .interiorid = 28);
	CreateDynamicObject(2525, 2334.51, -1171.77, 51030.98, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(2739, 2337.51, -1175.08, 51030.99, 0.00, 0.00, 270.00, .interiorid = 28);
	CreateDynamicObject(2517, 2337.42, -1179.51, 51030.98, 0.00, 0.00, 0.00, .interiorid = 28);
	CreateDynamicObject(3029, 2335.99, -1182.25, 51030.98, 0.00, 0.00, 90.00, .interiorid = 28);
	
	// Ryuko Yakuza HQ
	CreateDynamicObject(14777, 2421.93, -1964.97, 813.63, 0.00, 0.00, 179.99, .interiorid = 27);
	CreateDynamicObject(3441, 2419.73, -1979.54, 815.61, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3441, 2424.14, -1979.50, 815.61, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1978, 2421.40, -1964.58, 814.69, 0.00, 0.00, 0.25, .interiorid = 27);
	CreateDynamicObject(1978, 2416.41, -1965.11, 814.69, 0.00, 0.00, 180.25, .interiorid = 27);
	CreateDynamicObject(2785, 2406.45, -1955.73, 815.89, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(1979, 2421.21, -1963.23, 814.66, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1979, 2416.61, -1966.45, 814.66, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2405.99, -1962.66, 815.39, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2755, 2405.96, -1967.33, 815.39, 0.00, 0.00, 90.25, .interiorid = 27);
	CreateDynamicObject(2188, 2407.22, -1964.98, 814.64, 0.00, 0.00, 89.50, .interiorid = 27);
	CreateDynamicObject(1665, 2415.47, -1972.42, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2414.88, -1971.53, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2412.39, -1971.60, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2411.88, -1972.26, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2409.64, -1972.07, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2408.52, -1971.67, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2403.71, -1973.06, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2403.54, -1975.23, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2404.45, -1975.48, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2407.52, -1975.14, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2408.33, -1975.52, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2411.55, -1975.20, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2412.40, -1975.73, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2412.40, -1975.73, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2423.32, -1953.30, 815.86,   32.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2415.28, -1972.32, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2414.69, -1971.41, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2412.19, -1971.52, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2411.67, -1972.17, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2409.43, -1971.97, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2408.31, -1971.58, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2403.48, -1972.98, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2403.33, -1975.14, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2404.23, -1975.38, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2407.29, -1975.04, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2408.11, -1975.44, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2412.18, -1975.61, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2411.34, -1975.09, 815.85,   26.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2414.82, -1971.86, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2415.43, -1971.81, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2415.14, -1972.19, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2414.78, -1972.41, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2415.25, -1972.47, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2415.60, -1971.43, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2415.74, -1971.96, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2412.69, -1972.26, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2412.27, -1971.82, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2411.81, -1971.73, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2412.26, -1972.37, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2412.72, -1971.61, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2409.40, -1971.67, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2403.70, -1973.55, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.72, -1971.93, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2409.20, -1972.27, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.99, -1971.31, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2409.40, -1971.37, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.93, -1972.22, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2404.39, -1972.67, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2404.48, -1972.95, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2404.48, -1972.95, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2404.39, -1973.45, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2403.57, -1972.61, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2404.10, -1973.32, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2403.76, -1974.93, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2403.75, -1975.76, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2404.30, -1976.09, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2404.23, -1975.54, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2404.43, -1975.01, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2407.73, -1975.89, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.00, -1974.95, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2407.99, -1975.38, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.47, -1975.81, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.08, -1975.92, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.51, -1975.05, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2407.59, -1975.60, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.65, -1975.46, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2412.36, -1974.94, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2412.41, -1975.32, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2411.68, -1975.57, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2411.95, -1976.06, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2411.77, -1974.77, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2411.84, -1975.29, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2412.49, -1975.96, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2407.70, -1952.09, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2408.18, -1951.77, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2411.83, -1951.78, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2412.01, -1952.12, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2415.83, -1951.86, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2416.06, -1952.08, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2419.29, -1953.36, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2419.73, -1953.39, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2423.78, -1953.68, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2423.27, -1953.60, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2423.27, -1953.60, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2423.53, -1953.36, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2419.54, -1953.76, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2415.79, -1952.13, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2412.06, -1951.81, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2407.87, -1951.87, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2407.87, -1951.87, 815.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2419.32, -1953.67, 815.86,   32.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2415.56, -1952.05, 815.86,   32.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2411.81, -1951.74, 815.86,   32.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2407.67, -1951.83, 815.86,   32.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2785, 2423.40, -1958.34, 815.89, 0.00, 0.00, 180.25, .interiorid = 27);
	CreateDynamicObject(2785, 2419.15, -1958.35, 815.89, 0.00, 0.00, 180.25, .interiorid = 27);
	CreateDynamicObject(2785, 2414.89, -1958.36, 815.89, 0.00, 0.00, 180.25, .interiorid = 27);
	CreateDynamicObject(1716, 2413.47, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2414.34, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2415.21, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2416.06, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2416.91, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2417.75, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2418.62, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2419.44, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2420.34, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2421.16, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2422.00, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2422.85, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2423.70, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2424.57, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2425.42, -1957.22, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2964, 2409.64, -1955.82, 815.04, 0.00, 0.00, 89.50, .interiorid = 27);
	CreateDynamicObject(2964, 2412.27, -1955.83, 815.04, 0.00, 0.00, 89.49, .interiorid = 27);
	CreateDynamicObject(2964, 2415.96, -1954.76, 815.04, 0.00, 0.00, 89.50, .interiorid = 27);
	CreateDynamicObject(3106, 2409.36, -1955.84, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3105, 2409.75, -1956.35, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3103, 2409.79, -1955.18, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3001, 2409.43, -1956.49, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2997, 2409.84, -1955.59, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2996, 2409.34, -1955.21, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2995, 2412.02, -1956.32, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3106, 2412.66, -1956.59, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3104, 2411.95, -1955.04, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3102, 2416.07, -1954.34, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3100, 2415.68, -1955.27, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3106, 2416.29, -1955.33, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3104, 2415.71, -1954.40, 815.97, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3441, 2424.06, -1975.27, 815.61, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3441, 2419.93, -1975.20, 815.61, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2416.69, -1971.56, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2415.80, -1972.70, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2414.42, -1971.76, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2413.66, -1971.21, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2412.38, -1972.73, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2411.37, -1971.33, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2410.52, -1971.54, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2409.46, -1972.65, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2408.18, -1971.59, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2405.70, -1972.80, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1713, 2429.44, -1951.47, 813.63, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1713, 2431.99, -1952.54, 813.63, 0.00, 0.00, 269.75, .interiorid = 27);
	CreateDynamicObject(1713, 2428.52, -1954.26, 813.63, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2315, 2430.32, -1954.30, 813.63, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(1486, 2429.89, -1954.46, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2430.32, -1954.22, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2430.33, -1953.42, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2430.55, -1953.87, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2429.97, -1953.86, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2429.98, -1953.28, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2430.49, -1952.92, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2430.12, -1952.81, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2430.56, -1954.52, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2430.22, -1954.52, 814.28, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2430.53, -1953.29, 814.19, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2430.44, -1952.63, 814.19, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2430.35, -1953.75, 814.19, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2430.63, -1954.20, 814.19, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2430.24, -1952.53, 814.17,   28.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2430.33, -1953.19, 814.17,   28.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2430.16, -1953.67, 814.17,   28.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2430.41, -1954.09, 814.17,   28.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2417.96, -1977.33, 815.39, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2755, 2425.93, -1977.46, 815.39, 0.00, 0.00, 89.99, .interiorid = 27);
	CreateDynamicObject(2637, 2425.73, -1972.04, 813.74, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1713, 2424.99, -1970.30, 813.63, 0.00, 0.00, 0.50, .interiorid = 27);
	CreateDynamicObject(1713, 2426.61, -1973.69, 813.63, 0.00, 0.00, 180.50, .interiorid = 27);
	CreateDynamicObject(1665, 2425.78, -1972.09, 814.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2425.04, -1972.37, 814.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2425.91, -1971.64, 814.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2425.17, -1971.65, 814.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2426.33, -1972.46, 814.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2424.83, -1972.27, 814.20,   40.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2424.95, -1971.59, 814.20,   40.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2425.54, -1972.00, 814.20,   40.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2425.69, -1971.56, 814.20,   40.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2426.11, -1972.33, 814.20,   40.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2425.33, -1972.33, 814.29, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2425.79, -1972.31, 814.29, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2426.36, -1972.05, 814.29, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2426.37, -1971.64, 814.29, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2425.59, -1971.75, 814.29, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2425.28, -1972.04, 814.29, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2407.60, -1957.13, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2407.59, -1956.30, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2407.61, -1955.45, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2407.60, -1954.60, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1716, 2407.60, -1953.78, 815.04, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(14789, 2445.33, -1972.01, 818.25, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(14787, 2449.49, -1959.21, 814.11, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2755, 2449.30, -1965.89, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2452.55, -1965.87, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2455.72, -1965.89, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2458.89, -1965.87, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2462.11, -1965.87, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2462.12, -1950.47, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2458.85, -1950.48, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2455.58, -1950.49, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2452.37, -1950.52, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2449.33, -1950.54, 815.75, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2448.00, -1964.35, 815.75, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2755, 2447.99, -1961.34, 815.75, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2755, 2448.05, -1952.22, 815.75, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2755, 2448.06, -1955.25, 815.75, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2755, 2463.41, -1952.10, 815.75, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2755, 2463.42, -1955.10, 815.75, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2755, 2463.42, -1964.31, 815.75, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2755, 2463.40, -1961.28, 815.75, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2627, 2437.00, -1951.45, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2627, 2438.51, -1951.46, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2627, 2440.08, -1951.46, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2627, 2446.79, -1951.54, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2627, 2445.15, -1951.51, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2627, 2443.32, -1951.49, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2628, 2441.79, -1951.95, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2628, 2437.44, -1954.95, 814.02, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2628, 2437.48, -1956.93, 814.02, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2628, 2437.49, -1958.96, 814.02, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2628, 2437.46, -1961.08, 814.02, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2628, 2437.46, -1963.41, 814.02, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2628, 2446.34, -1954.77, 814.02, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2628, 2446.34, -1956.84, 814.02, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2628, 2446.36, -1958.79, 814.02, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2628, 2446.38, -1960.97, 814.02, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2628, 2446.40, -1963.30, 814.02, 0.00, 0.00, 270.25, .interiorid = 27);
	CreateDynamicObject(2630, 2439.29, -1964.62, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2630, 2440.34, -1964.62, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2630, 2441.49, -1964.63, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2630, 2442.61, -1964.61, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2630, 2443.71, -1964.61, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2630, 2444.86, -1964.59, 814.02, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(14782, 2443.97, -1972.92, 815.03, 0.00, 0.00, 180.25, .interiorid = 27);
	CreateDynamicObject(14782, 2457.97, -1972.94, 815.03, 0.00, 0.00, 180.24, .interiorid = 27);
	CreateDynamicObject(14534, 2476.00, -1958.19, 818.61, 0.00, 0.00, 91.25, .interiorid = 27);
	CreateDynamicObject(1713, 2477.92, -1952.90, 814.00, 0.00, 0.00, 271.00, .interiorid = 27);
	CreateDynamicObject(2179, 2478.34, -1951.84, 814.00, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2179, 2478.37, -1955.50, 814.00, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2311, 2472.29, -1961.34, 813.99, 0.00, 0.00, 271.25, .interiorid = 27);
	CreateDynamicObject(1713, 2471.43, -1959.20, 813.99, 0.00, 0.00, 0.75, .interiorid = 27);
	CreateDynamicObject(1713, 2470.62, -1962.98, 813.99, 0.00, 0.00, 91.00, .interiorid = 27);
	CreateDynamicObject(1713, 2473.23, -1964.72, 813.99, 0.00, 0.00, 180.99, .interiorid = 27);
	CreateDynamicObject(1486, 2472.49, -1963.10, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.75, -1962.72, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.46, -1962.17, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.66, -1961.35, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.69, -1961.88, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.15, -1960.96, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.64, -1960.96, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.04, -1961.63, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.02, -1962.77, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.19, -1963.23, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2471.93, -1962.18, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.36, -1962.72, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.36, -1961.66, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2471.90, -1961.12, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1486, 2472.72, -1963.11, 814.64, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2472.26, -1962.97, 814.52, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2472.56, -1962.48, 814.52, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2472.20, -1962.46, 814.52, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2472.15, -1961.97, 814.52, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2472.31, -1961.29, 814.52, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2472.65, -1962.15, 814.52, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2472.05, -1961.39, 814.52, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1665, 2472.62, -1961.63, 814.52, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2472.40, -1961.53, 814.54,   58.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2472.11, -1961.20, 814.54,   58.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2471.88, -1961.30, 814.54,   58.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2471.96, -1961.88, 814.54,   58.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2472.01, -1962.36, 814.54,   58.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2472.38, -1962.38, 814.54,   58.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1485, 2472.08, -1962.86, 814.54,   58.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2179, 2470.32, -1959.02, 814.00, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2179, 2470.67, -1964.89, 814.00, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2179, 2481.60, -1957.34, 818.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2179, 2477.56, -1957.42, 818.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2755, 2473.57, -1954.51, 815.65, 0.00, 0.00, 91.25, .interiorid = 27);
	CreateDynamicObject(2755, 2473.64, -1957.11, 815.65, 0.00, 0.00, 91.25, .interiorid = 27);
	CreateDynamicObject(2755, 2475.23, -1951.04, 815.65, 0.00, 0.00, 0.75, .interiorid = 27);
	CreateDynamicObject(2184, 2471.80, -1953.85, 819.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1714, 2472.86, -1952.03, 819.21, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1708, 2474.54, -1955.08, 819.21, 0.00, 0.00, 200.00, .interiorid = 27);
	CreateDynamicObject(1708, 2472.13, -1955.45, 819.21, 0.00, 0.00, 162.50, .interiorid = 27);
	CreateDynamicObject(2755, 2469.78, -1952.74, 820.95, 0.00, 0.00, 271.00, .interiorid = 27);
	CreateDynamicObject(2755, 2469.82, -1955.45, 820.95, 0.00, 0.00, 271.00, .interiorid = 27);
	CreateDynamicObject(1742, 2476.58, -1955.73, 819.20, 0.00, 0.00, 271.50, .interiorid = 27);
	CreateDynamicObject(1742, 2476.55, -1954.30, 819.20, 0.00, 0.00, 271.50, .interiorid = 27);
	CreateDynamicObject(1742, 2476.51, -1952.88, 819.20, 0.00, 0.00, 271.50, .interiorid = 27);
	CreateDynamicObject(1742, 2476.46, -1951.43, 819.20, 0.00, 0.00, 271.50, .interiorid = 27);
	CreateDynamicObject(1742, 2476.46, -1951.43, 821.23, 0.00, 0.00, 271.50, .interiorid = 27);
	CreateDynamicObject(1742, 2476.51, -1952.85, 821.23, 0.00, 0.00, 271.50, .interiorid = 27);
	CreateDynamicObject(1742, 2476.54, -1954.30, 821.23, 0.00, 0.00, 271.50, .interiorid = 27);
	CreateDynamicObject(1742, 2476.58, -1955.73, 821.23, 0.00, 0.00, 271.50, .interiorid = 27);
	CreateDynamicObject(2290, 2470.38, -1960.67, 819.21, 0.00, 0.00, 91.25, .interiorid = 27);
	CreateDynamicObject(2290, 2473.42, -1961.86, 819.21, 0.00, 0.00, 180.50, .interiorid = 27);
	CreateDynamicObject(2179, 2470.41, -1961.90, 820.85, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2332, 2470.29, -1963.18, 819.71, 0.00, 0.00, 91.25, .interiorid = 27);
	CreateDynamicObject(2332, 2470.28, -1964.95, 819.71, 0.00, 0.00, 91.74, .interiorid = 27);
	CreateDynamicObject(1829, 2470.64, -1964.07, 819.71, 0.00, 0.00, 91.50, .interiorid = 27);
	CreateDynamicObject(2093, 2475.58, -1958.81, 819.21, 0.00, 0.00, 226.25, .interiorid = 27);
	CreateDynamicObject(2311, 2471.84, -1959.71, 819.21, 0.00, 0.00, 1.25, .interiorid = 27);
	CreateDynamicObject(3117, 2471.50, -1952.39, 813.87, 0.00, 0.72, 0.00, .interiorid = 27);
	CreateDynamicObject(3117, 2472.02, -1952.39, 813.86, 0.00, 0.72, 0.00, .interiorid = 27);
	CreateDynamicObject(3117, 2471.52, -1952.39, 816.59, 0.00, 0.72, 0.00, .interiorid = 27);
	CreateDynamicObject(9339, 2472.62, -1951.49, 806.04,   90.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(9339, 2471.25, -1951.44, 806.10,   90.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(9339, 2470.36, -1951.46, 806.09,   90.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(9339, 2470.39, -1953.26, 806.13,   90.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(9339, 2471.75, -1953.25, 806.14,   90.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(9339, 2472.70, -1953.25, 806.11,   90.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(339, 2474.45, -1951.07, 821.07, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(339, 2471.11, -1951.13, 821.07, 0.00, 0.00, 180.00, .interiorid = 27);
	CreateDynamicObject(339, 2469.96, -1962.54, 816.00, 0.00, 50.00, 90.00, .interiorid = 27);
	CreateDynamicObject(339, 2469.98, -1961.82, 816.00, 0.00, 50.00, 270.00, .interiorid = 27);
	
	// Vatos Interior #1
	CreateDynamicObject(18056,2572.19995117,-2143.39990234,24884.80078125,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(mp_dinerbig) (1)
	CreateDynamicObject(2808,2558.80004883,-2149.75000000,24883.59960938,0.00000000,0.00000000,270.00000000, .interiorid = 27); //object(cj_pizza_chair4) (1)
	CreateDynamicObject(2747,2560.00000000,-2149.60009766,24883.37109375,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (1)
	CreateDynamicObject(2746,2561.69995117,-2149.56005859,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (1)
	CreateDynamicObject(2747,2563.35009766,-2149.59960938,24883.36914062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (2)
	CreateDynamicObject(2746,2565.00927734,-2149.55957031,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (2)
	CreateDynamicObject(2746,2568.25878906,-2149.55957031,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (3)
	CreateDynamicObject(2747,2566.64965820,-2149.59960938,24883.36914062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (3)
	CreateDynamicObject(2747,2582.30004883,-2149.60009766,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (4)
	CreateDynamicObject(9339,2583.60009766,-2144.03002930,24883.69921875,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(sfnvilla001_cm) (1)
	CreateDynamicObject(9339,2583.59960938,-2144.02929688,24885.09960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(sfnvilla001_cm) (2)
	CreateDynamicObject(9339,2583.59960938,-2144.02929688,24886.50000000,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(sfnvilla001_cm) (3)
	CreateDynamicObject(9339,2570.42480469,-2127.69995117,24883.39843750,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(sfnvilla001_cm) (4)
	CreateDynamicObject(1523,2570.37988281,-2143.78002930,24883.00000000,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(gen_doorext10) (2)
	CreateDynamicObject(1523,2570.31372070,-2140.73999023,24883.00000000,0.00000000,0.00000000,270.00000000, .interiorid = 27); //object(gen_doorext10) (3)
	CreateDynamicObject(9339,2570.42480469,-2127.69921875,24884.79882812,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(sfnvilla001_cm) (5)
	CreateDynamicObject(9339,2570.42480469,-2130.69921875,24886.20898438,0.00000000,180.00000000,0.00000000, .interiorid = 27); //object(sfnvilla001_cm) (6)
	CreateDynamicObject(2596,2585.89990234,-2138.50000000,24886.19921875,20.00000000,0.00000000,310.00000000, .interiorid = 27); //object(cj_sex_tv) (1)
	CreateDynamicObject(1433,2583.60009766,-2140.69995117,24883.19921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(dyn_table_1) (1)
	CreateDynamicObject(1433,2583.60009766,-2141.80004883,24883.19921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(dyn_table_1) (2)
	CreateDynamicObject(1433,2582.49951172,-2141.79980469,24883.19921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(dyn_table_1) (3)
	CreateDynamicObject(1433,2582.49902344,-2140.69970703,24883.19921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(dyn_table_1) (4)
	CreateDynamicObject(2189,2583.10009766,-2141.19995117,24883.72851562,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(poker_tbl) (2)
	CreateDynamicObject(1739,2584.89990234,-2142.00000000,24883.80078125,0.00000000,0.00000000,326.25000000, .interiorid = 27); //object(swank_din_chair_5) (1)
	CreateDynamicObject(1739,2584.89990234,-2140.50000000,24883.80078125,0.00000000,0.00000000,36.25000000, .interiorid = 27); //object(swank_din_chair_5) (2)
	CreateDynamicObject(1739,2583.30004883,-2139.50000000,24883.80078125,0.00000000,0.00000000,96.24938965, .interiorid = 27); //object(swank_din_chair_5) (3)
	CreateDynamicObject(1739,2583.00000000,-2143.19995117,24883.80078125,0.00000000,0.00000000,266.24572754, .interiorid = 27); //object(swank_din_chair_5) (4)
	CreateDynamicObject(1739,2581.39990234,-2141.10009766,24883.80078125,0.00000000,0.00000000,185.74267578, .interiorid = 27); //object(swank_din_chair_5) (5)
	CreateDynamicObject(349,2578.83007812,-2139.50000000,24883.80078125,340.00000000,90.00000000,90.00000000, .interiorid = 27); //object(1)
	CreateDynamicObject(352,2582.10009766,-2142.10009766,24883.69921875,90.00000000,320.00000000,90.00000000, .interiorid = 27); //object(2)
	CreateDynamicObject(336,2578.89990234,-2139.69995117,24883.09960938,0.00000000,90.00000000,290.00000000, .interiorid = 27); //object(4)
	CreateDynamicObject(1543,2582.19995117,-2140.50000000,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_beer_b_2) (1)
	CreateDynamicObject(1664,2582.19995117,-2141.89990234,24883.90039062,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(propwinebotl2) (1)
	CreateDynamicObject(1551,2583.80004883,-2142.19995117,24883.80078125,0.00000000,90.00000000,40.00000000, .interiorid = 27); //object(dyn_wine_big) (1)
	CreateDynamicObject(1517,2582.39990234,-2140.30004883,24883.90039062,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(dyn_wine_break) (1)
	CreateDynamicObject(1665,2583.80004883,-2140.30004883,24883.72656250,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(propashtray1) (1)
	CreateDynamicObject(1510,2582.19995117,-2140.30004883,24883.72070312,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(dyn_ashtry) (1)
	CreateDynamicObject(1732,2580.10009766,-2138.60009766,24883.82031250,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_juke_box) (1)
	CreateDynamicObject(1481,2574.19995117,-2136.69995117,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(dyn_bar_b_q) (1)
	CreateDynamicObject(1738,2578.89990234,-2141.80004883,24883.63867188,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_radiator_old) (1)
	CreateDynamicObject(1778,2585.89990234,-2143.30004883,24883.02929688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_mop_pail) (1)
	CreateDynamicObject(1828,2582.69995117,-2141.39990234,24883.00000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(man_sdr_rug) (1)
	CreateDynamicObject(1971,2580.19995117,-2143.89990234,24885.59960938,0.00000000,0.00000000,180.00000000, .interiorid = 27); //object(kb_flykiller) (1)
	CreateDynamicObject(2144,2578.10009766,-2136.60009766,24883.00000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_cooker3) (1)
	CreateDynamicObject(2147,2577.10009766,-2136.80004883,24883.00000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_kitch1_fridge) (1)
	CreateDynamicObject(2451,2571.19995117,-2140.19995117,24883.00000000,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_ff_worktop_3) (1)
	CreateDynamicObject(2419,2571.19995117,-2138.30004883,24883.00000000,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_ff_worktop_2) (1)
	CreateDynamicObject(2418,2575.21997070,-2137.00000000,24883.00000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_ff_worktop) (1)
	CreateDynamicObject(2451,2573.69995117,-2143.30004883,24883.00000000,0.00000000,0.00000000,180.00000000, .interiorid = 27); //object(cj_ff_worktop_3) (2)
	CreateDynamicObject(2419,2575.60009766,-2143.30004883,24883.00000000,0.00000000,0.00000000,180.00000000, .interiorid = 27); //object(cj_ff_worktop_2) (2)
	CreateDynamicObject(2418,2577.69995117,-2140.89990234,24883.00000000,0.00000000,0.00000000,270.00000000, .interiorid = 27); //object(cj_ff_worktop) (2)
	CreateDynamicObject(2418,2577.69921875,-2139.00000000,24883.00000000,0.00000000,0.00000000,269.99450684, .interiorid = 27); //object(cj_ff_worktop) (3)
	CreateDynamicObject(2069,2585.60009766,-2138.89990234,24883.07031250,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_mlight7) (1)
	CreateDynamicObject(2069,2579.00000000,-2138.89990234,24883.09960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_mlight7) (2)
	CreateDynamicObject(2069,2573.00000000,-2136.69995117,24883.09960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cj_mlight7) (3)
	CreateDynamicObject(1778,2571.00000000,-2136.89990234,24883.03906250,0.00000000,0.00000000,180.00000000, .interiorid = 27); //object(cj_mop_pail) (2)
	CreateDynamicObject(3963,2582.60009766,-2150.38012695,24885.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(lee_plane08) (1)
	CreateDynamicObject(2269,2582.10009766,-2144.65991211,24885.50000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(frame_wood_4) (1)
	CreateDynamicObject(2270,2579.89990234,-2144.69995117,24885.30078125,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(frame_wood_6) (1)
	CreateDynamicObject(2271,2574.19995117,-2144.69995117,24885.50000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(frame_wood_1) (1)
	CreateDynamicObject(2263,2571.80004883,-2144.69995117,24885.00000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(frame_slim_4) (1)
	CreateDynamicObject(2258,2576.30004883,-2144.19995117,24885.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(frame_clip_5) (1)
	CreateDynamicObject(2256,2560.60009766,-2138.40991211,24885.50000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(frame_clip_3) (1)
	CreateDynamicObject(2257,2564.00000000,-2138.50000000,24885.19921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(frame_clip_4) (1)
	CreateDynamicObject(2026,2579.60009766,-2146.60009766,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(mrk_shade_tmp) (1)
	CreateDynamicObject(2026,2563.80004883,-2145.00000000,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(mrk_shade_tmp) (2)
	CreateDynamicObject(2026,2577.29980469,-2145.79980469,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(mrk_shade_tmp) (3)
	CreateDynamicObject(2026,2574.29980469,-2147.09960938,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(mrk_shade_tmp) (4)
	CreateDynamicObject(2026,2568.79980469,-2145.19921875,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(mrk_shade_tmp) (5)
	CreateDynamicObject(2026,2564.60009766,-2147.39990234,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(mrk_shade_tmp) (6)
	CreateDynamicObject(2026,2562.39990234,-2142.10009766,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(mrk_shade_tmp) (7)
	CreateDynamicObject(16780,2564.60009766,-2145.89990234,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(ufo_light03) (1)
	CreateDynamicObject(16780,2582.60009766,-2147.00000000,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(ufo_light03) (2)
	CreateDynamicObject(16780,2583.09960938,-2141.29980469,24886.59960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(ufo_light03) (3)
	CreateDynamicObject(2746,2580.69995117,-2145.00000000,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (4)
	CreateDynamicObject(9339,2584.00000000,-2156.89990234,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(sfnvilla001_cm) (7)
	CreateDynamicObject(9339,2584.00000000,-2156.89941406,24885.09960938,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(sfnvilla001_cm) (8)
	CreateDynamicObject(9339,2584.00000000,-2156.89941406,24886.50000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(sfnvilla001_cm) (9)
	CreateDynamicObject(2808,2583.40014648,-2145.30004883,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_pizza_chair4) (2)
	CreateDynamicObject(2808,2583.39990234,-2147.29980469,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_pizza_chair4) (3)
	CreateDynamicObject(2808,2583.39990234,-2149.29980469,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_pizza_chair4) (4)
	CreateDynamicObject(2747,2569.85937500,-2149.59960938,24883.36914062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (5)
	CreateDynamicObject(2747,2582.30004883,-2145.00000000,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (6)
	CreateDynamicObject(2746,2580.69995117,-2149.60009766,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (5)
	CreateDynamicObject(2747,2582.30004883,-2147.30004883,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (7)
	CreateDynamicObject(2747,2579.10009766,-2149.60009766,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (8)
	CreateDynamicObject(2746,2577.50000000,-2149.69995117,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (6)
	CreateDynamicObject(2747,2575.89990234,-2149.69995117,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (9)
	CreateDynamicObject(2746,2574.39990234,-2149.69995117,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (7)
	CreateDynamicObject(2746,2571.39990234,-2149.69995117,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (8)
	CreateDynamicObject(2747,2572.89990234,-2149.69995117,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (10)
	CreateDynamicObject(2747,2579.10009766,-2145.00000000,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (11)
	CreateDynamicObject(2746,2577.50000000,-2145.00000000,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (9)
	CreateDynamicObject(2747,2575.89990234,-2144.89990234,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (12)
	CreateDynamicObject(2746,2574.39990234,-2144.89990234,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (10)
	CreateDynamicObject(2747,2572.80004883,-2144.89990234,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (13)
	CreateDynamicObject(2746,2571.30004883,-2144.80004883,24883.59960938,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_chair) (11)
	CreateDynamicObject(9131,2566.65283203,-2141.56909180,24882.99804688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(shbbyhswall13_lvs) (2)
	CreateDynamicObject(9131,2566.65234375,-2142.31347656,24882.99804688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(shbbyhswall13_lvs) (3)
	CreateDynamicObject(9131,2566.65234375,-2143.01342773,24882.99804688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(shbbyhswall13_lvs) (4)
	CreateDynamicObject(9131,2566.65234375,-2143.76269531,24882.99804688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(shbbyhswall13_lvs) (5)
	CreateDynamicObject(9131,2567.40942383,-2143.76269531,24882.99804688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(shbbyhswall13_lvs) (6)
	CreateDynamicObject(9131,2568.16918945,-2143.76269531,24882.99804688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(shbbyhswall13_lvs) (7)
	CreateDynamicObject(9131,2568.89990234,-2143.76269531,24882.99804688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(shbbyhswall13_lvs) (8)
	CreateDynamicObject(9131,2569.65942383,-2143.76269531,24882.99804688,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(shbbyhswall13_lvs) (9)
	CreateDynamicObject(3044,2574.10009766,-2136.69995117,24883.80078125,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cigar) (1)
	CreateDynamicObject(3044,2573.00000000,-2143.19995117,24883.80078125,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cigar) (2)
	CreateDynamicObject(3044,2573.80004883,-2143.00000000,24883.50000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cigar) (3)
	CreateDynamicObject(3044,2582.10009766,-2140.10009766,24883.80078125,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cigar) (4)
	CreateDynamicObject(3044,2583.69995117,-2140.30004883,24883.80078125,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(cigar) (5)
	CreateDynamicObject(2747,2569.69995117,-2144.89990234,24883.40039062,0.00000000,0.00000000,90.00000000, .interiorid = 27); //object(cj_donut_table) (15)
	CreateDynamicObject(2500,2569.39990234,-2143.89990234,24884.12890625,0.00000000,0.00000000,180.00000000, .interiorid = 27); //object(cj_ff_coffee) (1)
	CreateDynamicObject(2443,2570.00000000,-2139.19995117,24883.00000000,0.00000000,0.00000000,270.00000000, .interiorid = 27); //object(cj_ff_frige) (1)
	CreateDynamicObject(2369,2567.00000000,-2140.89990234,24884.11914062,0.00000000,0.00000000,270.00000000, .interiorid = 27); //object(cj_till) (1)
	CreateDynamicObject(2802,2559.10009766,-2145.50000000,24883.33984375,0.00000000,0.00000000,180.00000000, .interiorid = 27); //object(castable1) (1)
	CreateDynamicObject(2802,2562.50000000,-2145.50000000,24883.33984375,0.00000000,0.00000000,99.99447632, .interiorid = 27); //object(castable1) (2)
	CreateDynamicObject(2800,2559.00000000,-2145.60009766,24883.50000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(castable2top) (1)
	CreateDynamicObject(2800,2562.50000000,-2145.59960938,24883.50000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(castable2top) (2)
	CreateDynamicObject(1931,2583.39990234,-2141.00000000,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(chip_stack14) (1)
	CreateDynamicObject(1930,2583.39990234,-2141.10009766,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(chip_stack13) (1)
	CreateDynamicObject(1932,2582.60009766,-2140.89990234,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(chip_stack15) (1)
	CreateDynamicObject(1933,2582.50000000,-2141.39990234,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(chip_stack16) (1)
	CreateDynamicObject(1930,2583.00000000,-2141.89990234,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(chip_stack13) (2)
	CreateDynamicObject(1900,2582.10009766,-2141.60009766,24883.69921875,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(pkr_chplo07) (1)
	CreateDynamicObject(9345,2564.89990234,-2141.39990234,24886.97851562,0.00000000,180.00000000,180.00000000, .interiorid = 27); //object(sfn_pier_grassbit) (1)
	CreateDynamicObject(9345,2565.00000000,-2148.39990234,24886.97070312,0.00000000,179.99450684,179.99450684, .interiorid = 27); //object(sfn_pier_grassbit) (2)
	CreateDynamicObject(9345,2577.00000000,-2140.19995117,24887.00000000,0.00000000,179.99450684,179.99450684, .interiorid = 27); //object(sfn_pier_grassbit) (3)
	CreateDynamicObject(9345,2581.00000000,-2148.39990234,24887.00000000,0.00000000,179.99450684,179.99450684, .interiorid = 27); //object(sfn_pier_grassbit) (4)
	CreateDynamicObject(9345,2585.69995117,-2141.89990234,24887.00000000,0.00000000,179.99450684,179.99450684, .interiorid = 27); //object(sfn_pier_grassbit) (5)
	CreateDynamicObject(1530,2578.28002930,-2139.40014648,24885.30078125,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(tag_vagos) (1)
	CreateDynamicObject(1530,2583.60009766,-2138.38891602,24885.30078125,15.00000000,0.00000000,90.00000000, .interiorid = 27); //object(tag_vagos) (2)
	CreateDynamicObject(1530,2586.12988281,-2141.19921875,24885.30078125,15.00000000,0.00000000,0.00000000, .interiorid = 27); //object(tag_vagos) (3)
	CreateDynamicObject(14840,2575.47021484,-2136.29003906,24884.80078125,0.00000000,0.00000000,270.00000000, .interiorid = 27); //object(bdups_graf) (1)
	CreateDynamicObject(1265,2572.39990234,-2136.89990234,24883.50000000,0.00000000,0.00000000,0.00000000, .interiorid = 27); //object(blackbag2) (1)

	// Vatos Interior #2
	CreateDynamicObject(18007, 1898.20, -1766.40, 19202.80, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2205, 1898.30, -1769.40, 19200.61, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(1735, 1896.61, -1770.10, 19200.70, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(1810, 1895.00, -1767.00, 19200.65, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1670, 1898.40, -1770.90, 19201.56, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1530, 1895.17, -1767.60, 19202.60, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1527, 1893.60, -1766.39, 19202.80, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(4227, 1890.46, -1765.30, 19202.80, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(17969, 1890.90, -1768.85, 19203.00, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(17522, 1905.40, -1759.18, 19202.91, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2190, 1898.60, -1769.50, 19201.50, 0.00, 0.00, 295.75, .interiorid = 27);
	CreateDynamicObject(2002, 1904.90, -1768.20, 19200.60, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(2002, 1904.90, -1768.80, 19200.60, 0.00, 0.00, 269.99, .interiorid = 27);
	CreateDynamicObject(1971, 1901.70, -1767.80, 19204.00, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1829, 1891.40, -1768.40, 19201.10, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(1828, 1900.90, -1770.00, 19200.66, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1778, 1893.80, -1771.40, 19200.70, 0.00, 0.00, 210.00, .interiorid = 27);
	CreateDynamicObject(1738, 1896.20, -1767.90, 19201.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1510, 1898.20, -1770.60, 19201.58, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1487, 1898.50, -1770.00, 19201.60, 0.00, 90.00, 325.00, .interiorid = 27);
	CreateDynamicObject(1485, 1898.10, -1770.60, 19201.60, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1753, 1901.30, -1768.30, 19200.63, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2074, 1892.70, -1767.70, 19204.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2261, 1899.40, -1768.28, 19203.20, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2264, 1897.90, -1768.24, 19203.30, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2267, 1895.61, -1768.40, 19203.30, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(1433, 1891.24, -1767.20, 19200.86, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(352, 1891.00, -1766.90, 19201.36,   90.00, 330.00, 0.00, .interiorid = 27);
	CreateDynamicObject(349, 1891.83, -1766.90, 19201.53,   350.00, 90.00, 90.00, .interiorid = 27);
	CreateDynamicObject(335, 1890.90, -1768.30, 19201.55,   90.00, 90.00, 320.00, .interiorid = 27);
	CreateDynamicObject(2309, 1899.90, -1770.70, 19200.70, 0.00, 0.00, 62.00, .interiorid = 27);
	CreateDynamicObject(1493, 1904.74, -1771.09, 19200.68, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(1235, 1893.90, -1770.70, 19201.19, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2867, 1891.30, -1767.30, 19201.40, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2859, 1894.80, -1771.00, 19200.70, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1530, 1895.17, -1767.60, 19202.60, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1530, 1893.61, -1766.41, 19202.74,   10.00, 0.00, 90.00, .interiorid = 27);

    // Vatos Interior #3
	CreateDynamicObject(14488, 1233.92, -763.88, 51086.12, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3109, 1242.16, -774.31, 51084.88, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(7191, 1240.89, -774.43, 51083.70,   90.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2114, 1235.01, -758.22, 51083.82, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1985, 1243.66, -759.96, 51086.61, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1985, 1240.85, -756.76, 51086.61, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1985, 1240.86, -754.48, 51086.61, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3092, 1241.37, -760.14, 51086.01,   180.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2627, 1242.66, -762.99, 51083.67, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(2627, 1242.64, -763.99, 51083.67, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(2627, 1242.64, -764.96, 51083.67, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(2628, 1225.18, -759.23, 51083.69, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2629, 1225.07, -757.91, 51083.69, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2629, 1225.09, -756.13, 51083.69, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2630, 1242.67, -766.95, 51083.69, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(2630, 1242.68, -768.45, 51083.69, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(1786, 1244.41, -763.82, 51085.23, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(2631, 1226.63, -754.21, 51083.70, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2913, 1224.45, -757.42, 51084.59,   90.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2913, 1224.49, -755.66, 51084.59,   90.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3071, 1224.22, -754.87, 51083.79,   90.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2916, 1224.41, -754.42, 51083.76, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3072, 1224.41, -753.46, 51083.79,   90.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3072, 1224.40, -753.81, 51083.79,   90.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2916, 1224.39, -754.13, 51083.76, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(3071, 1224.49, -754.87, 51083.79,   90.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(14792, 1234.08, -763.59, 51085.21, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(349, 1224.54, -773.96, 51084.18, 0.00, 270.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2913, 1228.48, -753.14, 51084.09,   6.00, 0.00, 180.00, .interiorid = 27);
	CreateDynamicObject(2913, 1227.88, -753.18, 51084.09,   6.00, 0.00, 180.00, .interiorid = 27);
	CreateDynamicObject(4227, 1239.67, -753.02, 51085.62, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1530, 1228.69, -752.95, 51085.60, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(17969, 1234.05, -774.10, 51088.62,   -10.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(1530, 1244.05, -761.27, 51084.85, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(14840, 1224.17, -772.67, 51087.34, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(5016, 1260.74, -773.87, 51086.88, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(5016, 1260.73, -758.29, 51086.88, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(3260, 1244.13, -761.22, 51083.89, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(3260, 1244.14, -768.07, 51083.89, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(1530, 1244.10, -767.51, 51084.85,   -10.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1530, 1231.86, -774.13, 51088.13, 0.00, 0.00, 270.00, .interiorid = 27);
	CreateDynamicObject(947, 1234.20, -754.35, 51085.85, 0.00, 0.00, 180.00, .interiorid = 27);
	CreateDynamicObject(5663, 1166.56, -722.64, 51091.14, 0.00, 0.00, 180.00, .interiorid = 27);
	CreateDynamicObject(3260, 1224.08, -762.46, 51085.55, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(3260, 1224.07, -760.53, 51085.55, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(3260, 1224.05, -758.57, 51085.55, 0.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(2674, 1242.56, -772.65, 51083.71, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2674, 1241.03, -772.92, 51083.70, 0.00, 0.00, -178.00, .interiorid = 27);
	CreateDynamicObject(2674, 1242.12, -771.34, 51083.71, 0.00, 0.00, 84.00, .interiorid = 27);
	CreateDynamicObject(2670, 1240.67, -771.60, 51083.78, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2675, 1238.53, -772.05, 51083.76, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2674, 1236.05, -772.85, 51083.71, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(2670, 1232.85, -773.39, 51083.78, 0.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(13607, 1231.62, -756.43, 51086.16,   90.00, 0.00, 0.00, .interiorid = 27);
	CreateDynamicObject(13607, 1227.57, -722.09, 51086.16,   90.00, 0.00, 90.00, .interiorid = 27);
	CreateDynamicObject(13607, 1229.58, -771.34, 51086.16,   90.00, 0.00, 180.00, .interiorid = 27);
	CreateDynamicObject(4148, 1224.08, -760.08, 51085.58, 0.00, 90.00, 180.00, .interiorid = 27);
	CreateDynamicObject(4148, 1244.05, -761.61, 51085.58, 0.00, 90.00, 0.00, .interiorid = 27);
	CreateDynamicObject(1411, 1234.78, -765.13, 51084.85, 0.00, 0.00, 160.00, .interiorid = 27);
	CreateDynamicObject(2631, 1231.36, -767.92, 51083.73, 0.00, 0.00, 69.00, .interiorid = 27);
	CreateDynamicObject(1411, 1230.95, -766.63, 51084.85, 0.00, 0.00, 249.00, .interiorid = 27);
	CreateDynamicObject(2631, 1233.39, -765.48, 51083.74, 0.00, 0.00, 159.39, .interiorid = 27);
	CreateDynamicObject(2631, 1233.23, -768.63, 51083.73, 0.00, 0.00, 69.00, .interiorid = 27);
	CreateDynamicObject(2631, 1235.10, -769.33, 51083.73, 0.00, 0.00, 69.00, .interiorid = 27);
	CreateDynamicObject(2631, 1235.24, -766.17, 51083.73, 0.00, 0.00, 159.39, .interiorid = 27);
	CreateDynamicObject(1411, 1232.49, -770.28, 51084.85, 0.00, 0.00, -20.00, .interiorid = 27);
	CreateDynamicObject(1411, 1235.93, -769.07, 51084.85, 0.00, 0.00, 62.00, .interiorid = 27);
	
	//SANews
	CreateDynamicObject(14594, 2627.89, -1824.41, -39.74, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1491, 2627.83, -1807.46, -39.72, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1491, 2641.31, -1805.98, -39.72, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(1491, 2641.28, -1817.46, -39.72, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(1708, 2624.53, -1811.47, -39.73, 0.00, 0.00, 34.00, .interiorid = 26);
	CreateDynamicObject(1708, 2627.92, -1810.86, -39.73, 0.00, 0.00, 332.50, .interiorid = 26);
	CreateDynamicObject(1708, 2626.15, -1810.74, -39.73, 0.00, 0.00, 0.49, .interiorid = 26);
	CreateDynamicObject(2184, 2627.69, -1812.97, -39.73, 0.00, 0.00, 179.99, .interiorid = 26);
	CreateDynamicObject(1715, 2626.57, -1814.95, -39.73, 0.00, 0.00, 178.49, .interiorid = 26);
	CreateDynamicObject(2190, 2626.10, -1813.10, -38.95, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(14455, 2624.77, -1817.30, -37.98, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(948, 2624.29, -1816.67, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(948, 2629.62, -1816.63, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2287, 2625.62, -1808.39, -37.50, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2286, 2623.90, -1812.53, -37.76, 0.00, 0.00, 90.25, .interiorid = 26);
	CreateDynamicObject(2280, 2629.63, -1813.11, -37.60, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(2164, 2648.19, -1798.95, -39.73, 0.00, 0.00, 0.25, .interiorid = 26);
	CreateDynamicObject(2167, 2647.29, -1798.96, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2163, 2645.53, -1798.95, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2164, 2643.78, -1798.96, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2167, 2642.89, -1798.97, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2162, 2649.02, -1808.64, -39.73, 0.00, 0.00, 179.99, .interiorid = 26);
	CreateDynamicObject(2161, 2647.20, -1808.63, -39.73, 0.00, 0.00, 180.25, .interiorid = 26);
	CreateDynamicObject(1713, 2644.02, -1819.92, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1713, 2646.65, -1821.77, -39.73, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(1713, 2646.66, -1825.26, -39.73, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(1713, 2645.62, -1828.70, -39.73, 0.00, 0.00, 179.99, .interiorid = 26);
	CreateDynamicObject(2239, 2646.83, -1828.83, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2239, 2646.76, -1819.90, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2239, 2642.98, -1819.78, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2239, 2642.93, -1828.82, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2315, 2644.79, -1823.32, -39.73, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(2315, 2644.79, -1826.86, -39.73, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(2271, 2644.83, -1819.90, -37.65, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2267, 2647.24, -1822.54, -37.48, 0.00, 0.00, 269.75, .interiorid = 26);
	CreateDynamicObject(2266, 2646.78, -1826.03, -37.75, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(2262, 2644.76, -1828.91, -37.83, 0.00, 0.00, 179.99, .interiorid = 26);
	CreateDynamicObject(2239, 2624.60, -1807.09, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2239, 2624.66, -1803.47, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1360, 2624.75, -1805.23, -38.95, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2251, 2644.69, -1822.56, -38.39, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2251, 2644.80, -1826.16, -38.39, 0.00, 0.00, 120.00, .interiorid = 26);
	CreateDynamicObject(1364, 2633.42, -1832.23, -38.95, 0.00, 0.00, 90.74, .interiorid = 26);
	CreateDynamicObject(1364, 2633.43, -1819.47, -38.95, 0.00, 0.00, 89.99, .interiorid = 26);
	CreateDynamicObject(18014, 2633.84, -1815.04, -39.29, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(18014, 2633.79, -1825.44, -39.29, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2002, 2642.07, -1799.45, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2002, 2646.71, -1824.32, -39.73, 0.00, 0.00, 269.25, .interiorid = 26);
	CreateDynamicObject(2002, 2640.68, -1829.64, -39.73, 0.00, 0.00, 269.25, .interiorid = 26);
	CreateDynamicObject(2002, 2640.70, -1819.13, -39.73, 0.00, 0.00, 269.25, .interiorid = 26);
	CreateDynamicObject(1999, 2648.94, -1801.37, -39.73, 0.00, 0.00, 270.50, .interiorid = 26);
	CreateDynamicObject(1999, 2648.97, -1804.46, -39.73, 0.00, 0.00, 270.49, .interiorid = 26);
	CreateDynamicObject(1715, 2647.72, -1805.02, -39.73, 0.00, 0.00, 68.00, .interiorid = 26);
	CreateDynamicObject(1715, 2647.85, -1802.32, -39.73, 0.00, 0.00, 104.00, .interiorid = 26);
	CreateDynamicObject(1999, 2644.90, -1808.13, -39.73, 0.00, 0.00, 181.25, .interiorid = 26);
	CreateDynamicObject(1715, 2644.00, -1806.77, -39.73, 0.00, 0.00, 21.99, .interiorid = 26);
	CreateDynamicObject(2277, 2644.76, -1808.18, -38.71, 0.00, 0.00, 179.75, .interiorid = 26);
	CreateDynamicObject(2275, 2633.92, -1811.82, -37.73, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(2270, 2633.91, -1822.36, -37.85, 0.00, 0.00, 90.25, .interiorid = 26);
	CreateDynamicObject(2270, 2633.91, -1828.29, -37.85, 0.00, 0.00, 90.25, .interiorid = 26);
	CreateDynamicObject(1742, 2641.70, -1803.77, -39.73, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(1742, 2641.71, -1801.01, -39.73, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(1661, 2645.90, -1802.44, -35.87, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1661, 2645.82, -1806.67, -35.90, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2287, 2649.03, -1803.36, -37.46, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(2596, 2642.67, -1808.37, -37.33, 0.00, 0.00, 178.99, .interiorid = 26);
	CreateDynamicObject(2596, 2649.21, -1806.49, -37.33, 0.00, 0.00, 269.24, .interiorid = 26);
	CreateDynamicObject(2700, 2649.23, -1800.52, -37.41, 0.00, 0.00, 179.99, .interiorid = 26);
	CreateDynamicObject(1616, 2641.18, -1807.70, -36.01, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1616, 2624.50, -1803.62, -36.01, 0.00, 0.00, 179.75, .interiorid = 26);
	CreateDynamicObject(2184, 2651.11, -1815.90, -39.73, 0.00, 0.00, 18.50, .interiorid = 26);
	CreateDynamicObject(2184, 2648.30, -1814.96, -39.73, 0.00, 0.00, 335.25, .interiorid = 26);
	CreateDynamicObject(2184, 2650.47, -1812.13, -39.73, 0.00, 0.00, 198.50, .interiorid = 26);
	CreateDynamicObject(2184, 2653.29, -1813.09, -39.73, 0.00, 0.00, 154.74, .interiorid = 26);
	CreateDynamicObject(1360, 2650.85, -1813.96, -38.96, 0.00, 0.00, 266.24, .interiorid = 26);
	CreateDynamicObject(2001, 2650.24, -1813.91, -38.94, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2651.57, -1813.95, -38.94, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2011, 2650.87, -1813.98, -38.97, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1714, 2653.85, -1812.09, -39.73, 0.00, 0.00, 317.75, .interiorid = 26);
	CreateDynamicObject(1714, 2651.94, -1811.16, -39.73, 0.00, 0.00, 349.74, .interiorid = 26);
	CreateDynamicObject(1714, 2650.24, -1811.08, -39.73, 0.00, 0.00, 1.74, .interiorid = 26);
	CreateDynamicObject(1714, 2648.14, -1811.81, -39.73, 0.00, 0.00, 35.99, .interiorid = 26);
	CreateDynamicObject(1714, 2647.78, -1815.97, -39.73, 0.00, 0.00, 137.24, .interiorid = 26);
	CreateDynamicObject(1714, 2649.82, -1816.92, -39.73, 0.00, 0.00, 173.23, .interiorid = 26);
	CreateDynamicObject(1714, 2651.32, -1816.97, -39.73, 0.00, 0.00, 183.48, .interiorid = 26);
	CreateDynamicObject(1714, 2653.42, -1816.41, -39.73, 0.00, 0.00, 215.47, .interiorid = 26);
	CreateDynamicObject(18014, 2646.51, -1809.78, -39.29, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(18014, 2654.06, -1809.80, -39.29, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(18014, 2654.05, -1818.31, -39.29, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(18014, 2646.62, -1818.31, -39.29, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(2286, 2656.36, -1813.92, -37.68, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(2282, 2650.31, -1809.87, -38.03, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2267, 2650.17, -1818.66, -37.52, 0.00, 0.00, 179.99, .interiorid = 26);
	CreateDynamicObject(1713, 2640.68, -1813.06, -39.73, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(1713, 2640.71, -1807.28, -39.73, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(2001, 2652.23, -1818.30, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2653.55, -1818.23, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.54, -1818.22, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2652.23, -1809.74, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2653.71, -1809.62, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.52, -1809.61, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2644.85, -1818.16, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2646.35, -1818.18, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2648.37, -1818.17, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2647.94, -1809.63, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2646.60, -1809.62, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2644.87, -1809.58, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1713, 2640.68, -1813.06, -39.73, 0.00, 0.00, 269.49, .interiorid = 26);
	CreateDynamicObject(1713, 2642.37, -1814.52, -39.73, 0.00, 0.00, 89.49, .interiorid = 26);
	CreateDynamicObject(2315, 2643.98, -1814.49, -39.73, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(1666, 2643.92, -1813.22, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.25, -1814.61, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2643.69, -1814.53, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2643.60, -1812.86, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.26, -1813.11, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.94, -1823.01, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.57, -1823.49, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.50, -1821.77, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2645.10, -1821.85, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.59, -1822.46, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2645.02, -1825.29, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.55, -1825.35, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2645.03, -1826.42, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.48, -1826.53, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2644.86, -1826.98, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2251, 2644.03, -1813.80, -38.39, 0.00, 0.00, 119.99, .interiorid = 26);
	CreateDynamicObject(1666, 2644.05, -1814.25, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1491, 2652.63, -1836.68, -39.72, 0.00, 0.00, 180.00, .interiorid = 26);
	CreateDynamicObject(1714, 2650.93, -1833.14, -39.73, 0.00, 0.00, 210.00, .interiorid = 26);
	CreateDynamicObject(1714, 2647.65, -1833.27, -39.73, 0.00, 0.00, 159.99, .interiorid = 26);
	CreateDynamicObject(2239, 2642.37, -1836.19, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2290, 2649.25, -1843.55, -39.73, 0.00, 0.00, 179.99, .interiorid = 26);
	CreateDynamicObject(2290, 2652.24, -1841.94, -39.73, 0.00, 0.00, 215.99, .interiorid = 26);
	CreateDynamicObject(1705, 2644.25, -1841.45, -39.73, 0.00, 0.00, 80.25, .interiorid = 26);
	CreateDynamicObject(2206, 2645.80, -1840.25, -39.73, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(2315, 2649.97, -1841.55, -39.73, 0.00, 0.00, 34.75, .interiorid = 26);
	CreateDynamicObject(2315, 2647.27, -1842.03, -39.73, 0.00, 0.00, 354.75, .interiorid = 26);
	CreateDynamicObject(1666, 2647.29, -1842.02, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2648.90, -1842.40, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2648.46, -1842.03, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2647.76, -1842.35, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2649.96, -1841.52, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2650.38, -1841.02, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2650.67, -1841.27, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2651.13, -1840.71, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2650.68, -1840.62, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2651.22, -1840.34, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1666, 2647.71, -1841.68, -39.15, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2894, 2645.75, -1840.47, -38.79, 0.00, 0.00, 110.00, .interiorid = 26);
	CreateDynamicObject(2894, 2645.81, -1841.89, -38.79, 0.00, 0.00, 59.99, .interiorid = 26);
	CreateDynamicObject(18014, 2642.25, -1842.50, -39.29, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(18014, 2644.76, -1844.47, -39.29, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(18014, 2649.44, -1844.45, -39.29, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(18014, 2653.73, -1844.46, -39.32, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(18014, 2655.40, -1842.32, -39.32, 0.00, 0.00, 179.99, .interiorid = 26);
	CreateDynamicObject(2251, 2650.72, -1841.02, -38.39, 0.00, 0.00, 119.99, .interiorid = 26);
	CreateDynamicObject(2251, 2648.11, -1842.17, -38.39, 0.00, 0.00, 119.99, .interiorid = 26);
	CreateDynamicObject(2894, 2627.67, -1813.31, -38.94, 0.00, 0.00, 140.75, .interiorid = 26);
	CreateDynamicObject(2894, 2626.55, -1813.26, -38.94, 0.00, 0.00, 240.74, .interiorid = 26);
	CreateDynamicObject(2894, 2627.14, -1813.58, -38.94, 0.00, 0.00, 288.24, .interiorid = 26);
	CreateDynamicObject(1713, 2633.51, -1803.69, -39.73, 0.00, 0.00, 0.25, .interiorid = 26);
	CreateDynamicObject(2001, 2645.60, -1818.17, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2647.85, -1818.22, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2647.10, -1818.20, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2652.85, -1818.32, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2654.20, -1818.35, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2654.87, -1818.31, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2654.85, -1809.72, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2654.25, -1809.89, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2652.83, -1809.89, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2648.45, -1809.81, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2647.45, -1809.91, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2645.05, -1809.90, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2645.82, -1809.91, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2646.79, -1809.94, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2634.02, -1813.32, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2634.04, -1813.87, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.90, -1814.60, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.93, -1815.48, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.96, -1816.13, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.99, -1816.90, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.88, -1823.56, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.91, -1824.17, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.92, -1824.81, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.95, -1825.57, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.85, -1826.25, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2633.99, -1826.91, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2634.01, -1827.42, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2653.72, -1809.92, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.72, -1809.98, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.95, -1818.17, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2652.03, -1818.26, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2648.72, -1818.29, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2644.44, -1809.97, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2642.42, -1840.46, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2642.39, -1841.09, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2642.36, -1841.69, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2642.32, -1842.44, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2642.29, -1843.14, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2642.36, -1843.77, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2642.40, -1844.47, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2643.10, -1844.46, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2643.60, -1844.48, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2644.19, -1844.35, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2644.94, -1844.31, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2645.49, -1844.44, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2646.16, -1844.40, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2646.69, -1844.38, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2647.51, -1844.44, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2648.11, -1844.41, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2648.63, -1844.43, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2649.31, -1844.40, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2649.90, -1844.37, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2650.48, -1844.44, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2651.18, -1844.46, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2651.50, -1844.44, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2652.17, -1844.33, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2652.89, -1844.29, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2653.52, -1844.31, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2652.42, -1844.32, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2653.96, -1844.40, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2654.69, -1844.36, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.34, -1844.26, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.40, -1843.54, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.43, -1842.99, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.41, -1842.46, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.39, -1841.88, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.46, -1841.27, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.38, -1840.65, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2001, 2655.41, -1840.27, -39.82, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2190, 2648.99, -1814.60, -38.95, 0.00, 0.00, 320.00, .interiorid = 26);
	CreateDynamicObject(2190, 2650.60, -1815.46, -38.95, 0.00, 0.00, 292.00, .interiorid = 26);
	CreateDynamicObject(2190, 2651.53, -1815.20, -38.95, 0.00, 0.00, 341.99, .interiorid = 26);
	CreateDynamicObject(2190, 2652.59, -1814.58, -38.95, 0.00, 0.00, 11.99, .interiorid = 26);
	CreateDynamicObject(2190, 2652.31, -1813.05, -38.95, 0.00, 0.00, 101.99, .interiorid = 26);
	CreateDynamicObject(2190, 2651.37, -1812.83, -38.95, 0.00, 0.00, 151.99, .interiorid = 26);
	CreateDynamicObject(2190, 2650.13, -1812.79, -38.95, 0.00, 0.00, 171.98, .interiorid = 26);
	CreateDynamicObject(2190, 2648.89, -1813.31, -38.95, 0.00, 0.00, 201.98, .interiorid = 26);
	CreateDynamicObject(2103, 2648.99, -1804.55, -38.91, 0.00, 0.00, 300.00, .interiorid = 26);
	CreateDynamicObject(14391, 2649.28, -1831.21, -38.80, 0.00, 0.00, 270.25, .interiorid = 26);
	CreateDynamicObject(2852, 2644.92, -1825.79, -39.23, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2854, 2644.72, -1823.41, -39.23, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2855, 2644.81, -1821.89, -39.23, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2828, 2649.05, -1801.54, -38.91, 0.00, 0.00, 110.00, .interiorid = 26);
	CreateDynamicObject(1713, 2643.32, -1831.83, -39.73, 0.00, 0.00, 359.74, .interiorid = 26);
	CreateDynamicObject(948, 2653.31, -1831.87, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(948, 2642.36, -1831.88, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2818, 2636.76, -1805.32, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2818, 2636.76, -1806.42, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2818, 2636.76, -1807.53, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2818, 2636.76, -1804.22, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2207, 2637.01, -1846.21, -39.77, 0.00, 0.00, 180.00, .interiorid = 26);
	CreateDynamicObject(9339, 2630.27, -1848.63, -39.08, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(9339, 2630.29, -1848.55, -35.52, 0.00, 180.00, 0.00, .interiorid = 26);
	CreateDynamicObject(9339, 2630.28, -1826.61, -37.70, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(9339, 2630.28, -1826.61, -36.30, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(9339, 2630.24, -1860.93, -36.30, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(9339, 2630.25, -1860.93, -37.68, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(9339, 2617.12, -1848.34, -37.71, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(9339, 2617.10, -1848.32, -36.34, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(9339, 2617.12, -1839.21, -37.77, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(9339, 2617.12, -1839.19, -36.38, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(8832, 2590.32, -1847.41, -39.23, 0.00, -6.50, 0.00, .interiorid = 26);
	CreateDynamicObject(8832, 2590.43, -1844.54, -42.74, 0.00, -6.50, 0.00, .interiorid = 26);
	CreateDynamicObject(10444, 2630.06, -1843.93, -37.58, 0.00, 90.00, 0.00, .interiorid = 26);
	CreateDynamicObject(9339, 2627.06, -1846.49, -37.74, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(9339, 2627.06, -1846.49, -36.53, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1601, 2629.12, -1843.50, -36.60, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1603, 2627.75, -1839.73, -37.31, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1603, 2627.67, -1840.34, -36.97, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1599, 2628.35, -1840.55, -37.11, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1599, 2627.69, -1841.19, -36.38, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1605, 2628.39, -1846.63, -37.55, 0.00, 0.00, 180.00, .interiorid = 26);
	CreateDynamicObject(1610, 2629.02, -1842.14, -38.52, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(16655, 2619.53, -1824.27, -37.25, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(1714, 2635.89, -1848.26, -39.76, 0.00, 0.00, 180.00, .interiorid = 26);
	CreateDynamicObject(2190, 2635.58, -1846.36, -39.04, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2253, 2636.90, -1846.89, -38.87, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2894, 2636.29, -1846.41, -38.99, 0.00, 0.00, -18.00, .interiorid = 26);
	CreateDynamicObject(14455, 2640.89, -1849.05, -38.12, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(14455, 2640.84, -1843.08, -38.12, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(2126, 2631.86, -1840.61, -39.79, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1455, 2632.90, -1839.87, -39.21, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1455, 2633.05, -1840.49, -39.21, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1455, 2632.71, -1840.59, -39.21, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1455, 2631.86, -1840.48, -39.21, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1455, 2631.74, -1839.78, -39.21, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(644, 2631.21, -1849.04, -39.45, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1960, 2637.74, -1837.92, -36.93, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1961, 2638.47, -1837.91, -36.92, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1962, 2639.20, -1837.91, -36.91, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2230, 2638.01, -1837.82, -39.74, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2230, 2639.70, -1837.76, -39.74, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1839, 2638.57, -1838.18, -39.28, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(2346, 2638.05, -1838.14, -39.76, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2230, 2640.09, -1837.74, -39.74, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2230, 2637.64, -1837.83, -39.74, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2852, 2632.67, -1840.16, -39.68, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2854, 2631.96, -1840.27, -39.68, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(2265, 2633.02, -1849.41, -37.36, 0.00, 0.00, 180.00, .interiorid = 26);
	CreateDynamicObject(2258, 2639.34, -1849.83, -37.04, 0.00, 0.00, 180.00, .interiorid = 26);
	CreateDynamicObject(19173, 2632.55, -1837.91, -37.25, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1708, 2637.51, -1845.14, -39.73, 0.00, 0.00, -33.00, .interiorid = 26);
	CreateDynamicObject(1713, 2631.57, -1838.63, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1708, 2633.75, -1845.54, -39.73, 0.00, 0.00, 25.00, .interiorid = 26);
	CreateDynamicObject(1708, 2635.55, -1844.78, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1713, 2633.19, -1841.97, -39.73, 0.00, 0.00, 180.00, .interiorid = 26);
	CreateDynamicObject(2818, 2636.93, -1836.62, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(948, 2636.10, -1836.28, -39.76, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(948, 2638.80, -1836.22, -39.76, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(19375, 2633.29, -1824.30, -36.71,   90.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(19356, 2649.51, -1836.70, -40.62, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19356, 2646.30, -1836.70, -40.62, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19356, 2643.09, -1836.70, -40.62, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19356, 2643.11, -1836.70, -34.82, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19356, 2646.30, -1836.70, -34.82, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19356, 2649.51, -1836.70, -34.82, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19356, 2654.22, -1836.70, -40.62, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19375, 2655.92, -1836.70, -31.32, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19325, 2653.18, -1836.75, -33.90,   90.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19325, 2641.15, -1836.75, -38.22, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19325, 2647.79, -1836.75, -38.22, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19325, 2655.94, -1836.75, -39.28, 0.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(19325, 2657.31, -1836.75, -33.90,   90.00, 0.00, 90.00, .interiorid = 26);
	CreateDynamicObject(14782, 2655.48, -1833.49, -38.73, 0.00, 0.00, 270.00, .interiorid = 26);
	CreateDynamicObject(948, 2655.49, -1834.58, -39.73, 0.00, 0.00, 0.00, .interiorid = 26);
	CreateDynamicObject(1536, 2638.21, -1836.72, -39.79, 0.00, 0.00, 180.00, .interiorid = 26);
	CreateDynamicObject(1536, 2635.00, -1837.90, -39.79, 0.00, 0.00, 0.00, .interiorid = 26);
	
	// AL Club
	CreateDynamicObject(14536, 1892.09, -1939.49, 22212.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(14537, 1890.71, -1938.90, 22196.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(14546, 1892.09, -1939.49, 22212.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(14533, 1892.10, -1939.50, 22212.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1649, 1901.80, -1952.50, 22212.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1649, 1892.00, -1952.52, 22208.82,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1649, 1895.60, -1952.50, 22212.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1649, 1898.10, -1952.50, 22208.29,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(14455, 1904.80, -1958.60, 22208.84,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(14455, 1904.80, -1964.34, 22208.84,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2206, 1901.90, -1958.20, 22207.17,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1735, 1903.60, -1957.30, 22207.20,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(1704, 1900.20, -1959.20, 22207.20,   0.00, 0.00, 121.75, .interiorid = 25);
	CreateDynamicObject(1827, 1899.90, -1957.20, 22207.19,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1704, 1899.90, -1956.00, 22207.20,   0.00, 0.00, 64.49, .interiorid = 25);
	CreateDynamicObject(1670, 1899.80, -1957.10, 22207.63,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2190, 1901.60, -1958.00, 22208.10,   0.00, 0.00, 111.75, .interiorid = 25);
	CreateDynamicObject(2332, 1903.40, -1953.00, 22207.63,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(1829, 1900.60, -1953.10, 22207.63,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1828, 1898.40, -1957.40, 22207.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1808, 1892.50, -1953.80, 22207.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2964, 1895.00, -1956.30, 22207.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3105, 1895.10, -1956.20, 22208.03,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3104, 1894.90, -1956.30, 22208.03,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3102, 1894.20, -1955.90, 22208.03,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3100, 1895.10, -1956.60, 22208.03,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3103, 1895.50, -1956.10, 22208.03,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3106, 1895.60, -1956.70, 22208.03,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2965, 1895.10, -1956.20, 22208.00,   0.00, 0.00, 237.75, .interiorid = 25);
	CreateDynamicObject(1665, 1902.10, -1956.60, 22208.12,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1668, 1901.80, -1956.30, 22208.15,   0.00, 90.00, 280.00, .interiorid = 25);
	CreateDynamicObject(1738, 1898.70, -1953.80, 22207.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2230, 1873.86, -1948.65, 22201.18,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1879.50, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1905.25, -1948.65, 22203.77,   0.00, 179.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1874.46, -1949.90, 22201.05,   0.00, 90.00, 270.00, .interiorid = 25);
	CreateDynamicObject(2230, 1876.92, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1887.26, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1879.51, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1879.51, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1882.09, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1882.10, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1887.25, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1884.68, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1884.67, -1948.65, 22201.67,   0.00, 269.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1889.84, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1889.83, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1895.00, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1892.41, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2290, 1886.50, -1956.00, 22207.17,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2230, 1892.42, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1895.00, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1897.59, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1904.66, -1951.20, 22206.34,   0.00, 90.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2230, 1900.18, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1900.17, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1902.76, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1902.76, -1948.65, 22201.67,   0.00, 269.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1905.13, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1873.86, -1948.65, 22203.77,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1874.47, -1948.65, 22206.36,   0.00, 179.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1874.35, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1876.94, -1948.65, 22201.06,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1882.09, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1876.94, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1876.91, -1948.65, 22206.97,   0.00, 269.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1884.68, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1879.50, -1948.65, 22206.97,   0.00, 269.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1882.09, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1884.68, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1887.27, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1887.27, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1889.85, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1889.85, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1892.44, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1892.44, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1895.00, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1895.00, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1897.58, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1897.58, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1900.16, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1873.86, -1948.65, 22205.55,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1900.15, -1948.65, 22206.97,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1902.74, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1902.73, -1948.65, 22206.97,   0.00, 269.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1905.13, -1948.65, 22206.36,   0.00, 90.00, 179.99, .interiorid = 25);
	CreateDynamicObject(14434, 1879.30, -1945.40, 22207.20,   0.00, 0.00, 178.00, .interiorid = 25);
	CreateDynamicObject(7903, 1880.30, -1918.30, 22196.80,   0.00, 0.00, 202.25, .interiorid = 25);
	CreateDynamicObject(7903, 1897.90, -1958.20, 22197.50,   0.00, 0.00, 22.25, .interiorid = 25);
	CreateDynamicObject(14467, 1876.10, -1951.80, 22198.00,   0.00, 0.00, 178.74, .interiorid = 25);
	CreateDynamicObject(14467, 1873.30, -1929.70, 22198.00,   0.00, 0.00, 58.24, .interiorid = 25);
	CreateDynamicObject(1763, 1902.90, -1936.60, 22195.10,   0.00, 0.00, 328.00, .interiorid = 25);
	CreateDynamicObject(1763, 1894.00, -1948.90, 22195.00,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1761, 1883.30, -1929.60, 22195.10,   0.00, 0.00, 314.99, .interiorid = 25);
	CreateDynamicObject(2315, 1901.90, -1937.80, 22195.10,   0.00, 0.00, 328.25, .interiorid = 25);
	CreateDynamicObject(2370, 1882.70, -1932.10, 22194.80,   0.00, 0.00, 45.00, .interiorid = 25);
	CreateDynamicObject(1761, 1882.10, -1933.60, 22195.10,   0.00, 0.00, 133.49, .interiorid = 25);
	CreateDynamicObject(2125, 1888.60, -1933.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1887.70, -1933.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1886.70, -1933.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1885.70, -1933.40, 22195.40,   90.00, 340.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1885.20, -1934.80, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1885.20, -1935.90, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1885.20, -1937.00, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1885.30, -1940.90, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1885.30, -1942.00, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1885.30, -1943.10, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1886.40, -1944.30, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1887.50, -1944.30, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1888.70, -1944.30, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1892.70, -1944.30, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1894.00, -1944.30, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1895.20, -1944.30, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1896.20, -1943.20, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1896.20, -1942.00, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1896.20, -1940.80, 22195.40,   90.00, 50.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1896.00, -1936.90, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1896.00, -1935.70, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1896.00, -1934.60, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1894.80, -1933.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1893.70, -1933.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2125, 1892.60, -1933.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1670, 1902.90, -1938.40, 22195.61,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1902.90, -1938.30, 22195.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2904, 1890.70, -1925.18, 22199.20,   0.00, 0.00, 1.00, .interiorid = 25);
	CreateDynamicObject(2904, 1888.30, -1925.22, 22199.20,   0.00, 0.00, 1.00, .interiorid = 25);
	CreateDynamicObject(18553, 1889.10, -1925.20, 22196.60,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2230, 1874.35, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1874.46, -1949.91, 22201.66,   0.00, 270.00, 269.99, .interiorid = 25);
	CreateDynamicObject(2230, 1874.46, -1952.49, 22201.66,   0.00, 270.00, 269.99, .interiorid = 25);
	CreateDynamicObject(970, 1876.30, -1948.40, 22207.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1874.20, -1950.60, 22207.50,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(970, 1880.40, -1948.40, 22207.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1884.56, -1948.40, 22207.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1888.66, -1948.40, 22207.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1892.76, -1948.40, 22207.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1896.86, -1948.40, 22207.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1901.01, -1948.40, 22207.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1902.77, -1948.40, 22207.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1904.86, -1950.59, 22207.50,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2230, 1874.45, -1949.91, 22206.97,   0.00, 270.00, 270.00, .interiorid = 25);
	CreateDynamicObject(2230, 1874.46, -1949.90, 22206.37,   0.00, 90.00, 270.00, .interiorid = 25);
	CreateDynamicObject(2230, 1874.46, -1952.49, 22206.97,   0.00, 269.99, 269.99, .interiorid = 25);
	CreateDynamicObject(1649, 1884.51, -1952.50, 22208.06,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1502, 1880.78, -1952.58, 22207.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1649, 1882.51, -1952.50, 22211.36,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2290, 1873.70, -1960.10, 22207.20,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1502, 1892.29, -1959.12, 22207.20,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(1649, 1876.51, -1952.50, 22208.86,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1649, 1876.51, -1952.50, 22212.16,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1768, 1883.80, -1953.10, 22195.26,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(1737, 1882.30, -1951.80, 22195.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1709, 1879.20, -1925.90, 22195.26,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1737, 1872.40, -1943.20, 22196.34,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1737, 1872.40, -1935.50, 22196.34,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(14820, 1872.40, -1935.00, 22197.20,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(14820, 1872.40, -1942.73, 22197.20,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1548, 1888.00, -1943.30, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1548, 1893.50, -1943.30, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1548, 1893.50, -1934.40, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1548, 1887.80, -1934.50, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1548, 1886.30, -1936.20, 22196.10,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1548, 1886.30, -1941.80, 22196.10,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1548, 1895.10, -1941.70, 22196.10,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1548, 1895.20, -1936.10, 22196.10,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1551, 1895.10, -1934.30, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1551, 1895.10, -1936.10, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1551, 1895.20, -1935.00, 22196.15,   0.00, 90.00, 30.00, .interiorid = 25);
	CreateDynamicObject(1664, 1894.80, -1934.20, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1895.30, -1934.50, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1666, 1892.50, -1934.20, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1667, 1893.50, -1934.30, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1668, 1893.20, -1934.70, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1669, 1894.50, -1934.60, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1951, 1895.30, -1937.30, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1951, 1895.20, -1942.90, 22196.15,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1950, 1894.80, -1943.40, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1669, 1895.00, -1942.50, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1668, 1895.10, -1940.60, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1667, 1895.00, -1941.00, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1666, 1895.00, -1941.70, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1895.20, -1943.30, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1551, 1892.30, -1943.20, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1893.40, -1943.10, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1543, 1892.80, -1943.60, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1520, 1889.20, -1943.30, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1517, 1888.60, -1943.10, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1512, 1887.10, -1943.30, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1510, 1886.90, -1943.50, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1509, 1888.90, -1943.50, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1486, 1886.60, -1943.00, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1485, 1886.80, -1943.50, 22196.12,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1485, 1895.00, -1943.30, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1485, 1895.20, -1934.50, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1669, 1887.30, -1943.50, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1669, 1886.30, -1943.40, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1668, 1886.50, -1941.10, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1667, 1886.20, -1942.70, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1666, 1886.20, -1940.80, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1889.10, -1943.60, 22196.09,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1551, 1886.40, -1940.60, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1485, 1889.00, -1943.60, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1669, 1892.20, -1934.50, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1668, 1889.20, -1934.30, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1667, 1888.60, -1934.50, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1666, 1889.00, -1934.70, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1886.80, -1934.50, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1888.90, -1934.40, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1886.30, -1937.20, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1664, 1886.40, -1934.50, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1551, 1886.50, -1935.00, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1886.10, -1935.10, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1543, 1886.50, -1937.40, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1485, 1886.70, -1934.40, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1485, 1888.80, -1934.30, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1485, 1886.20, -1937.10, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1737, 1881.60, -1926.40, 22195.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2653, 1904.50, -1957.10, 22211.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1874.20, -1950.60, 22202.00,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(14387, 1871.30, -1950.60, 22195.43,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(2395, 1873.71, -1950.59, 22193.68,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(3029, 1906.50, -1951.04, 22195.14,   0.00, 0.00, 319.75, .interiorid = 25);
	CreateDynamicObject(2957, 1908.68, -1948.45, 22195.76,   0.00, 90.00, 228.75, .interiorid = 25);
	CreateDynamicObject(2957, 1905.40, -1952.22, 22195.76,   0.00, 90.00, 228.75, .interiorid = 25);
	CreateDynamicObject(2957, 1907.70, -1949.57, 22199.61,   0.00, 0.00, 229.25, .interiorid = 25);
	CreateDynamicObject(14474, 1939.15, -1951.30, 22197.09,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(16151, 1895.50, -1959.60, 22201.60,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(2292, 1883.44, -1957.70, 22201.25,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(2291, 1882.97, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2291, 1882.01, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2292, 1873.70, -1957.70, 22201.25,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2291, 1875.17, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2291, 1876.15, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2291, 1877.12, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2291, 1879.08, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2291, 1878.10, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2291, 1880.06, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2291, 1881.03, -1957.70, 22201.25,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2291, 1873.70, -1957.22, 22201.25,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2291, 1873.70, -1956.25, 22201.25,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2291, 1873.70, -1955.28, 22201.25,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2292, 1873.70, -1953.88, 22201.25,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2290, 1908.80, -1954.70, 22195.30,   0.00, 0.00, 140.00, .interiorid = 25);
	CreateDynamicObject(2001, 1909.70, -1949.30, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2001, 1890.70, -1956.00, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2254, 1917.20, -1951.58, 22198.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(638, 1918.90, -1952.87, 22196.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(638, 1918.90, -1955.50, 22196.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(638, 1918.90, -1958.18, 22196.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(638, 1918.90, -1960.81, 22196.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(644, 1909.60, -1955.40, 22195.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2290, 1910.30, -1949.90, 22195.30,   0.00, 0.00, 320.00, .interiorid = 25);
	CreateDynamicObject(2001, 1906.70, -1952.80, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1902.74, -1948.40, 22202.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1876.40, -1948.40, 22202.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1880.55, -1948.40, 22202.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1884.66, -1948.40, 22202.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1888.76, -1948.40, 22202.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1892.86, -1948.40, 22202.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1897.01, -1948.40, 22202.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1901.14, -1948.40, 22202.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1737, 1881.60, -1956.30, 22200.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1737, 1878.60, -1956.30, 22200.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1737, 1875.40, -1956.30, 22200.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1763, 1902.30, -1939.80, 22195.10,   0.00, 0.00, 148.75, .interiorid = 25);
	CreateDynamicObject(1763, 1896.50, -1947.70, 22195.00,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(1737, 1895.30, -1948.80, 22194.80,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1763, 1899.60, -1948.90, 22195.00,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1737, 1900.80, -1948.80, 22194.80,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1763, 1902.00, -1947.70, 22195.00,   0.00, 0.00, 269.99, .interiorid = 25);
	CreateDynamicObject(1703, 1888.00, -1956.00, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2001, 1912.60, -1951.70, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2001, 1887.40, -1956.00, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1702, 1897.60, -1954.10, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1703, 1880.60, -1951.96, 22201.10,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2290, 1873.70, -1956.20, 22207.20,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2001, 1873.70, -1957.10, 22207.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2230, 1904.64, -1948.65, 22201.18,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1874.47, -1948.65, 22203.77,   0.00, 179.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1904.64, -1948.65, 22203.77,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1905.25, -1948.65, 22206.36,   0.00, 179.99, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1904.64, -1948.65, 22205.56,   0.00, 0.00, 179.99, .interiorid = 25);
	CreateDynamicObject(1703, 1875.00, -1951.50, 22201.10,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2230, 1897.59, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1897.59, -1948.65, 22201.67,   0.00, 270.00, 179.99, .interiorid = 25);
	CreateDynamicObject(2230, 1904.66, -1948.61, 22206.95,   0.00, 270.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2230, 1904.66, -1951.19, 22201.67,   0.00, 270.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2230, 1904.66, -1948.61, 22201.67,   0.00, 270.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2230, 1904.66, -1951.20, 22201.06,   0.00, 90.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2230, 1904.66, -1951.20, 22206.95,   0.00, 270.00, 90.00, .interiorid = 25);
	CreateDynamicObject(14384, 1951.82, -1956.23, 22196.80,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(3095, 1950.00, -1947.60, 22198.80,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(3095, 1950.00, -1938.60, 22198.80,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(3095, 1959.00, -1947.60, 22198.80,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(3095, 1959.00, -1939.70, 22198.80,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(3095, 1939.10, -1949.00, 22198.90,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(3029, 1911.30, -1947.30, 22195.00,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(3095, 1955.30, -1941.01, 22202.30,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1786, 1949.90, -1942.00, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2101, 1948.60, -1942.30, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2103, 1951.20, -1942.30, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2100, 1946.00, -1943.20, 22195.30,   0.00, 0.00, 50.00, .interiorid = 25);
	CreateDynamicObject(2233, 1948.30, -1942.40, 22195.30,   0.00, 0.00, 32.50, .interiorid = 25);
	CreateDynamicObject(2233, 1952.80, -1942.80, 22195.30,   0.00, 0.00, 332.50, .interiorid = 25);
	CreateDynamicObject(1766, 1951.00, -1947.40, 22195.20,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1768, 1952.59, -1944.43, 22195.30,   0.00, 0.00, 258.00, .interiorid = 25);
	CreateDynamicObject(1711, 1947.70, -1946.40, 22195.30,   0.00, 0.00, 125.75, .interiorid = 25);
	CreateDynamicObject(2233, 1951.70, -1947.90, 22195.30,   0.00, 0.00, 212.49, .interiorid = 25);
	CreateDynamicObject(2233, 1947.60, -1947.30, 22195.30,   0.00, 0.00, 142.49, .interiorid = 25);
	CreateDynamicObject(2370, 1949.70, -1945.60, 22194.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1709, 1927.50, -1948.60, 22195.30,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2315, 1928.20, -1946.90, 22195.20,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1665, 1928.20, -1945.60, 22195.71,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1668, 1928.30, -1945.30, 22195.85,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1669, 1928.20, -1945.90, 22195.85,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1738, 1929.00, -1942.80, 22195.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1928.10, -1945.50, 22195.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1486, 1927.90, -1945.80, 22195.75,   0.00, 90.00, 30.00, .interiorid = 25);
	CreateDynamicObject(1510, 1928.10, -1946.20, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1512, 1927.90, -1946.40, 22195.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1520, 1928.00, -1946.70, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2653, 1929.70, -1942.40, 22198.10,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2649, 1933.90, -1942.10, 22199.80,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3804, 1926.00, -1946.20, 22197.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2691, 1950.00, -1942.20, 22197.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2691, 1933.60, -1942.58, 22197.01,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2595, 1934.90, -1944.10, 22196.16,   0.00, 0.00, 230.00, .interiorid = 25);
	CreateDynamicObject(2319, 1935.00, -1944.90, 22195.30,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2817, 1924.20, -1950.80, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2819, 1928.60, -1944.10, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2824, 1928.30, -1946.50, 22195.30,   0.00, 0.00, 50.00, .interiorid = 25);
	CreateDynamicObject(2827, 1934.90, -1944.90, 22195.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2834, 1949.50, -1944.00, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3383, 1931.30, -1959.00, 22195.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3383, 1927.70, -1959.00, 22195.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2045, 1928.50, -1945.80, 22195.71,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1550, 1926.30, -1957.90, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2738, 1938.70, -1959.40, 22195.90,   0.00, 0.00, 130.00, .interiorid = 25);
	CreateDynamicObject(2739, 1941.70, -1955.80, 22195.30,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(2742, 1942.10, -1955.60, 22196.80,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(2713, 1941.90, -1956.80, 22195.47,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1771, 1944.70, -1943.90, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1793, 1939.50, -1944.20, 22195.30,   0.00, 0.00, 89.49, .interiorid = 25);
	CreateDynamicObject(1801, 1941.80, -1947.10, 22195.30,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(1766, 1896.30, -1918.10, 22201.20,   0.00, 0.00, 310.00, .interiorid = 25);
	CreateDynamicObject(1763, 1884.70, -1917.90, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2370, 1895.50, -1920.70, 22200.90,   0.00, 0.00, 40.74, .interiorid = 25);
	CreateDynamicObject(1766, 1894.70, -1922.20, 22201.20,   0.00, 0.00, 130.00, .interiorid = 25);
	CreateDynamicObject(1763, 1885.90, -1920.70, 22201.30,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1433, 1885.20, -1919.30, 22201.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(11665, 1903.00, -1950.70, 22201.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1905.00, -1950.60, 22202.00,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1704, 1892.20, -1951.30, 22201.10,   0.00, 0.00, 136.75, .interiorid = 25);
	CreateDynamicObject(1704, 1886.70, -1951.00, 22201.10,   0.00, 0.00, 225.00, .interiorid = 25);
	CreateDynamicObject(2800, 1882.90, -1951.90, 22195.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2800, 1882.70, -1931.70, 22195.47,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2800, 1900.80, -1948.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2800, 1895.20, -1948.30, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1711, 1888.80, -1924.70, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1711, 1882.60, -1924.70, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1711, 1876.20, -1924.70, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1711, 1895.30, -1924.80, 22201.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1768, 1880.50, -1923.50, 22201.20,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1433, 1879.40, -1922.00, 22201.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2902, 1934.60, -1943.40, 22195.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3029, 1930.33, -1951.80, 22195.30,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(1502, 1942.40, -1959.00, 22195.30,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1804, 1939.40, -1944.80, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2103, 1937.50, -1943.00, 22195.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2320, 1939.10, -1942.20, 22196.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2517, 1938.70, -1953.60, 22195.30,   0.00, 0.00, 358.75, .interiorid = 25);
	CreateDynamicObject(2526, 1941.80, -1953.80, 22195.30,   0.00, 0.00, 90.25, .interiorid = 25);
	CreateDynamicObject(2629, 1936.80, -1947.80, 22195.30,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(3029, 1935.80, -1947.18, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2693, 1935.10, -1948.00, 22195.99,   0.00, 0.00, 240.00, .interiorid = 25);
	CreateDynamicObject(2692, 1954.58, -1951.25, 22196.04,   0.00, 0.00, 229.00, .interiorid = 25);
	CreateDynamicObject(2677, 1948.80, -1950.30, 22195.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2676, 1951.90, -1948.80, 22195.43,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(14475, 1941.75, -1951.20, 22199.09,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(2671, 1951.80, -1944.30, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2670, 1947.60, -1945.10, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2673, 1948.90, -1944.10, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2674, 1944.10, -1952.80, 22195.34,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2676, 1937.50, -1946.70, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2670, 1930.90, -1945.50, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2671, 1930.80, -1946.10, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2672, 1934.50, -1945.20, 22195.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2674, 1932.10, -1950.30, 22195.33,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2844, 1944.20, -1943.50, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2845, 1942.30, -1947.90, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2846, 1937.50, -1944.50, 22196.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1485, 1949.70, -1944.80, 22195.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1949.80, -1944.80, 22195.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1668, 1949.70, -1945.40, 22195.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1669, 1949.40, -1945.90, 22195.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1951, 1950.40, -1945.10, 22195.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1950.10, -1945.60, 22195.78,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1543, 1951.99, -1946.64, 22195.96,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1512, 1950.10, -1945.80, 22195.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1517, 1949.00, -1947.40, 22195.90,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1551, 1952.16, -1944.97, 22195.85,   0.00, 270.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1952.40, -1944.21, 22195.97,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1953.10, -1944.60, 22196.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3004, 1950.60, -1945.80, 22195.74,   0.00, 70.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3497, 1933.70, -1951.30, 22198.00,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2114, 1933.70, -1951.10, 22195.43,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2105, 1935.20, -1943.60, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2105, 1928.10, -1942.90, 22195.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(926, 1954.87, -1947.53, 22195.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(913, 1942.30, -1943.00, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3092, 1936.80, -1954.60, 22195.50,   0.00, 90.00, 20.00, .interiorid = 25);
	CreateDynamicObject(3092, 1936.50, -1953.80, 22195.50,   0.00, 90.00, 340.00, .interiorid = 25);
	CreateDynamicObject(3092, 1935.60, -1954.10, 22195.50,   0.00, 90.00, 150.00, .interiorid = 25);
	CreateDynamicObject(3092, 1936.80, -1954.30, 22195.80,   0.00, 90.00, 119.99, .interiorid = 25);
	CreateDynamicObject(3008, 1934.90, -1954.50, 22195.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2906, 1936.10, -1954.50, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2905, 1934.80, -1954.40, 22195.40,   0.00, 0.00, 316.00, .interiorid = 25);
	CreateDynamicObject(2906, 1934.60, -1953.80, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3092, 1935.60, -1954.10, 22195.80,   0.00, 90.00, 47.99, .interiorid = 25);
	CreateDynamicObject(3092, 1936.40, -1954.00, 22196.20,   0.00, 90.00, 347.99, .interiorid = 25);
	CreateDynamicObject(2900, 1934.00, -1953.80, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2900, 1934.00, -1954.80, 22197.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2673, 1950.80, -1945.00, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2674, 1929.60, -1948.60, 22195.33,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2675, 1932.30, -1947.20, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2676, 1939.90, -1956.10, 22195.41,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2844, 1939.30, -1944.80, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2845, 1938.80, -1946.10, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(931, 1929.80, -1955.70, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1579, 1929.00, -1955.10, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1579, 1929.50, -1955.10, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1579, 1929.50, -1955.10, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1580, 1929.20, -1955.10, 22196.56,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1577, 1928.99, -1955.50, 22196.42,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1580, 1929.50, -1955.50, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1580, 1930.00, -1955.10, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1580, 1930.50, -1955.50, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1580, 1930.50, -1955.80, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1580, 1928.90, -1956.30, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1579, 1930.60, -1955.10, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1578, 1930.00, -1955.50, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1578, 1929.80, -1955.15, 22196.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2901, 1929.50, -1955.20, 22195.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2901, 1929.50, -1955.60, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2901, 1929.50, -1956.00, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2901, 1929.50, -1955.70, 22195.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2901, 1930.60, -1955.70, 22195.60,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(2900, 1934.00, -1954.80, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2900, 1934.00, -1954.80, 22196.49,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2900, 1934.00, -1953.80, 22196.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2900, 1934.00, -1953.80, 22197.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(2900, 1934.00, -1954.80, 22197.68,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1930.30, -1955.30, 22196.50,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(3409, 1931.10, -1960.70, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3409, 1927.70, -1960.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3409, 1930.60, -1960.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3409, 1928.20, -1960.40, 22195.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(941, 1928.80, -1952.50, 22195.76,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(941, 1926.46, -1952.50, 22195.76,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(941, 1926.50, -1954.50, 22195.76,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(941, 1926.50, -1956.83, 22195.76,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1580, 1926.50, -1957.40, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1579, 1926.30, -1956.80, 22196.20,   0.00, 0.00, 50.00, .interiorid = 25);
	CreateDynamicObject(1578, 1926.80, -1957.10, 22196.20,   0.00, 0.00, 330.00, .interiorid = 25);
	CreateDynamicObject(1577, 1926.40, -1956.10, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1576, 1926.80, -1956.50, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.60, -1957.20, 22196.35,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1550, 1926.20, -1955.50, 22196.55,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1550, 1926.40, -1955.00, 22196.45,   0.00, 90.00, 300.00, .interiorid = 25);
	CreateDynamicObject(1577, 1926.80, -1955.70, 22196.20,   0.00, 0.00, 310.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.90, -1955.00, 22196.20,   0.00, 0.00, 280.00, .interiorid = 25);
	CreateDynamicObject(1576, 1926.40, -1954.30, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.40, -1953.90, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1577, 1926.50, -1954.10, 22196.35,   0.00, 0.00, 308.00, .interiorid = 25);
	CreateDynamicObject(1578, 1926.90, -1954.40, 22196.20,   0.00, 0.00, 290.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.20, 22196.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.50, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.80, -1952.50, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.80, -1952.20, 22196.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.80, -1952.20, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.80, -1952.20, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.80, -1952.20, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.80, -1952.50, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.80, -1952.50, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.50, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.20, 22196.20,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.20, 22196.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.20, 22196.40,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.20, 22196.50,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.20, 22196.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1575, 1926.30, -1952.20, 22196.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1927.90, -1959.10, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1932.00, -1959.00, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1931.50, -1959.10, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1930.60, -1959.20, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1929.60, -1959.20, 22196.10,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(4227, 1925.97, -1953.30, 22196.90,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(17969, 1927.00, -1951.58, 22197.40,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(14840, 1955.28, -1947.46, 22197.60,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1526, 1943.90, -1948.88, 22197.30,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1531, 1945.40, -1943.90, 22197.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1526, 1935.50, -1944.00, 22197.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1736, 1904.64, -1957.50, 22211.10,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(1665, 1928.10, -1947.10, 22195.71,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1927.80, -1946.10, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1928.40, -1946.40, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1928.50, -1947.10, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1928.30, -1947.00, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1927.90, -1947.10, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1928.00, -1947.50, 22195.30,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1512, 1928.00, -1946.00, 22195.90,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(1486, 1928.30, -1946.10, 22195.80,   0.00, 90.00, 310.00, .interiorid = 25);
	CreateDynamicObject(1544, 1927.90, -1946.60, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1928.10, -1945.80, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1520, 1928.40, -1946.70, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1520, 1928.30, -1947.20, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1520, 1928.00, -1945.40, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1544, 1934.70, -1943.70, 22195.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1928.00, -1947.00, 22195.80,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1928.20, -1946.40, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3044, 1928.40, -1946.10, 22195.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1665, 1928.40, -1946.30, 22195.71,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(7191, 1936.02, -1951.74, 22193.60,   90.00, 179.99, 89.99, .interiorid = 25);
	CreateDynamicObject(7191, 1937.73, -1948.77, 22193.60,   90.00, 180.01, 269.99, .interiorid = 25);
	CreateDynamicObject(7191, 1938.25, -1948.57, 22193.60,   90.00, 179.99, 89.99, .interiorid = 25);
	CreateDynamicObject(7191, 1937.82, -1948.57, 22193.60,   90.00, 179.99, 89.99, .interiorid = 25);
	CreateDynamicObject(7191, 1938.23, -1951.92, 22193.60,   90.00, 179.99, 270.00, .interiorid = 25);
	CreateDynamicObject(7191, 1938.23, -1948.76, 22193.60,   90.00, 180.01, 269.99, .interiorid = 25);
	CreateDynamicObject(9339, 1942.40, -1970.55, 22198.52,   0.00, 180.00, 0.00, .interiorid = 25);
	CreateDynamicObject(9339, 1942.40, -1956.78, 22198.90,   270.00, 180.00, 0.01, .interiorid = 25);
	CreateDynamicObject(1526, 1955.27, -1950.20, 22197.50,   25.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(4227, 1952.30, -1952.09, 22196.70,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(7191, 1938.25, -1951.72, 22193.60,   90.00, 180.01, 89.98, .interiorid = 25);
	CreateDynamicObject(3029, 1941.98, -1948.60, 22195.30,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1508, 1945.70, -1946.10, 22196.60,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1980, 1940.40, -1942.40, 22196.60,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1980, 1931.60, -1942.40, 22196.60,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1526, 1933.37, -1956.70, 22197.60,   25.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1508, 1938.10, -1956.00, 22196.70,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3029, 1941.97, -1951.80, 22195.30,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(19325, 1892.24, -1957.07, 22209.81,   90.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19325, 1892.24, -1961.19, 22213.03,   90.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19360, 1913.27, -1948.83, 22195.31,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19360, 1916.77, -1949.75, 22195.31,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19360, 1920.25, -1949.74, 22195.31,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(11472, 1921.48, -1955.96, 22192.38,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(19385, 1912.29, -1947.33, 22197.06,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(19355, 1915.23, -1948.05, 22197.07,   0.00, 0.00, 63.50, .interiorid = 25);
	CreateDynamicObject(19433, 1916.77, -1947.35, 22195.31,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1776, 1915.43, -1946.92, 22196.31,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1776, 1914.22, -1946.90, 22196.31,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(19355, 1918.23, -1948.75, 22197.07,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(19385, 1922.38, -1950.27, 22197.07,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19355, 1920.74, -1949.08, 22197.07,   0.00, 0.00, 78.00, .interiorid = 25);
	CreateDynamicObject(19355, 1920.71, -1951.09, 22197.07,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(19355, 1917.52, -1950.75, 22197.07,   0.00, 0.00, 78.00, .interiorid = 25);
	CreateDynamicObject(19355, 1914.38, -1950.09, 22197.07,   0.00, 0.00, 78.00, .interiorid = 25);
	CreateDynamicObject(19355, 1912.42, -1948.84, 22197.07,   0.00, 0.00, 30.00, .interiorid = 25);
	CreateDynamicObject(19371, 1920.63, -1949.90, 22198.82,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19371, 1917.13, -1949.66, 22198.82,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19371, 1913.64, -1948.83, 22198.82,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19355, 1918.12, -1946.00, 22197.07,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(3260, 1949.11, -1959.88, 22197.24,   0.00, 90.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3260, 1948.75, -1959.90, 22196.74,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3260, 1950.69, -1959.88, 22196.74,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(3029, 1922.72, -1951.24, 22194.96,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(348, 1949.49, -1946.03, 22195.77,   -87.78, -40.68, 0.00, .interiorid = 25);
	CreateDynamicObject(348, 1950.56, -1945.96, 22195.77,   -87.78, -40.68, 0.00, .interiorid = 25);
	CreateDynamicObject(348, 1945.97, -1943.76, 22196.25,   -89.58, -35.64, 0.00, .interiorid = 25);
	CreateDynamicObject(349, 1949.68, -1942.33, 22197.16,   -87.24, 23.64, 7.74, .interiorid = 25);
	CreateDynamicObject(1508, 1955.55, -1941.82, 22196.45,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1878.72, -1958.39, 22207.73,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1882.83, -1958.39, 22207.73,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(970, 1884.92, -1960.48, 22207.73,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1649, 1901.80, -1952.50, 22208.83,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(1651, 1868.79, -1948.21, 22205.03,   90.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1651, 1866.61, -1948.21, 22205.03,   90.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1651, 1864.43, -1948.21, 22205.03,   90.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1651, 1862.25, -1948.21, 22205.03,   90.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1651, 1860.07, -1948.21, 22205.03,   90.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(19143, 1880.46, -1939.36, 22200.59,   0.00, 0.00, 273.00, .interiorid = 25);
	CreateDynamicObject(19144, 1880.46, -1938.36, 22200.59,   0.00, 0.00, 273.00, .interiorid = 25);
	CreateDynamicObject(19145, 1879.51, -1938.25, 22200.59,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19146, 1877.60, -1938.28, 22200.59,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19147, 1875.83, -1938.18, 22200.59,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19148, 1873.92, -1938.30, 22200.59,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19149, 1873.04, -1936.84, 22200.59,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(19150, 1873.03, -1934.70, 22200.59,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(19151, 1873.02, -1932.81, 22200.59,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(19152, 1872.37, -1932.69, 22200.59,   0.00, 0.00, 0.00, .interiorid = 25);
	CreateDynamicObject(19143, 1878.69, -1939.46, 22200.59,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(19144, 1876.77, -1939.42, 22200.59,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(19145, 1874.88, -1939.38, 22200.59,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(19146, 1872.80, -1939.01, 22200.59,   0.00, 0.00, 222.00, .interiorid = 25);
	CreateDynamicObject(19147, 1873.02, -1940.80, 22200.59,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(19148, 1873.09, -1942.25, 22200.59,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(19149, 1872.99, -1943.74, 22200.59,   0.00, 0.00, 270.00, .interiorid = 25);
	CreateDynamicObject(19150, 1872.96, -1944.97, 22200.59,   0.00, 0.00, 222.00, .interiorid = 25);
	CreateDynamicObject(19151, 1872.19, -1945.06, 22200.59,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(348, 1902.19, -1957.90, 22208.12,   -87.06, -52.32, 0.00, .interiorid = 25);
	CreateDynamicObject(19355, 1914.65, -1947.30, 22197.07,   0.00, 0.00, 90.00, .interiorid = 25);
	CreateDynamicObject(1649, 1876.51, -1952.50, 22208.86,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1649, 1876.51, -1952.50, 22212.16,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1649, 1882.51, -1952.50, 22211.36,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1649, 1884.51, -1952.50, 22208.06,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1649, 1901.80, -1952.50, 22208.83,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1649, 1901.80, -1952.50, 22212.10,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1649, 1895.60, -1952.50, 22212.10,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1649, 1892.00, -1952.52, 22208.82,   0.00, 0.00, 180.00, .interiorid = 25);
	CreateDynamicObject(1649, 1898.10, -1952.50, 22208.29,   0.00, 90.00, 180.00, .interiorid = 25);
	CreateDynamicObject(2904, 1890.70, -1925.18, 22196.67,   0.00, 0.00, 1.00, .interiorid = 25);
	CreateDynamicObject(2904, 1888.30, -1925.22, 22196.59,   0.00, 0.00, 1.00, .interiorid = 25);
	CreateDynamicObject(2774, 1905.56, -1961.26, 22206.22,   0.00, 0.00, 0.00, .interiorid = 25);
	return 1;
}
