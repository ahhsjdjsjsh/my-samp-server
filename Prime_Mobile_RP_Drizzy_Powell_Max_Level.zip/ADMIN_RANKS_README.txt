Prime Mobile RP - 19 Admin Rank Update
========================================

The gamemode source has been updated to support admin ranks 1 through 19.

Ranks:
1. Administrator
2. Curators of organisations
3. Deputy senior curator of Crime/Deputy senior curator of State
4. Senior Curator Of Crime/Senior Curator Of State
5. Deputy Senior Curator Of Roleplay
6. Senior Curator Of Roleplay
7. Assistant Deputy Chieif Administrator
8. Deputy Chieif Administrator
9. Chieif Administrator
10. Special Administrator
11. Senior Special Administrator
12. Asistant Project Curator
13. Project Curator
14. Head Of Project Curator
15. Technical Administrator
16. Deputy Project Management
17. Project Management
18. Project Co Founder
19. Project Founder

Permissions:
- Ranks 1-6 retain the existing command permission tiers.
- Ranks 7-19 have management-level access, so all of the existing admin
  commands available to Level 7 are available to these ranks.
- Project Co Founder (18) and Project Founder (19) are the top management
  ranks and have all existing admin permissions.
- Only ranks 18 and 19 can use /setadmin and /osetadmin.
- Admin rank values are restricted to 0-19.
- A lower-ranked admin cannot change the rank of a higher-ranked admin.
- /osetadmin can now promote an existing account even if it currently has
  no admin rank.

IMPORTANT:
The included gamemode source is the changed file. The pre-existing FRP.amx
is still included as a backup, but it does not contain these source changes
until it is recompiled.

On Windows, run:
    COMPILE_AND_START.bat

Or run:
    COMPILE_FRP.bat

After successful compilation, gamemodes/FRP.amx will contain the new ranks.
